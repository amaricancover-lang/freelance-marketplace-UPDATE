<?php
// ============================================================
// এই ফাইলটি শুধুমাত্র একবার ব্রাউজারে রান করে অ্যাডমিন একাউন্ট তৈরি করুন
// রান করার পর অবশ্যই এই ফাইলটি সার্ভার থেকে ডিলিট করে দিন (নিরাপত্তার জন্য)
// ============================================================
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/functions.php';

$done = false;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    $check = $conn->query("SELECT id FROM users WHERE role = 'admin' LIMIT 1");
    if ($check->num_rows > 0) {
        $error = "একটি অ্যাডমিন একাউন্ট আগে থেকেই আছে। নিরাপত্তার জন্য এই ফাইলটি ডিলিট করুন।";
    } elseif (strlen($password) < 8 || !preg_match('/[A-Za-z]/', $password) || !preg_match('/[0-9]/', $password)) {
        $error = "পাসওয়ার্ড কমপক্ষে ৮ ক্যারেক্টার এবং অক্ষর ও সংখ্যা উভয়ই থাকতে হবে";
    } else {
        $hashed = password_hash($password, PASSWORD_BCRYPT);
        // email_verified = 1 করা হচ্ছে যাতে অ্যাডমিন সরাসরি 2FA স্টেপে যায় (আলাদা ইমেইল-ভেরিফিকেশন স্টেপ এড়িয়ে)
        $stmt = $conn->prepare("INSERT INTO users (name, email, password, role, status, email_verified) VALUES (?, ?, ?, 'admin', 'approved', 1)");
        $stmt->bind_param("sss", $name, $email, $hashed);
        if ($stmt->execute()) {
            $done = true;
        } else {
            $error = "এরর: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="bn">
<head>
<link rel="icon" type="image/svg+xml" href="assets/img/favicon.svg">
<meta charset="UTF-8">
<title>অ্যাডমিন সেটআপ</title>
<style>
body{font-family:Arial;max-width:420px;margin:60px auto;padding:20px;}
input{width:100%;padding:10px;margin:6px 0 14px;border:1px solid #ccc;border-radius:6px;}
button{background:#1dbf73;color:#fff;border:none;padding:12px;width:100%;border-radius:6px;font-weight:bold;cursor:pointer;}
.warn{background:#fff3cd;padding:10px;border-radius:6px;margin-bottom:16px;}
.done{background:#d4edda;padding:10px;border-radius:6px;}
.err{background:#f8d7da;padding:10px;border-radius:6px;}
</style>
</head>
<body>
<h2>অ্যাডমিন একাউন্ট সেটআপ</h2>
<div class="warn">⚠️ এই ফাইলটি একবার ব্যবহারের পর অবশ্যই সার্ভার থেকে ডিলিট করে দিন।</div>

<?php if ($done): ?>
    <div class="done">✅ অ্যাডমিন একাউন্ট সফলভাবে তৈরি হয়েছে! এখন <a href="auth/login.php">লগইন পেজে</a> যান এবং এই ফাইলটি (setup_admin.php) ডিলিট করে দিন।</div>
<?php else: ?>
    <?php if ($error): ?><div class="err"><?php echo $error; ?></div><?php endif; ?>
    <form method="POST">
        <?php echo csrfField(); ?>
        <label>নাম</label>
        <input type="text" name="name" required>
        <label>ইমেইল</label>
        <input type="email" name="email" required>
        <label>পাসওয়ার্ড</label>
        <input type="password" name="password" required minlength="8">
        <p style="font-size:12px;color:#777;margin:-8px 0 14px;">কমপক্ষে ৮ ক্যারেক্টার, অক্ষর ও সংখ্যা মিলিয়ে</p>
        <button type="submit">অ্যাডমিন তৈরি করুন</button>
    </form>
<?php endif; ?>
</body>
</html>
