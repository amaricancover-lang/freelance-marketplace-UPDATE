<?php
require_once __DIR__ . '/../config/mail.php';
require_once __DIR__ . '/SmtpMailer.php';

// সুন্দর, কনসিস্টেন্ট HTML ইমেইল টেমপ্লেট — সব নোটিফিকেশন এই র‍্যাপার দিয়ে যায়
function emailTemplate($title, $bodyHtml) {
    return '
    <!DOCTYPE html>
    <html>
    <body style="margin:0;padding:0;background:#f7f7f9;font-family:Arial,Helvetica,sans-serif;">
        <table width="100%" cellpadding="0" cellspacing="0" style="background:#f7f7f9;padding:30px 0;">
            <tr><td align="center">
                <table width="480" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:10px;overflow:hidden;">
                    <tr><td style="background:#222325;padding:18px 24px;">
                        <span style="color:#ffffff;font-family:Helvetica,Arial,sans-serif;font-size:26px;font-weight:700;letter-spacing:-1px;line-height:1;">FreeUp</span>
                    </td></tr>
                    <tr><td style="padding:28px 24px;">
                        <h2 style="margin:0 0 14px;color:#222325;font-size:18px;">' . $title . '</h2>
                        <div style="color:#4f4f4f;font-size:14px;line-height:1.6;">' . $bodyHtml . '</div>
                    </td></tr>
                    <tr><td style="padding:16px 24px;background:#f0f0f0;color:#999;font-size:12px;">
                        এই মেইলটি স্বয়ংক্রিয়ভাবে পাঠানো হয়েছে, রিপ্লাই করার প্রয়োজন নেই।
                    </td></tr>
                </table>
            </td></tr>
        </table>
    </body>
    </html>';
}

// কেন্দ্রীয় মেইল পাঠানোর ফাংশন — সব নোটিফিকেশন এই একটা ফাংশন দিয়ে যায়
// SMTP_ENABLED = true থাকলে নিজস্ব SmtpMailer ব্যবহার করে, নাহলে PHP এর mail() এ ফলব্যাক করে
function sendEmail($toEmail, $toName, $subject, $bodyHtml) {
    if (!$toEmail) return false;

    $html = emailTemplate($subject, $bodyHtml);

    if (SMTP_ENABLED) {
        $mailer = new SmtpMailer(SMTP_HOST, SMTP_PORT, SMTP_ENCRYPTION, SMTP_USERNAME, SMTP_PASSWORD);
        $ok = $mailer->send($toEmail, $toName, MAIL_FROM_EMAIL, MAIL_FROM_NAME, $subject, $html);
        if (!$ok) {
            error_log("Mail send failed to $toEmail: " . $mailer->getLastError());
        }
        return $ok;
    }

    // ফলব্যাক: PHP বিল্ট-ইন mail() (লোকাল সার্ভারে সাধারণত কাজ করে না)
    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
    $headers .= "From: " . MAIL_FROM_NAME . " <" . MAIL_FROM_EMAIL . ">\r\n";
    return @mail($toEmail, $subject, $html, $headers);
}
