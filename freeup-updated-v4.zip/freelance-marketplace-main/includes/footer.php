</main>
<footer class="site-footer">
  <div class="footer-grid">
    <div>
      <h5>ক্যাটাগরি</h5>
      <?php foreach (array_slice(siteCategories(), 0, 6) as $__fc): ?>
        <a href="<?php echo BASE_URL; ?>gigs/browse.php?category=<?php echo urlencode($__fc['name']); ?>"><?php echo htmlspecialchars($__fc['name']); ?></a>
      <?php endforeach; ?>
    </div>
    <div>
      <h5>ক্লায়েন্টদের জন্য</h5>
      <a href="<?php echo BASE_URL; ?>gigs/browse.php">গিগ ব্রাউজ</a>
      <a href="<?php echo BASE_URL; ?>messages/inbox.php">মেসেজ</a>
      <a href="<?php echo BASE_URL; ?>auth/register.php">অ্যাকাউন্ট খুলুন</a>
    </div>
    <div>
      <h5>ফ্রিল্যান্সারদের জন্য</h5>
      <a href="<?php echo BASE_URL; ?>auth/register.php">সেলার হোন</a>
      <a href="<?php echo BASE_URL; ?>developer/dashboard.php">ড্যাশবোর্ড</a>
    </div>
    <div>
      <h5>FreeUp</h5>
      <a href="<?php echo BASE_URL; ?>auth/login.php">লগইন</a>
      <a href="<?php echo BASE_URL; ?>index.php?nosplash=1">হোম</a>
    </div>
  </div>
  <div class="footer-copy">
    <span class="footer-brand">free<span>up</span></span>
    <span>&copy; <?php echo date('Y'); ?> FreeUp — সকল অধিকার সংরক্ষিত</span>
  </div>
</footer>
</body>
</html>
