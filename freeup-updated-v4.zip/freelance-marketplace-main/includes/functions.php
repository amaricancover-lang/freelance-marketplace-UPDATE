<?php
// সেশন কুকি হার্ডেনিং (session_start এর আগে সেট করতে হয়)
// Android অ্যাপের API রিকোয়েস্টে (api/ ফোল্ডার) সেশন/কুকি লাগে না — সেখানে টোকেন দিয়ে লগইন হয়
if (!defined('API_REQUEST')) {
    session_set_cookie_params([
        'httponly' => true,     // জাভাস্ক্রিপ্ট দিয়ে কুকি পড়া যাবে না (XSS থেকে সুরক্ষা)
        'samesite' => 'Lax',    // ক্রস-সাইট রিকোয়েস্টে কুকি পাঠাবে না (CSRF কমায়)
    ]);
    session_start();
}
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/mailer.php';

// ============ সিকিউরিটি হেডার ============
// XSS, clickjacking, MIME-sniffing এর বিরুদ্ধে ব্রাউজার-লেভেল প্রোটেকশন
header("X-Frame-Options: SAMEORIGIN");           // অন্য সাইটের <iframe> এ এই সাইট বসানো বন্ধ (clickjacking প্রতিরোধ)
header("X-Content-Type-Options: nosniff");        // ব্রাউজার ফাইলের টাইপ অনুমান করে রান করবে না
header("Referrer-Policy: strict-origin-when-cross-origin");

// প্রতিটি রিকোয়েস্টে একটি নতুন র‍্যান্ডম "nonce" — শুধু এই নির্দিষ্ট nonce-সহ <script> ট্যাগই চলবে।
// এর ফলে কোনো ইনজেক্টেড <script>alert(1)</script> (XSS) ব্রাউজার রান করবে না, কারণ তার কাছে সঠিক nonce থাকবে না।
$GLOBALS['cspNonce'] = base64_encode(random_bytes(16));
function cspNonce() {
    return $GLOBALS['cspNonce'];
}
header("Content-Security-Policy: default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'nonce-" . $GLOBALS['cspNonce'] . "'; object-src 'none'; base-uri 'self';");
// লাইভ সার্ভারে HTTPS থাকলে নিচের লাইনটি আনকমেন্ট করুন (ব্রাউজারকে বাধ্য করবে সবসময় HTTPS ব্যবহার করতে)
// header("Strict-Transport-Security: max-age=31536000; includeSubDomains");

// ============ সেশন নিষ্ক্রিয়তা টাইমআউট ============
// ৩০ মিনিট কোনো অ্যাক্টিভিটি না থাকলে অটো লগআউট হয়ে যাবে
define('SESSION_IDLE_LIMIT', 1800);
if (isset($_SESSION['user_id']) && isset($_SESSION['last_activity'])
    && (time() - $_SESSION['last_activity']) > SESSION_IDLE_LIMIT) {
    $_SESSION = [];
    session_destroy();
    session_start();
}
$_SESSION['last_activity'] = time();

// ============ প্রতিটি রিকোয়েস্টে গ্লোবাল সিকিউরিটি চেক ============
// ১. ব্লক করা IP থেকে সাইটই লোড হবে না
enforceIpBlock();

// ২. লগইন করা অবস্থায় থাকলেও, কাউকে অ্যাডমিন ব্যান করে দিলে সাথে সাথে তার সেশন কেটে যাবে
if (isset($_SESSION['user_id'])) {
    $stmt = $conn->prepare("SELECT is_banned FROM users WHERE id = ?");
    $stmt->bind_param("i", $_SESSION['user_id']);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    if ($row && $row['is_banned']) {
        $_SESSION = [];
        session_destroy();
        session_start();
    }
}

// XSS প্রতিরোধের জন্য
function clean($str) {
    global $conn;
    return htmlspecialchars($conn->real_escape_string(trim($str)), ENT_QUOTES, 'UTF-8');
}

// ============ CSRF প্রোটেকশন ============
// প্রতিটি সেশনের জন্য একটি র‍্যান্ডম টোকেন তৈরি করে সেশনে রাখে
function csrfToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// ফর্মে বসানোর জন্য হিডেন ইনপুট তৈরি করে
function csrfField() {
    return '<input type="hidden" name="csrf_token" value="' . csrfToken() . '">';
}

// POST রিকোয়েস্টে টোকেন যাচাই করে; না মিললে রিকোয়েস্ট ব্লক করে দেয়
function verifyCsrf() {
    $token = $_POST['csrf_token'] ?? '';
    if (!$token || empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
        http_response_code(403);
        die("নিরাপত্তা যাচাই ব্যর্থ হয়েছে (CSRF token mismatch)। পেজ রিলোড করে আবার চেষ্টা করুন।");
    }
}

// ============ লগইন ব্রুট-ফোর্স প্রোটেকশন (IP-বেজড, ডাটাবেজে সংরক্ষিত) ============
// কুকি/সেশন মুছে ফেললেও এই লিমিট এড়ানো যায় না, কারণ এটা IP অনুযায়ী ডাটাবেজে গণনা হয়
define('LOGIN_MAX_ATTEMPTS', 5);
define('LOGIN_LOCK_SECONDS', 300); // ৫ মিনিট
define('IDENTITY_LOCK_MAX_ATTEMPTS', 5);   // একটা নির্দিষ্ট একাউন্টে (ইমেইল/মোবাইল) কতবার ভুল হলে সতর্কীকরণ মেইল যাবে
define('IDENTITY_LOCK_WINDOW_SECONDS', 900); // কত সময়ের মধ্যে (১৫ মিনিট)

function clientIp() {
    // প্রক্সি/লোড-ব্যালান্সারের পেছনে থাকলে X-Forwarded-For ব্যবহার করা যেতে পারে,
    // কিন্তু সেটা স্পুফ করা সহজ বলে ডিফল্টভাবে REMOTE_ADDR ব্যবহার করা হচ্ছে (নিরাপদ)
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

function loginIsLocked() {
    global $conn;
    $ip = clientIp();
    $lockSeconds = LOGIN_LOCK_SECONDS;
    $stmt = $conn->prepare("SELECT COUNT(*) c FROM login_attempts WHERE ip_address = ? AND attempted_at > (NOW() - INTERVAL ? SECOND)");
    $stmt->bind_param("si", $ip, $lockSeconds);
    $stmt->execute();
    $count = $stmt->get_result()->fetch_assoc()['c'];
    return $count >= LOGIN_MAX_ATTEMPTS;
}

function loginSecondsRemaining() {
    global $conn;
    $ip = clientIp();
    $lockSeconds = LOGIN_LOCK_SECONDS;
    $stmt = $conn->prepare("SELECT MIN(attempted_at) t FROM login_attempts WHERE ip_address = ? AND attempted_at > (NOW() - INTERVAL ? SECOND)");
    $stmt->bind_param("si", $ip, $lockSeconds);
    $stmt->execute();
    $oldest = $stmt->get_result()->fetch_assoc()['t'];
    if (!$oldest) return 0;
    $elapsed = time() - strtotime($oldest);
    return max(0, LOGIN_LOCK_SECONDS - $elapsed);
}

function registerFailedLogin($identity = null) {
    global $conn;
    $ip = clientIp();
    $stmt = $conn->prepare("INSERT INTO login_attempts (ip_address, identity) VALUES (?, ?)");
    $stmt->bind_param("ss", $ip, $identity);
    $stmt->execute();

    // নির্দিষ্ট একাউন্টে থ্রেশহোল্ডে পৌঁছালে (=== ব্যবহার করা হচ্ছে যাতে বারবার মেইল না যায়) সেই ইউজারকে সতর্ক করা হয়
    if ($identity) {
        $windowSeconds = IDENTITY_LOCK_WINDOW_SECONDS;
        $cstmt = $conn->prepare("SELECT COUNT(*) c FROM login_attempts WHERE identity = ? AND attempted_at > (NOW() - INTERVAL ? SECOND)");
        $cstmt->bind_param("si", $identity, $windowSeconds);
        $cstmt->execute();
        $count = $cstmt->get_result()->fetch_assoc()['c'];

        if ($count == IDENTITY_LOCK_MAX_ATTEMPTS) {
            $ustmt = $conn->prepare("SELECT name, email FROM users WHERE email = ? OR mobile = ? LIMIT 1");
            $ustmt->bind_param("ss", $identity, $identity);
            $ustmt->execute();
            $user = $ustmt->get_result()->fetch_assoc();
            if ($user && $user['email']) {
                $body = "প্রিয় " . htmlspecialchars($user['name']) . ",<br><br>"
                      . "আপনার একাউন্টে সাম্প্রতিক কিছু সময়ে একাধিকবার ভুল পাসওয়ার্ড দিয়ে লগইনের চেষ্টা হয়েছে (IP: " . htmlspecialchars($ip) . ")।<br><br>"
                      . "এটি আপনি না হলে, আপনার পাসওয়ার্ড এখনই পরিবর্তন করার পরামর্শ দেওয়া হচ্ছে।";
                sendEmail($user['email'], $user['name'], "আপনার একাউন্টে সন্দেহজনক লগইন চেষ্টা", $body);
            }
        }
    }
}

function resetLoginAttempts() {
    global $conn;
    $ip = clientIp();
    $stmt = $conn->prepare("DELETE FROM login_attempts WHERE ip_address = ?");
    $stmt->bind_param("s", $ip);
    $stmt->execute();
}

// ============ IP ব্লকিং সিস্টেম (সিকিউরিটি অ্যাডমিন প্যানেল) ============
function isIpBlocked($ip = null) {
    global $conn;
    $ip = $ip ?? clientIp();
    $stmt = $conn->prepare("SELECT id FROM blocked_ips WHERE ip_address = ?");
    $stmt->bind_param("s", $ip);
    $stmt->execute();
    return $stmt->get_result()->num_rows > 0;
}

function blockIp($ip, $reason, $blockedBy = 'admin') {
    global $conn;
    $stmt = $conn->prepare("INSERT IGNORE INTO blocked_ips (ip_address, reason, blocked_by) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $ip, $reason, $blockedBy);
    $stmt->execute();
    logActivity(null, 'ip_blocked', "$ip ব্লক করা হয়েছে ($blockedBy): $reason");
}

function unblockIp($ip) {
    global $conn;
    $stmt = $conn->prepare("DELETE FROM blocked_ips WHERE ip_address = ?");
    $stmt->bind_param("s", $ip);
    $stmt->execute();
    logActivity(null, 'ip_unblocked', "$ip আনব্লক করা হয়েছে");
}

// প্রতিটি রিকোয়েস্টের শুরুতে চেক হয় — ব্লক করা IP থেকে সাইটই লোড হবে না
// ব্যতিক্রম: ইতিমধ্যে লগইন করা অ্যাডমিন এই চেক এড়িয়ে যায়, নাহলে ভুলবশত নিজের IP ব্লক করলে
// নিজেই সিকিউরিটি প্যানেল থেকে সেটা আনব্লক করতে পারবে না (লক-আউট এড়াতে)
function enforceIpBlock() {
    if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') return;
    if (isIpBlocked()) {
        http_response_code(403);
        if (defined('API_REQUEST')) {
            // অ্যাপের জন্য HTML নয়, JSON উত্তর
            header('Content-Type: application/json; charset=UTF-8');
            die(json_encode(['ok' => false, 'error' => [
                'code' => 'ip_blocked',
                'message' => 'সন্দেহজনক কার্যকলাপের কারণে আপনার IP ঠিকানা থেকে প্রবেশাধিকার বন্ধ করা হয়েছে।',
            ]], JSON_UNESCAPED_UNICODE));
        }
        die("<div style='font-family:sans-serif;max-width:480px;margin:80px auto;text-align:center;'>"
          . "<h2>অ্যাক্সেস বন্ধ করা হয়েছে</h2>"
          . "<p>সন্দেহজনক কার্যকলাপের কারণে আপনার IP ঠিকানা থেকে এই সাইটে প্রবেশাধিকার বন্ধ করা হয়েছে। "
          . "এটি ভুল মনে হলে সাইট অ্যাডমিনের সাথে যোগাযোগ করুন।</p></div>");
    }
}

// ============ অ্যাক্টিভিটি/অডিট লগ ============
function logActivity($userId, $action, $details = '') {
    global $conn;
    $ip = clientIp();
    $stmt = $conn->prepare("INSERT INTO activity_log (user_id, action, details, ip_address) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $userId, $action, $details, $ip);
    $stmt->execute();
}

// ============ সাধারণ পুনর্ব্যবহারযোগ্য রেট-লিমিটার ============
// $action যেকোনো নাম হতে পারে: 'forgot_password', 'chat_message', 'place_order' ইত্যাদি
function checkRateLimit($action, $maxAttempts, $windowSeconds) {
    global $conn;
    $ip = clientIp();
    $stmt = $conn->prepare("SELECT COUNT(*) c FROM rate_limits WHERE action = ? AND ip_address = ? AND created_at > (NOW() - INTERVAL ? SECOND)");
    $stmt->bind_param("ssi", $action, $ip, $windowSeconds);
    $stmt->execute();
    $count = $stmt->get_result()->fetch_assoc()['c'];
    if ($count >= $maxAttempts) return false; // লিমিট শেষ
    $ins = $conn->prepare("INSERT INTO rate_limits (action, ip_address) VALUES (?, ?)");
    $ins->bind_param("ss", $action, $ip);
    $ins->execute();
    return true; // অনুমোদিত
}

// ============ একই IP থেকে বারবার একাউন্ট খোলা ঠেকানো (অটো-ব্লক) ============
define('REGISTRATION_MAX_PER_WINDOW', 3);   // একটি IP থেকে সর্বোচ্চ কয়টি একাউন্ট
define('REGISTRATION_WINDOW_SECONDS', 86400); // কত সময়ের মধ্যে (এখানে ২৪ ঘণ্টা)

function registrationAllowedForIp() {
    global $conn;
    $ip = clientIp();
    $stmt = $conn->prepare("SELECT COUNT(*) c FROM registration_attempts WHERE ip_address = ? AND created_at > (NOW() - INTERVAL ? SECOND)");
    $windowSeconds = REGISTRATION_WINDOW_SECONDS;
    $stmt->bind_param("si", $ip, $windowSeconds);
    $stmt->execute();
    $count = $stmt->get_result()->fetch_assoc()['c'];
    return $count < REGISTRATION_MAX_PER_WINDOW;
}

function recordRegistrationAttempt() {
    global $conn;
    $ip = clientIp();
    $stmt = $conn->prepare("INSERT INTO registration_attempts (ip_address) VALUES (?)");
    $stmt->bind_param("s", $ip);
    $stmt->execute();

    // লিমিট ছাড়ালে স্বয়ংক্রিয়ভাবে IP ব্লক হয়ে যাবে
    if (!registrationAllowedForIp()) {
        blockIp(clientIp(), "একই IP থেকে " . REGISTRATION_MAX_PER_WINDOW . "+ বার একাউন্ট তৈরির চেষ্টা (অটো-ব্লক)", 'auto');
    }
}

// ============ নির্দিষ্ট একাউন্টে বারবার ভুল পাসওয়ার্ড হলে সেই ইউজারকে সতর্ক করা ============
// (এই লজিক registerFailedLogin() ফাংশনের ভেতরেই আছে — এখানে শুধু থ্রেশহোল্ড কনস্ট্যান্ট রাখা হলো)

// ============ সাধারণ ম্যাথ CAPTCHA (বট প্রতিরোধ, বাহ্যিক সার্ভিস ছাড়াই) ============
function generateCaptcha() {
    $a = random_int(1, 9);
    $b = random_int(1, 9);
    $_SESSION['captcha_answer'] = $a + $b;
    return "$a + $b = ?";
}

function captchaField() {
    $question = generateCaptcha();
    return '<label>সাধারণ যোগফল লিখুন: ' . $question . '</label><input type="number" name="captcha_answer" required>';
}

function verifyCaptcha() {
    $given = $_POST['captcha_answer'] ?? null;
    $correct = $_SESSION['captcha_answer'] ?? null;
    unset($_SESSION['captcha_answer']); // এক-বার ব্যবহারযোগ্য
    return $given !== null && $correct !== null && (int)$given === (int)$correct;
}

// ============ OTP (ইমেইল ভেরিফিকেশন / অ্যাডমিন 2FA / পাসওয়ার্ড রিসেট) ============
function generateOtp($userId, $purpose) {
    global $conn;
    $code = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    $ip = clientIp();
    $stmt = $conn->prepare("INSERT INTO otp_codes (user_id, code, purpose, request_ip, expires_at) VALUES (?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL 10 MINUTE))");
    $stmt->bind_param("isss", $userId, $code, $purpose, $ip);
    $stmt->execute();
    return $code;
}

// $bindIp = true হলে, যে IP থেকে কোড রিকোয়েস্ট হয়েছিল ভেরিফাই করার সময়ও সেই একই IP হতে হবে —
// পাসওয়ার্ড রিসেট কোডে এটি ব্যবহার করা হয় যাতে কোড অন্য কোনো নেটওয়ার্ক/ডিভাইস থেকে ব্যবহার করা না যায়
function verifyOtp($userId, $purpose, $code, $bindIp = false) {
    global $conn;
    $stmt = $conn->prepare("SELECT id, request_ip FROM otp_codes WHERE user_id = ? AND purpose = ? AND code = ? AND used = 0 AND expires_at > NOW() ORDER BY id DESC LIMIT 1");
    $stmt->bind_param("iss", $userId, $purpose, $code);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    if (!$row) return false;

    if ($bindIp && $row['request_ip'] && $row['request_ip'] !== clientIp()) {
        logActivity($userId, 'otp_ip_mismatch', "$purpose কোড অন্য IP থেকে ব্যবহারের চেষ্টা হয়েছে");
        return false;
    }

    $conn->query("UPDATE otp_codes SET used = 1 WHERE id = " . (int)$row['id']);
    return true;
}

// সহজ মেইল পাঠানোর ফাংশন — এখন কেন্দ্রীয় sendEmail() (SMTP সমর্থিত) ব্যবহার করে
function sendOtpEmail($toEmail, $toName, $code, $purpose) {
    $labels = [
        '2fa_login' => 'আপনার অ্যাডমিন লগইন ভেরিফিকেশন কোড',
        'email_verify' => 'আপনার ইমেইল ভেরিফিকেশন কোড',
        'password_reset' => 'আপনার পাসওয়ার্ড রিসেট কোড',
    ];
    $subject = $labels[$purpose] ?? 'ভেরিফিকেশন কোড';
    $body = "প্রিয় " . htmlspecialchars($toName) . ",<br><br>"
          . "আপনার কোড: <b style='font-size:22px;letter-spacing:4px;'>" . htmlspecialchars($code) . "</b><br><br>"
          . "এই কোডটি ১০ মিনিটের জন্য বৈধ। আপনি যদি এই রিকোয়েস্ট না করে থাকেন, এই মেইলটি উপেক্ষা করুন।";
    return sendEmail($toEmail, $toName, $subject, $body);
}

// ============ নোটিফিকেশন ইমেইল ============
function sendWelcomeEmail($toEmail, $toName) {
    $body = "প্রিয় " . htmlspecialchars($toName) . ",<br><br>"
          . "আমাদের মার্কেটপ্লেসে স্বাগতম! আপনার একাউন্ট সফলভাবে তৈরি হয়েছে।<br><br>"
          . "এখন আপনি গিগ ব্রাউজ করতে, অর্ডার করতে বা (ডেভলপার হলে) নিজের সার্ভিস পাবলিশ করতে পারবেন।";
    return sendEmail($toEmail, $toName, "মার্কেটপ্লেসে স্বাগতম!", $body);
}

function sendDeveloperStatusEmail($toEmail, $toName, $approved) {
    if ($approved) {
        $subject = "আপনার ডেভলপার একাউন্ট অ্যাপ্রুভ হয়েছে";
        $body = "প্রিয় " . htmlspecialchars($toName) . ",<br><br>অভিনন্দন! আপনার ডেভলপার একাউন্ট অ্যাডমিন অ্যাপ্রুভ করেছেন। এখন আপনি লগইন করে গিগ পাবলিশ করা শুরু করতে পারবেন।";
    } else {
        $subject = "আপনার ডেভলপার একাউন্ট রিজেক্ট করা হয়েছে";
        $body = "প্রিয় " . htmlspecialchars($toName) . ",<br><br>দুঃখিত, আপনার ডেভলপার একাউন্ট রিকোয়েস্ট রিজেক্ট করা হয়েছে। বিস্তারিত জানতে সাপোর্টে যোগাযোগ করুন।";
    }
    return sendEmail($toEmail, $toName, $subject, $body);
}

function sendGigStatusEmail($toEmail, $toName, $gigTitle, $approved) {
    if ($approved) {
        $subject = "আপনার গিগ লাইভ হয়েছে";
        $body = "প্রিয় " . htmlspecialchars($toName) . ",<br><br>আপনার গিগ \"<b>" . htmlspecialchars($gigTitle) . "</b>\" অ্যাডমিন অ্যাপ্রুভ করেছেন এবং এখন এটি পাবলিকলি দেখা যাচ্ছে।";
    } else {
        $subject = "আপনার গিগ রিজেক্ট করা হয়েছে";
        $body = "প্রিয় " . htmlspecialchars($toName) . ",<br><br>দুঃখিত, আপনার গিগ \"<b>" . htmlspecialchars($gigTitle) . "</b>\" রিজেক্ট করা হয়েছে। ডেসক্রিপশন/ছবি ঠিক করে আবার সাবমিট করতে পারেন।";
    }
    return sendEmail($toEmail, $toName, $subject, $body);
}

function sendNewOrderEmail($toEmail, $toName, $gigTitle, $packagePrice) {
    $body = "প্রিয় " . htmlspecialchars($toName) . ",<br><br>আপনার গিগ \"<b>" . htmlspecialchars($gigTitle) . "</b>\" এ একটি নতুন অর্ডার এসেছে (মূল্য: $" . number_format($packagePrice, 2) . ")।<br><br>দ্রুত ড্যাশবোর্ডে গিয়ে বায়ারের সাথে যোগাযোগ করুন।";
    return sendEmail($toEmail, $toName, "নতুন অর্ডার এসেছে!", $body);
}

function sendNewMessageEmail($toEmail, $toName, $fromName, $preview) {
    $body = "প্রিয় " . htmlspecialchars($toName) . ",<br><br><b>" . htmlspecialchars($fromName) . "</b> আপনাকে একটি নতুন মেসেজ পাঠিয়েছেন:<br><br>"
          . "<div style='background:#f5f5f5;padding:12px;border-radius:8px;'>" . htmlspecialchars($preview) . "</div><br>"
          . "মেসেজটি দেখতে ও রিপ্লাই দিতে সাইটে লগইন করুন।";
    return sendEmail($toEmail, $toName, "$fromName এর কাছ থেকে নতুন মেসেজ", $body);
}

// ============ সাইট সেটিংস (settings টেবিল) ও Android API ============
// টেবিলটি না থাকলে (update_api.sql ইমপোর্ট করা না হলে) এই ফাংশন এক্সেপশন ছোঁড়ে
function siteSettingRaw($key) {
    global $conn;
    $stmt = $conn->prepare("SELECT setting_value FROM settings WHERE setting_key = ?");
    $stmt->bind_param("s", $key);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    return $row ? $row['setting_value'] : null;
}

function setSiteSetting($key, $value) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?");
    $stmt->bind_param("sss", $key, $value, $value);
    $stmt->execute();
}

// 'on' = চালু, 'off' = অ্যাডমিন বন্ধ করেছেন, 'missing' = ডাটাবেজে নতুন টেবিল এখনো নেই
function apiState() {
    try {
        $v = siteSettingRaw('api_enabled');
    } catch (Throwable $e) {
        return 'missing';
    }
    return $v === '0' ? 'off' : 'on';
}

// সাইটের ক্যাটাগরি তালিকা (হোম পেজ ও Android API একই তালিকা ব্যবহার করে)
function siteCategories() {
    return [
        ['name' => 'Web Design', 'icon' => '💻'],
        ['name' => 'App Development', 'icon' => '📱'],
        ['name' => 'Graphic Design', 'icon' => '🎨'],
        ['name' => 'Content Writing', 'icon' => '✍️'],
        ['name' => 'SEO Marketing', 'icon' => '🚀'],
        ['name' => 'Voice Over', 'icon' => '🎵'],
        ['name' => 'Video Editing', 'icon' => '🎬'],
        ['name' => 'Data Entry', 'icon' => '📊'],
    ];
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header("Location: " . BASE_URL . "auth/login.php");
        exit;
    }
}

function requireRole($roles) {
    requireLogin();
    if (!in_array($_SESSION['role'], (array)$roles)) {
        header("Location: " . BASE_URL . "index.php");
        exit;
    }
}

function currentUser() {
    global $conn;
    if (!isLoggedIn()) return null;
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->bind_param("i", $_SESSION['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

function redirect($path) {
    header("Location: " . BASE_URL . $path);
    exit;
}

function flash($key, $message = null) {
    if ($message !== null) {
        $_SESSION['flash'][$key] = $message;
        return;
    }
    if (isset($_SESSION['flash'][$key])) {
        $msg = $_SESSION['flash'][$key];
        unset($_SESSION['flash'][$key]);
        return $msg;
    }
    return null;
}

// ফাইলের এক্সটেনশন না দেখে আসল কনটেন্ট (MIME টাইপ) চেক করে —
// কেউ .php ফাইলের নাম বদলে .jpg বানিয়ে আপলোড করলে সেটা ধরা পড়বে
function realMimeType($tmpPath) {
    if (!function_exists('finfo_open')) {
        return null; // fileinfo এক্সটেনশন না থাকলে এই চেক স্কিপ হবে
    }
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $tmpPath);
    finfo_close($finfo);
    return $mime;
}

// নিরাপদে ফাইল আপলোড করার ফাংশন (ইমেজ)
function uploadImage($fileInputName, $targetDir) {
    if (!isset($_FILES[$fileInputName]) || $_FILES[$fileInputName]['error'] !== UPLOAD_ERR_OK) {
        return null;
    }
    // ৫ এমবি সাইজ লিমিট
    if ($_FILES[$fileInputName]['size'] > 5 * 1024 * 1024) {
        return false;
    }
    $allowedExt = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
    $allowedMime = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    $ext = strtolower(pathinfo($_FILES[$fileInputName]['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowedExt)) {
        return false;
    }
    $mime = realMimeType($_FILES[$fileInputName]['tmp_name']);
    if ($mime !== null && !in_array($mime, $allowedMime)) {
        return false; // ফাইলের আসল কনটেন্ট ইমেজ না — বাতিল
    }
    $newName = uniqid('img_', true) . '.' . $ext;
    $destination = $targetDir . '/' . $newName;
    if (move_uploaded_file($_FILES[$fileInputName]['tmp_name'], $destination)) {
        return $newName;
    }
    return false;
}

// চ্যাটের জন্য যেকোনো ফাইল আপলোড (ডকুমেন্ট, ইমেজ, ইত্যাদি)
function uploadChatFile($fileInputName, $targetDir) {
    if (!isset($_FILES[$fileInputName]) || $_FILES[$fileInputName]['error'] !== UPLOAD_ERR_OK) {
        return null;
    }
    // ১০ এমবি সাইজ লিমিট
    if ($_FILES[$fileInputName]['size'] > 10 * 1024 * 1024) {
        return false;
    }
    $allowedExt = ['jpg', 'jpeg', 'png', 'webp', 'gif', 'pdf', 'doc', 'docx', 'zip', 'rar', 'txt'];
    $allowedMime = [
        'image/jpeg', 'image/png', 'image/webp', 'image/gif',
        'application/pdf', 'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/zip', 'application/x-rar-compressed', 'application/x-rar',
        'text/plain', 'application/octet-stream', // কিছু zip/rar সার্ভারে octet-stream হিসেবে ধরা পড়ে
    ];
    $ext = strtolower(pathinfo($_FILES[$fileInputName]['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowedExt)) {
        return false;
    }
    $mime = realMimeType($_FILES[$fileInputName]['tmp_name']);
    if ($mime !== null && !in_array($mime, $allowedMime)) {
        return false;
    }
    $newName = uniqid('file_', true) . '.' . $ext;
    $destination = $targetDir . '/' . $newName;
    if (move_uploaded_file($_FILES[$fileInputName]['tmp_name'], $destination)) {
        return $newName;
    }
    return false;
}

function timeAgo($datetime) {
    $time = strtotime($datetime);
    $diff = time() - $time;
    if ($diff < 60) return "এইমাত্র";
    if ($diff < 3600) return floor($diff / 60) . " মিনিট আগে";
    if ($diff < 86400) return floor($diff / 3600) . " ঘণ্টা আগে";
    return floor($diff / 86400) . " দিন আগে";
}
