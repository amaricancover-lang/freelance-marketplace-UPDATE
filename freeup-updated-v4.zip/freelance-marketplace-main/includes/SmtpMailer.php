<?php
// ============================================================
// হালকা SMTP মেইলার — কোনো এক্সটার্নাল লাইব্রেরি (PHPMailer/Composer) ছাড়াই
// সরাসরি PHP সকেট দিয়ে SMTP প্রোটোকল কথা বলে। Gmail/Brevo/Mailgun ইত্যাদির
// সাথে TLS/SSL দুটোই সাপোর্ট করে।
// ============================================================
class SmtpMailer {
    private $host, $port, $encryption, $username, $password;
    private $socket;
    private $lastError = '';

    public function __construct($host, $port, $encryption, $username, $password) {
        $this->host = $host;
        $this->port = $port;
        $this->encryption = $encryption; // 'tls' অথবা 'ssl'
        $this->username = $username;
        $this->password = $password;
    }

    public function getLastError() {
        return $this->lastError;
    }

    private function readResponse() {
        $data = '';
        while ($line = fgets($this->socket, 515)) {
            $data .= $line;
            // মাল্টি-লাইন রেসপন্সের শেষ লাইনে কোড এর পর স্পেস থাকে (হাইফেন না)
            if (isset($line[3]) && $line[3] === ' ') break;
        }
        return $data;
    }

    private function sendCommand($cmd) {
        fwrite($this->socket, $cmd . "\r\n");
        return $this->readResponse();
    }

    public function send($toEmail, $toName, $fromEmail, $fromName, $subject, $htmlBody) {
        $connectHost = ($this->encryption === 'ssl') ? "ssl://{$this->host}" : $this->host;
        $this->socket = @stream_socket_client("{$connectHost}:{$this->port}", $errno, $errstr, 15);

        if (!$this->socket) {
            $this->lastError = "SMTP সার্ভারে কানেক্ট করা যায়নি: $errstr";
            return false;
        }

        $this->readResponse(); // গ্রিটিং
        $this->sendCommand("EHLO " . ($_SERVER['HTTP_HOST'] ?? 'localhost'));

        if ($this->encryption === 'tls') {
            $this->sendCommand("STARTTLS");
            if (!stream_socket_enable_crypto($this->socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
                $this->lastError = "TLS এনক্রিপশন চালু করা যায়নি";
                return false;
            }
            $this->sendCommand("EHLO " . ($_SERVER['HTTP_HOST'] ?? 'localhost'));
        }

        $this->sendCommand("AUTH LOGIN");
        $this->sendCommand(base64_encode($this->username));
        $authResp = $this->sendCommand(base64_encode($this->password));
        if (strpos($authResp, '235') === false) {
            $this->lastError = "SMTP অথেন্টিকেশন ব্যর্থ হয়েছে — ইউজারনেম/পাসওয়ার্ড (App Password) চেক করুন";
            fclose($this->socket);
            return false;
        }

        $this->sendCommand("MAIL FROM: <{$fromEmail}>");
        $rcptResp = $this->sendCommand("RCPT TO: <{$toEmail}>");
        if (strpos($rcptResp, '250') === false) {
            $this->lastError = "গ্রহীতার ইমেইল ঠিকানা গ্রহণযোগ্য নয়";
            fclose($this->socket);
            return false;
        }

        $this->sendCommand("DATA");

        $headers = "From: {$fromName} <{$fromEmail}>\r\n";
        $headers .= "To: {$toName} <{$toEmail}>\r\n";
        $headers .= "Subject: =?UTF-8?B?" . base64_encode($subject) . "?=\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        $headers .= "Date: " . date('r') . "\r\n";

        // "." দিয়ে শুরু হওয়া লাইন এসএমটিপি প্রোটোকলে বিশেষ অর্থ বহন করে, তাই এস্কেপ করা হচ্ছে
        $body = preg_replace('/^\./m', '..', $htmlBody);

        $this->sendCommand($headers . "\r\n" . $body . "\r\n.");
        $this->sendCommand("QUIT");
        fclose($this->socket);
        return true;
    }
}
