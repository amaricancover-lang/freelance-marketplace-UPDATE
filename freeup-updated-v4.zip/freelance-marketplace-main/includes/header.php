<?php
require_once __DIR__ . '/functions.php';
$user = currentUser();
?>
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo isset($pageTitle) ? $pageTitle . ' - FreeUp' : 'FreeUp'; ?></title>
<link rel="icon" type="image/svg+xml" href="<?php echo BASE_URL; ?>assets/img/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="<?php echo BASE_URL; ?>assets/img/favicon-32.png">
<link rel="apple-touch-icon" href="<?php echo BASE_URL; ?>assets/img/apple-touch-icon.png">
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/style.css">
</head>
<body>
<header class="top-header">
  <a href="<?php echo BASE_URL; ?>index.php" class="brand-logo" aria-label="Freeup Digital">
    <span class="logo-row" aria-hidden="true">
      <span class="logo-word">free<span class="logo-up">up</span></span>
      <svg class="logo-arrow" viewBox="0 0 50 50"><path d="M8 42 L40 10"/><path d="M17 9 H41 V33"/></svg>
    </span>
    <span class="logo-digital" aria-hidden="true">digital</span>
  </a>
  <form method="GET" action="<?php echo BASE_URL; ?>gigs/browse.php" class="header-search" role="search">
    <input type="text" name="q" placeholder="সার্ভিস খুঁজুন..." value="<?php echo htmlspecialchars($_GET['q'] ?? ''); ?>" aria-label="সার্ভিস খুঁজুন">
    <button type="submit" aria-label="খুঁজুন"><svg viewBox="0 0 16 16" width="16" height="16" fill="currentColor"><path d="M15.8 14.6l-4-4a6.5 6.5 0 1 0-1.2 1.2l4 4a.85.85 0 0 0 1.2-1.2zM2 6.5a4.5 4.5 0 1 1 9 0 4.5 4.5 0 0 1-9 0z"/></svg></button>
  </form>
  <nav class="header-nav">
    <a href="<?php echo BASE_URL; ?>gigs/browse.php">গিগ ব্রাউজ</a>
    <?php if ($user): ?>
        <?php if ($user['role'] === 'developer' && $user['status'] === 'approved'): ?>
            <a href="<?php echo BASE_URL; ?>developer/dashboard.php">ড্যাশবোর্ড</a>
        <?php endif; ?>
        <?php if ($user['role'] === 'admin'): ?>
            <a href="<?php echo BASE_URL; ?>admin/dashboard.php">অ্যাডমিন প্যানেল</a>
            <a href="<?php echo BASE_URL; ?>admin/security/dashboard.php">🛡️ সিকিউরিটি</a>
            <a href="<?php echo BASE_URL; ?>admin/api.php">📱 Android API</a>
        <?php endif; ?>
        <a href="<?php echo BASE_URL; ?>messages/inbox.php">মেসেজ</a>
        <a href="<?php echo BASE_URL; ?>user/profile.php?id=<?php echo $user['id']; ?>">আমার প্রোফাইল</a>
        <a href="<?php echo BASE_URL; ?>auth/logout.php">লগআউট</a>
    <?php else: ?>
        <a href="<?php echo BASE_URL; ?>auth/register.php">সেলার হোন</a>
        <a href="<?php echo BASE_URL; ?>auth/login.php">লগইন</a>
        <a href="<?php echo BASE_URL; ?>auth/register.php" class="btn-signup">রেজিস্টার</a>
    <?php endif; ?>
  </nav>
</header>
<?php $__cats = siteCategories(); if ($__cats): ?>
<nav class="category-strip" aria-label="ক্যাটাগরি">
  <div class="category-strip-inner">
    <?php foreach ($__cats as $__c): ?>
      <a href="<?php echo BASE_URL; ?>gigs/browse.php?category=<?php echo urlencode($__c['name']); ?>"><?php echo htmlspecialchars($__c['name']); ?></a>
    <?php endforeach; ?>
  </div>
</nav>
<?php endif; ?>
<main class="page-container<?php echo !empty($homePage) ? ' is-home' : ''; ?>">
<?php
if ($msg = flash('success')): ?>
    <div class="alert alert-success"><?php echo $msg; ?></div>
<?php endif;
if ($msg = flash('error')): ?>
    <div class="alert alert-error"><?php echo $msg; ?></div>
<?php endif; ?>
