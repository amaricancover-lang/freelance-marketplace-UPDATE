-- ডাটাবেজ তৈরি
CREATE DATABASE IF NOT EXISTS freelance_marketplace CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE freelance_marketplace;

-- ইউজার টেবিল (buyer, developer, admin)
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE,
    mobile VARCHAR(20) UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('buyer','developer','admin') NOT NULL DEFAULT 'buyer',
    status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'approved',
    email_verified TINYINT(1) NOT NULL DEFAULT 0,
    is_banned TINYINT(1) NOT NULL DEFAULT 0,
    ban_reason VARCHAR(255) DEFAULT NULL,
    profile_image VARCHAR(255) DEFAULT NULL,
    bio TEXT,
    skills VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- গিগ (সার্ভিস) টেবিল
CREATE TABLE gigs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    category VARCHAR(100),
    tags VARCHAR(255),
    image VARCHAR(255) DEFAULT NULL,
    status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- গিগের প্যাকেজ (Basic, Standard, Premium) - ডেভলপার নিজের মত করে বানাতে পারবে
CREATE TABLE packages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    gig_id INT NOT NULL,
    type ENUM('basic','standard','premium') NOT NULL,
    title VARCHAR(255) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    description TEXT,
    delivery_days INT DEFAULT 3,
    revisions VARCHAR(50) DEFAULT '1',
    features TEXT COMMENT 'কমা দিয়ে আলাদা ফিচার লিস্ট',
    FOREIGN KEY (gig_id) REFERENCES gigs(id) ON DELETE CASCADE
);

-- মেসেজিং সিস্টেম (ফাইল সহ)
CREATE TABLE messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sender_id INT NOT NULL,
    receiver_id INT NOT NULL,
    message TEXT,
    file_path VARCHAR(255) DEFAULT NULL,
    is_read TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE
);

-- অর্ডার/পারচেজ টেবিল (বায়ার কোন প্যাকেজ কিনলো)
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    buyer_id INT NOT NULL,
    gig_id INT NOT NULL,
    package_id INT NOT NULL,
    status ENUM('pending','in_progress','completed','cancelled') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (buyer_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (gig_id) REFERENCES gigs(id) ON DELETE CASCADE,
    FOREIGN KEY (package_id) REFERENCES packages(id) ON DELETE CASCADE
);

-- OTP কোড (ইমেইল ভেরিফিকেশন, অ্যাডমিন 2FA, পাসওয়ার্ড রিসেট)
CREATE TABLE otp_codes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    code VARCHAR(10) NOT NULL,
    purpose ENUM('email_verify','2fa_login','password_reset') NOT NULL,
    request_ip VARCHAR(45) DEFAULT NULL COMMENT 'কোড রিকোয়েস্ট করার সময়ের IP — ভেরিফাইয়ের সময় মেলানো হয় (password_reset এর জন্য)',
    expires_at DATETIME NOT NULL,
    used TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- IP-বেজড লগইন অ্যাটেম্পট ট্র্যাকিং (কুকি/সেশন ক্লিয়ার করলেও এড়ানো যায় না)
CREATE TABLE login_attempts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ip_address VARCHAR(45) NOT NULL,
    identity VARCHAR(150) DEFAULT NULL COMMENT 'কোন ইমেইল/মোবাইল দিয়ে লগইন চেষ্টা হয়েছিল',
    attempted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_ip_time (ip_address, attempted_at),
    INDEX idx_identity_time (identity, attempted_at)
);

-- ============ সিকিউরিটি অ্যাডমিন প্যানেলের টেবিলসমূহ ============

-- ব্লক করা IP ঠিকানা (ম্যানুয়াল বা অটো-ব্লক)
CREATE TABLE blocked_ips (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ip_address VARCHAR(45) NOT NULL UNIQUE,
    reason VARCHAR(255) DEFAULT NULL,
    blocked_by ENUM('auto','admin') NOT NULL DEFAULT 'admin',
    blocked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- অ্যাক্টিভিটি/অডিট লগ — কে কখন কী করলো
CREATE TABLE activity_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT DEFAULT NULL,
    action VARCHAR(100) NOT NULL,
    details VARCHAR(255) DEFAULT NULL,
    ip_address VARCHAR(45) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_created (created_at),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- IP অনুযায়ী রেজিস্ট্রেশন ট্র্যাকিং — একই IP থেকে বারবার একাউন্ট খোলা ঠেকাতে
CREATE TABLE registration_attempts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ip_address VARCHAR(45) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_ip_time (ip_address, created_at)
);

-- সাধারণ রেট-লিমিট টেবিল — রেজিস্ট্রেশন ছাড়া অন্য অ্যাকশনের জন্য পুনর্ব্যবহারযোগ্য
-- (ফরগট পাসওয়ার্ড, মেসেজ পাঠানো, অর্ডার দেওয়া ইত্যাদি)
CREATE TABLE rate_limits (
    id INT AUTO_INCREMENT PRIMARY KEY,
    action VARCHAR(50) NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_action_ip_time (action, ip_address, created_at)
);

-- ============ Android অ্যাপের REST API এর টেবিলসমূহ ============

-- সাইটের সাধারণ সেটিংস (যেমন: API চালু/বন্ধ) — অ্যাডমিন > Android API পেজ থেকে বদলানো যায়
CREATE TABLE IF NOT EXISTS settings (
    setting_key VARCHAR(50) PRIMARY KEY,
    setting_value VARCHAR(255) NOT NULL
);
INSERT IGNORE INTO settings (setting_key, setting_value) VALUES ('api_enabled', '1');

-- অ্যাপের লগইন টোকেন (আসল টোকেন সেভ হয় না, শুধু SHA-256 হ্যাশ সেভ হয়)
CREATE TABLE IF NOT EXISTS api_tokens (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    token_hash CHAR(64) NOT NULL UNIQUE,
    device_name VARCHAR(100) DEFAULT NULL,
    ip_address VARCHAR(45) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_used_at DATETIME DEFAULT NULL,
    expires_at DATETIME NOT NULL,
    revoked TINYINT(1) NOT NULL DEFAULT 0,
    INDEX idx_user (user_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- অ্যাডমিন একাউন্ট তৈরি করার জন্য setup_admin.php ফাইলটি ব্রাউজারে একবার রান করুন (নিরাপদ bcrypt hash সহ)
