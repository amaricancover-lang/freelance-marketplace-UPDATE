<?php
require_once __DIR__ . '/../includes/functions.php';
requireLogin();
$myId = $_SESSION['user_id'];
$otherId = (int)($_GET['to'] ?? 0);

$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $otherId);
$stmt->execute();
$other = $stmt->get_result()->fetch_assoc();
if (!$other || $otherId === $myId) { flash('error', 'ইউজার পাওয়া যায়নি।'); redirect('messages/inbox.php'); }

// টেক্সট মেসেজ পাঠানো (ফাইল সহ)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    if (!checkRateLimit('chat_message', 30, 300)) {
        flash('error', 'অনেকগুলো মেসেজ দ্রুত পাঠানো হয়েছে। কিছুক্ষণ অপেক্ষা করুন।');
        redirect('messages/chat.php?to=' . $otherId);
    }
    $text = clean($_POST['message'] ?? '');
    $filePath = null;
    if (!empty($_FILES['attachment']['name'])) {
        $uploaded = uploadChatFile('attachment', __DIR__ . '/../assets/uploads/chat');
        if ($uploaded) $filePath = $uploaded;
    }
    if ($text !== '' || $filePath) {
        $stmt = $conn->prepare("INSERT INTO messages (sender_id, receiver_id, message, file_path) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("iiss", $myId, $otherId, $text, $filePath);
        $stmt->execute();

        // রিসিভারকে ইমেইলে জানানো হচ্ছে (নোট: প্রোডাকশনে চাইলে রিসিভার অনলাইন থাকলে স্কিপ/থ্রটল করা যায়)
        if ($other['email']) {
            $preview = $text !== '' ? $text : '📎 একটি ফাইল পাঠানো হয়েছে';
            sendNewMessageEmail($other['email'], $other['name'], $_SESSION['name'], $preview);
        }
    }
    redirect('messages/chat.php?to=' . $otherId);
}

// দুজনের মধ্যে সব মেসেজ
$stmt = $conn->prepare("SELECT * FROM messages WHERE (sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?) ORDER BY created_at ASC");
$stmt->bind_param("iiii", $myId, $otherId, $otherId, $myId);
$stmt->execute();
$msgs = $stmt->get_result();

// রিড মার্ক করা
$conn->query("UPDATE messages SET is_read = 1 WHERE sender_id = $otherId AND receiver_id = $myId");

$pageTitle = "চ্যাট - " . $other['name'];
require_once __DIR__ . '/../includes/header.php';
?>
<div class="chat-window">
    <div class="chat-header">
        <div class="chat-avatar-sm"><?php echo strtoupper(substr($other['name'],0,1)); ?></div>
        <strong><?php echo htmlspecialchars($other['name']); ?></strong>
    </div>

    <div class="chat-messages">
        <?php while ($m = $msgs->fetch_assoc()):
            $isMine = $m['sender_id'] == $myId; ?>
            <div class="chat-bubble <?php echo $isMine ? 'mine' : 'theirs'; ?>">
                <?php if ($m['message']): ?><p><?php echo nl2br(htmlspecialchars($m['message'])); ?></p><?php endif; ?>
                <?php if ($m['file_path']):
                    $ext = strtolower(pathinfo($m['file_path'], PATHINFO_EXTENSION));
                    $isImg = in_array($ext, ['jpg','jpeg','png','webp','gif']); ?>
                    <?php if ($isImg): ?>
                        <a href="<?php echo BASE_URL; ?>assets/uploads/chat/<?php echo $m['file_path']; ?>" target="_blank">
                            <img src="<?php echo BASE_URL; ?>assets/uploads/chat/<?php echo $m['file_path']; ?>" class="chat-img">
                        </a>
                    <?php else: ?>
                        <a href="<?php echo BASE_URL; ?>assets/uploads/chat/<?php echo $m['file_path']; ?>" target="_blank" class="chat-file-link">📎 ফাইল ডাউনলোড করুন</a>
                    <?php endif; ?>
                <?php endif; ?>
                <span class="chat-time"><?php echo timeAgo($m['created_at']); ?></span>
            </div>
        <?php endwhile; ?>
    </div>

    <form method="POST" enctype="multipart/form-data" class="chat-input-row">
        <?php echo csrfField(); ?>
        <input type="text" name="message" placeholder="মেসেজ লিখুন..." autocomplete="off">
        <label class="attach-btn">
            📎
            <input type="file" name="attachment" id="chat-attachment" style="display:none;">
        </label>
        <span class="file-name-preview"></span>
        <button type="submit" class="btn-primary">পাঠান</button>
    </form>
</div>

<script nonce="<?php echo cspNonce(); ?>">
document.getElementById('chat-attachment').addEventListener('change', function() {
    document.querySelector('.file-name-preview').textContent = this.files[0]?.name || '';
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
