<?php
require_once __DIR__ . '/../includes/functions.php';
requireLogin();
$myId = $_SESSION['user_id'];

// যাদের সাথে কথা হয়েছে তাদের লিস্ট বের করা
$sql = "SELECT u.id, u.name, u.role, u.profile_image,
        (SELECT message FROM messages m2 WHERE (m2.sender_id=u.id AND m2.receiver_id=?) OR (m2.sender_id=? AND m2.receiver_id=u.id) ORDER BY m2.created_at DESC LIMIT 1) AS last_message,
        (SELECT created_at FROM messages m3 WHERE (m3.sender_id=u.id AND m3.receiver_id=?) OR (m3.sender_id=? AND m3.receiver_id=u.id) ORDER BY m3.created_at DESC LIMIT 1) AS last_time
        FROM users u
        WHERE u.id IN (
            SELECT sender_id FROM messages WHERE receiver_id = ?
            UNION
            SELECT receiver_id FROM messages WHERE sender_id = ?
        )
        ORDER BY last_time DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("iiiiii", $myId, $myId, $myId, $myId, $myId, $myId);
$stmt->execute();
$conversations = $stmt->get_result();

$pageTitle = "মেসেজ ইনবক্স";
require_once __DIR__ . '/../includes/header.php';
?>
<h2>ইনবক্স</h2>
<div class="conversation-list">
<?php if ($conversations->num_rows === 0): ?>
    <p>এখনো কোনো কথোপকথন নেই। কোনো গিগ বা প্রোফাইল থেকে "মেসেজ পাঠান" বাটনে ক্লিক করুন।</p>
<?php endif; ?>
<?php while ($c = $conversations->fetch_assoc()): ?>
    <a href="chat.php?to=<?php echo $c['id']; ?>" class="conversation-item">
        <div class="chat-avatar-sm"><?php echo strtoupper(substr($c['name'],0,1)); ?></div>
        <div class="conv-info">
            <strong><?php echo htmlspecialchars($c['name']); ?></strong>
            <p><?php echo htmlspecialchars(mb_strimwidth($c['last_message'] ?? '(ফাইল পাঠানো হয়েছে)', 0, 50, '...')); ?></p>
        </div>
    </a>
<?php endwhile; ?>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
