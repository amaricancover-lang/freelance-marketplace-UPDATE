<?php
// Show the splash screen once per visit (cookie set by splash.html)
if ($_SERVER['REQUEST_METHOD'] === 'GET' && empty($_COOKIE['freeup_splash']) && empty($_GET['nosplash'])) {
    header('Location: splash.html');
    exit;
}
require_once __DIR__ . '/includes/functions.php';

$categories = siteCategories();

$latestGigs = $conn->query("SELECT g.*, u.name AS seller_name,
    (SELECT MIN(price) FROM packages WHERE gig_id = g.id) AS starting_price
    FROM gigs g JOIN users u ON g.user_id = u.id
    WHERE g.status = 'approved' ORDER BY g.created_at DESC, g.id DESC LIMIT 12");

// ক্যাটাগরি আইকন (লাইন-আইকন, currentColor ব্যবহার করে)
$catSvg = [
    'Web Design'       => '<rect x="5" y="8" width="30" height="24" rx="4"/><path d="M5 15h30"/><circle cx="10" cy="11.5" r="1" fill="currentColor"/><circle cx="14" cy="11.5" r="1" fill="currentColor"/><path d="M11 24h8M11 28h14"/>',
    'App Development'  => '<rect x="11" y="4" width="18" height="32" rx="4"/><path d="M17 8h6"/><circle cx="20" cy="31" r="1.6" fill="currentColor"/><path d="M16 17l-3 3 3 3M24 17l3 3-3 3"/>',
    'Graphic Design'   => '<path d="M20 5c8 0 15 5 15 12 0 4-3 6-7 6h-3c-2 0-3 2-2 4 1 2 0 5-3 5C11 32 5 27 5 20 5 12 11 5 20 5z"/><circle cx="12" cy="18" r="1.8" fill="currentColor"/><circle cx="18" cy="12" r="1.8" fill="currentColor"/><circle cx="26" cy="13" r="1.8" fill="currentColor"/>',
    'Content Writing'  => '<path d="M8 6h16l8 8v20H8z"/><path d="M24 6v8h8M13 21h14M13 26h14M13 31h8"/>',
    'SEO Marketing'    => '<path d="M5 31l9-10 7 5 13-16"/><path d="M26 10h8v8"/><path d="M5 35h30"/>',
    'Voice Over'       => '<rect x="14" y="4" width="12" height="20" rx="6"/><path d="M8 19c0 7 5 12 12 12s12-5 12-12M20 31v5M14 36h12"/>',
    'Video Editing'    => '<rect x="4" y="9" width="32" height="22" rx="4"/><path d="M17 15l8 5-8 5z" fill="currentColor"/>',
    'Data Entry'       => '<rect x="5" y="7" width="30" height="26" rx="3"/><path d="M5 15h30M5 23h30M15 7v26M25 7v26"/>',
];

// জনপ্রিয় সার্ভিস (কার্ডে ক্লিক করলে সার্চ/ক্যাটাগরি পেজে যাবে)
$popular = [
    ['ওয়েবসাইট ডেভেলপমেন্ট', 'q=' . urlencode('ওয়েবসাইট'),         '#0f5d3b', '#1dbf73', 'Web Design'],
    ['লোগো ডিজাইন',          'q=' . urlencode('লোগো'),             '#7a1d4f', '#ec4899', 'Graphic Design'],
    ['ভিডিও এডিটিং',          'category=' . urlencode('Video Editing'), '#3b2a8f', '#8b7bff', 'Video Editing'],
    ['মোবাইল অ্যাপ',           'category=' . urlencode('App Development'), '#0a4a66', '#22b8e0', 'App Development'],
    ['ওয়ার্ডপ্রেস',            'q=' . urlencode('ওয়ার্ডপ্রেস'),       '#1d3a8a', '#4f8bff', 'Web Design'],
    ['কনটেন্ট রাইটিং',         'category=' . urlencode('Content Writing'), '#7a3b08', '#ff9a3c', 'Content Writing'],
    ['এসইও',                  'category=' . urlencode('SEO Marketing'), '#134e2a', '#7ddc5c', 'SEO Marketing'],
    ['ভয়েস ওভার',            'category=' . urlencode('Voice Over'),   '#5a1a6e', '#c77dff', 'Voice Over'],
    ['সোশ্যাল মিডিয়া মার্কেটিং', 'q=' . urlencode('সোশ্যাল মিডিয়া'),   '#7a1414', '#ff6b6b', 'SEO Marketing'],
    ['ইউআই/ইউএক্স ডিজাইন',    'q=' . urlencode('ইউআই'),             '#14456b', '#38bdf8', 'Graphic Design'],
    ['এআই ডেভেলপমেন্ট',       'q=' . urlencode('এআই'),              '#2a2a3d', '#a78bfa', 'App Development'],
    ['ডাটা এন্ট্রি',            'category=' . urlencode('Data Entry'),   '#0f5555', '#2dd4bf', 'Data Entry'],
];

$pageTitle = "হোম";
$homePage = true;
require_once __DIR__ . '/includes/header.php';

$B = BASE_URL;
$iconSearch = '<svg viewBox="0 0 16 16" width="18" height="18" fill="currentColor" aria-hidden="true"><path d="M15.8 14.6l-4-4a6.5 6.5 0 1 0-1.2 1.2l4 4a.85.85 0 0 0 1.2-1.2zM2 6.5a4.5 4.5 0 1 1 9 0 4.5 4.5 0 0 1-9 0z"/></svg>';
$iconCheck = '<svg viewBox="0 0 16 16" width="16" height="16" fill="currentColor" aria-hidden="true"><path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0zm3.7 6.2-4.4 4.6a.8.8 0 0 1-1.1 0L4.3 9a.8.8 0 1 1 1.1-1.1l1.3 1.3 3.9-4.1a.8.8 0 1 1 1.1 1.1z"/></svg>';
?>

<!-- ============ HERO ============ -->
<section class="fx-hero">
  <div class="fx-hero-inner">
    <div class="fx-hero-copy">
      <h1>আমাদের ফ্রিল্যান্সাররা <em>বাকিটা সামলে নেবে</em></h1>
      <form method="GET" action="<?php echo $B; ?>gigs/browse.php" class="fx-hero-search" role="search">
        <span class="fx-hero-search-ico"><?php echo $iconSearch; ?></span>
        <input type="text" name="q" placeholder="যেকোনো সার্ভিস খুঁজুন..." aria-label="সার্ভিস খুঁজুন" autocomplete="off">
        <button type="submit" aria-label="খুঁজুন"><?php echo $iconSearch; ?></button>
      </form>
      <div class="fx-hero-pills">
        <a href="<?php echo $B; ?>gigs/browse.php?q=<?php echo urlencode('ওয়েবসাইট'); ?>"><span class="fx-pill-ico">💻</span>ওয়েবসাইট ডেভেলপমেন্ট</a>
        <a href="<?php echo $B; ?>gigs/browse.php?category=<?php echo urlencode('App Development'); ?>"><span class="fx-pill-ico">📱</span>অ্যাপ ডেভেলপমেন্ট</a>
        <a href="<?php echo $B; ?>gigs/browse.php?category=<?php echo urlencode('Video Editing'); ?>"><span class="fx-pill-ico">🎬</span>ভিডিও এডিটিং</a>
        <a href="<?php echo $B; ?>gigs/browse.php?q=<?php echo urlencode('এআই'); ?>"><span class="fx-pill-ico">🤖</span>এআই অটোমেশন</a>
        <a href="<?php echo $B; ?>gigs/browse.php?q=<?php echo urlencode('লোগো'); ?>"><span class="fx-pill-ico">🎨</span>লোগো ডিজাইন</a>
      </div>
      <div class="fx-trust">
        <span class="fx-trust-label">নিশ্চিন্তে কাজ করুন:</span>
        <span class="fx-trust-item"><?php echo $iconCheck; ?> অ্যাডমিন-অ্যাপ্রুভড সেলার</span>
        <span class="fx-trust-item"><?php echo $iconCheck; ?> ইমেইল OTP ভেরিফিকেশন</span>
        <span class="fx-trust-item"><?php echo $iconCheck; ?> সরাসরি চ্যাট ও ফাইল শেয়ার</span>
      </div>
    </div>
    <div class="fx-hero-art" aria-hidden="true">
      <img src="<?php echo $B; ?>assets/img/home/hero-art.svg" alt="">
    </div>
  </div>
</section>

<!-- ============ ক্যাটাগরি রো ============ -->
<section class="fx-wrap fx-catrow-wrap">
  <div class="fx-catrow">
    <?php foreach ($categories as $cat): ?>
      <a href="<?php echo $B; ?>gigs/browse.php?category=<?php echo urlencode($cat['name']); ?>" class="fx-catitem">
        <svg viewBox="0 0 40 40" width="40" height="40" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><?php echo $catSvg[$cat['name']] ?? '<circle cx="20" cy="20" r="13"/>'; ?></svg>
        <span><?php echo htmlspecialchars($cat['name']); ?></span>
      </a>
    <?php endforeach; ?>
  </div>
</section>

<!-- ============ জনপ্রিয় সার্ভিস ============ -->
<section class="fx-wrap fx-section">
  <div class="fx-section-head">
    <h2>জনপ্রিয় সার্ভিস</h2>
    <div class="fx-arrows">
      <button type="button" class="fx-arrow" data-dir="-1" aria-label="আগের">‹</button>
      <button type="button" class="fx-arrow" data-dir="1" aria-label="পরের">›</button>
    </div>
  </div>
  <div class="fx-carousel" id="fxPopular">
    <?php foreach ($popular as $p): $icon = $catSvg[$p[4]] ?? ''; ?>
      <a href="<?php echo $B; ?>gigs/browse.php?<?php echo $p[1]; ?>" class="fx-pop" style="--c1:<?php echo $p[2]; ?>;--c2:<?php echo $p[3]; ?>">
        <h3><?php echo htmlspecialchars($p[0]); ?></h3>
        <svg class="fx-pop-ico" viewBox="0 0 40 40" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><?php echo $icon; ?></svg>
      </a>
    <?php endforeach; ?>
  </div>
</section>

<!-- ============ সাম্প্রতিক গিগসমূহ ============ -->
<section class="fx-wrap fx-section">
  <div class="fx-section-head">
    <h2>সাম্প্রতিক গিগসমূহ</h2>
    <a href="<?php echo $B; ?>gigs/browse.php" class="fx-see-all">সব দেখুন →</a>
  </div>
  <div class="fx-gig-grid">
    <?php if ($latestGigs->num_rows === 0): ?>
      <p class="fx-empty">এখনো কোনো গিগ পাবলিশ হয়নি।</p>
    <?php endif; ?>
    <?php while ($g = $latestGigs->fetch_assoc()): ?>
      <a href="<?php echo $B; ?>gigs/gig_detail.php?id=<?php echo (int)$g['id']; ?>" class="fx-gig">
        <div class="fx-gig-media">
          <?php if ($g['image']): ?>
            <img src="<?php echo $B; ?>assets/uploads/gigs/<?php echo htmlspecialchars($g['image']); ?>" alt="" loading="lazy">
          <?php else: ?>
            <div class="no-image">কোনো ছবি নেই</div>
          <?php endif; ?>
          <?php if (!empty($g['category'])): ?><span class="fx-gig-cat"><?php echo htmlspecialchars($g['category']); ?></span><?php endif; ?>
        </div>
        <div class="fx-gig-seller">
          <span class="fx-avatar"><?php echo htmlspecialchars(preg_match('/./u', $g['seller_name'], $__m) ? mb_strtoupper($__m[0]) : '?'); ?></span>
          <strong><?php echo htmlspecialchars($g['seller_name']); ?></strong>
        </div>
        <h4><?php echo htmlspecialchars($g['title']); ?></h4>
        <div class="fx-gig-price">শুরু <b><?php echo $g['starting_price'] ? '$' . number_format($g['starting_price'], 0) : 'N/A'; ?></b></div>
      </a>
    <?php endwhile; ?>
  </div>
</section>

<!-- ============ ফ্রিল্যান্সারদের দিয়ে সবকিছু সম্ভব করুন ============ -->
<section class="fx-wrap fx-section">
  <div class="fx-green">
    <div class="fx-green-copy">
      <h2>ফ্রিল্যান্সারদের দিয়ে সবকিছু সম্ভব করুন</h2>
      <ul class="fx-benefits">
        <li><span class="fx-b-ico"><svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6"/><circle cx="17.5" cy="9" r="2.5"/><path d="M17 14.2c2.6.2 4.5 2 4.5 4.8"/></svg></span><div><b>শত শত ক্যাটাগরিতে দক্ষ ফ্রিল্যান্সার</b><span>সব ধরনের কাজের জন্য এক জায়গায় সেরা ট্যালেন্ট</span></div></li>
        <li><span class="fx-b-ico"><svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12a8 8 0 0 1 14-5.3M20 12a8 8 0 0 1-14 5.3"/><path d="M18 3v4h-4M6 21v-4h4"/></svg></span><div><b>সহজ ও দ্রুত ম্যাচিং অভিজ্ঞতা</b><span>সার্চ করুন, প্যাকেজ তুলনা করুন, সরাসরি চ্যাট করুন</span></div></li>
        <li><span class="fx-b-ico"><svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="6" width="18" height="13" rx="3"/><path d="M3 10h18M7 15h4"/></svg></span><div><b>বাজেটের মধ্যে মানসম্মত কাজ</b><span>Basic, Standard ও Premium — নিজের বাজেট অনুযায়ী বেছে নিন</span></div></li>
        <li><span class="fx-b-ico"><svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6z"/><path d="M8.5 12l2.5 2.5 4.5-5"/></svg></span><div><b>সন্তুষ্ট হলেই কেবল পেমেন্ট করুন</b><span>নিশ্চিন্তে কাজ বুঝে নিন</span></div></li>
      </ul>
      <?php if (!isLoggedIn()): ?>
        <a href="<?php echo $B; ?>auth/register.php" class="fx-btn fx-btn-green">এখনই জয়েন করুন</a>
      <?php else: ?>
        <a href="<?php echo $B; ?>gigs/browse.php" class="fx-btn fx-btn-green">গিগ ব্রাউজ করুন</a>
      <?php endif; ?>
    </div>
    <div class="fx-green-art" aria-hidden="true"><img src="<?php echo $B; ?>assets/img/home/team-art.svg" alt=""></div>
  </div>
</section>

<!-- ============ সঠিক ফ্রিল্যান্সার খুঁজে নিন ============ -->
<section class="fx-wrap fx-section">
  <div class="fx-split">
    <div class="fx-split-art" aria-hidden="true"><img src="<?php echo $B; ?>assets/img/home/experts-art.svg" alt=""></div>
    <div class="fx-split-copy">
      <h2>আপনার জন্য সঠিক ফ্রিল্যান্সার খুঁজে নিন</h2>
      <ul class="fx-checks">
        <li><?php echo $iconCheck; ?> সেলারের গিগ, প্যাকেজ ও ডেলিভারি সময় পাশাপাশি দেখুন</li>
        <li><?php echo $iconCheck; ?> অর্ডারের আগেই সেলারের সাথে সরাসরি চ্যাট করে সব পরিষ্কার করে নিন</li>
        <li><?php echo $iconCheck; ?> অ্যাডমিন যাচাই করা সেলারদের কাছ থেকেই সার্ভিস নিন</li>
      </ul>
      <a href="<?php echo $B; ?>gigs/browse.php" class="fx-btn fx-btn-dark">সব সার্ভিস দেখুন</a>
    </div>
  </div>
</section>

<!-- ============ এআই ব্যানার ============ -->
<section class="fx-wrap fx-section">
  <div class="fx-ai">
    <div class="fx-ai-copy">
      <h2>এআই এক্সপার্টদের দিয়ে আপনার ব্যবসা অটোমেট করুন</h2>
      <p>বুকিং সিস্টেম হোক বা লিড ম্যানেজমেন্ট — চ্যাটবট ও অটোমেশন বানাতে অভিজ্ঞ ফ্রিল্যান্সারদের পাশে পান, শুরু থেকে শেষ পর্যন্ত।</p>
      <a href="<?php echo $B; ?>gigs/browse.php?q=<?php echo urlencode('এআই'); ?>" class="fx-btn fx-btn-light">এআই এক্সপার্ট খুঁজুন</a>
    </div>
    <div class="fx-ai-art" aria-hidden="true">
      <span class="fx-ai-chip c1">🤖 চ্যাটবট</span><span class="fx-ai-chip c2">⚙️ অটোমেশন</span><span class="fx-ai-chip c3">📈 লিড</span><span class="fx-ai-chip c4">💬 সাপোর্ট</span>
    </div>
  </div>
</section>

<!-- ============ গাইড ============ -->
<section class="fx-wrap fx-section">
  <div class="fx-section-head"><h2>ব্যবসা বড় করার গাইড</h2></div>
  <div class="fx-guides">
    <a class="fx-guide" style="--c1:#0f5d3b;--c2:#1dbf73" href="<?php echo $B; ?>gigs/browse.php?category=<?php echo urlencode('Web Design'); ?>"><div class="fx-guide-tile">💻</div><h3>ব্যবসার জন্য ওয়েবসাইট বানান</h3><span>ওয়েব ডিজাইন →</span></a>
    <a class="fx-guide" style="--c1:#7a1d4f;--c2:#ec4899" href="<?php echo $B; ?>gigs/browse.php?q=<?php echo urlencode('লোগো'); ?>"><div class="fx-guide-tile">🎨</div><h3>প্রফেশনাল লোগো তৈরি করুন</h3><span>লোগো ডিজাইন →</span></a>
    <a class="fx-guide" style="--c1:#3b2a8f;--c2:#8b7bff" href="<?php echo $B; ?>gigs/browse.php?category=<?php echo urlencode('Video Editing'); ?>"><div class="fx-guide-tile">🎬</div><h3>ভিডিও দিয়ে ব্র্যান্ড গড়ুন</h3><span>ভিডিও এডিটিং →</span></a>
    <a class="fx-guide" style="--c1:#134e2a;--c2:#7ddc5c" href="<?php echo $B; ?>gigs/browse.php?category=<?php echo urlencode('SEO Marketing'); ?>"><div class="fx-guide-tile">🚀</div><h3>এসইও দিয়ে গুগলে এগিয়ে যান</h3><span>এসইও মার্কেটিং →</span></a>
    <a class="fx-guide" style="--c1:#2a2a3d;--c2:#a78bfa" href="<?php echo $B; ?>gigs/browse.php?q=<?php echo urlencode('এআই'); ?>"><div class="fx-guide-tile">🤖</div><h3>এআই দিয়ে ব্যবসা বাড়ান</h3><span>এআই সার্ভিস →</span></a>
  </div>
</section>

<!-- ============ ফাইনাল CTA ============ -->
<section class="fx-wrap fx-section fx-section-last">
  <div class="fx-final">
    <h2>আপনার হাতের মুঠোয় <em>ফ্রিল্যান্স সার্ভিস</em></h2>
    <?php if (!isLoggedIn()): ?>
      <a href="<?php echo $B; ?>auth/register.php" class="fx-btn fx-btn-green">FreeUp-এ জয়েন করুন</a>
    <?php else: ?>
      <a href="<?php echo $B; ?>gigs/browse.php" class="fx-btn fx-btn-green">গিগ ব্রাউজ করুন</a>
    <?php endif; ?>
  </div>
</section>

<script nonce="<?php echo cspNonce(); ?>">
(function () {
  var c = document.getElementById('fxPopular');
  if (!c) return;
  document.querySelectorAll('.fx-arrow').forEach(function (b) {
    b.addEventListener('click', function () {
      c.scrollBy({ left: parseInt(b.dataset.dir, 10) * (c.clientWidth * 0.8), behavior: 'smooth' });
    });
  });
})();
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
