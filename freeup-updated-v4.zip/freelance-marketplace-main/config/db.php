<?php
// ডাটাবেজ কানেকশন কনফিগারেশন
// আপনার হোস্টিং অনুযায়ী নিচের তথ্য পরিবর্তন করুন
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'freelance_marketplace');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    die("ডাটাবেজ কানেকশন ব্যর্থ হয়েছে: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");

// সাইটের বেস URL — ফোল্ডারের নাম যা-ই হোক (freelance-marketplace বা freelance-marketplace-main), নিজে থেকে বের করে নেয়।
// সার্ভারের ডকুমেন্ট রুট থেকে প্রজেক্ট ফোল্ডারের পাথ কেটে বের করা হয়।
// অটো-ডিটেক্ট কাজ না করলে নিচের $fallbackBase এ নিজের ফোল্ডারের নাম লিখুন।
$fallbackBase = '/freelance-marketplace/';
$docRoot = isset($_SERVER['DOCUMENT_ROOT']) ? rtrim(str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']), '/') : '';
$projectDir = str_replace('\\', '/', (string) realpath(__DIR__ . '/..'));
if ($docRoot !== '' && $projectDir !== '' && stripos($projectDir, $docRoot) === 0) {
    $rel = trim(substr($projectDir, strlen($docRoot)), '/');
    define('BASE_URL', $rel === '' ? '/' : '/' . $rel . '/');
} else {
    define('BASE_URL', $fallbackBase);
}
