<?php
// ============================================================
// SMTP মেইল কনফিগারেশন
// এখানে আপনার SMTP তথ্য বসান (Gmail, Brevo, Mailgun ইত্যাদি)
// ============================================================

// SMTP_ENABLED = false রাখলে সিস্টেম PHP এর বিল্ট-ইন mail() ফাংশন ব্যবহার করবে (লোকালে সাধারণত কাজ করে না)
// SMTP_ENABLED = true করে নিচের তথ্য পূরণ করলে রিলায়েবল ইমেইল ডেলিভারি হবে
define('SMTP_ENABLED', false);

define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);              // Gmail এর জন্য 587 (TLS)
define('SMTP_ENCRYPTION', 'tls');      // 'tls' অথবা 'ssl'
define('SMTP_USERNAME', 'your-email@gmail.com');
define('SMTP_PASSWORD', 'your-16-digit-app-password'); // Gmail এর নরমাল পাসওয়ার্ড না — App Password লাগবে

define('MAIL_FROM_EMAIL', 'your-email@gmail.com');
define('MAIL_FROM_NAME', 'FreeUp');

// ============================================================
// Gmail App Password কীভাবে বানাবেন:
// ১. https://myaccount.google.com/security এ যান
// ২. "2-Step Verification" চালু করুন (না থাকলে)
// ৩. "App passwords" এ গিয়ে নতুন একটি App Password জেনারেট করুন (নাম দিন যা খুশি, যেমন "Marketplace")
// ৪. জেনারেট হওয়া ১৬-ডিজিট কোডটি উপরে SMTP_PASSWORD এ বসান (স্পেস ছাড়া)
// ============================================================
