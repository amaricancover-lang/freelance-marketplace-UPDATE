-- ============================================================
-- Android API আপডেট — যাদের ডাটাবেজ আগেই ইমপোর্ট করা আছে, শুধু তারা এটি রান করবেন।
-- (নতুন করে database.sql ইমপোর্ট করলে এটি লাগবে না, ওটাতেই এই টেবিল দুটো আছে)
--
-- ব্যবহার: phpMyAdmin > বাঁ দিকে freelance_marketplace ডাটাবেজ সিলেক্ট করুন > Import ট্যাব > এই ফাইল দিন।
-- আগের কোনো ডাটা মুছবে না।
-- ============================================================
USE freelance_marketplace;

CREATE TABLE IF NOT EXISTS settings (
    setting_key VARCHAR(50) PRIMARY KEY,
    setting_value VARCHAR(255) NOT NULL
);
INSERT IGNORE INTO settings (setting_key, setting_value) VALUES ('api_enabled', '1');

CREATE TABLE IF NOT EXISTS api_tokens (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    token_hash CHAR(64) NOT NULL UNIQUE,
    device_name VARCHAR(100) DEFAULT NULL,
    ip_address VARCHAR(45) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_used_at DATETIME DEFAULT NULL,
    expires_at DATETIME NOT NULL,
    revoked TINYINT(1) NOT NULL DEFAULT 0,
    INDEX idx_user (user_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
