<?php
require_once __DIR__ . '/../includes/functions.php';
requireRole('developer');
$user = currentUser();
if ($user['status'] !== 'approved') redirect('index.php');

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $title = clean($_POST['title'] ?? '');
    $description = clean($_POST['description'] ?? '');
    $category = clean($_POST['category'] ?? '');
    $tags = clean($_POST['tags'] ?? '');

    if ($title === '') $errors[] = "গিগের টাইটেল দিন";
    if ($description === '') $errors[] = "ডেসক্রিপশন দিন";

    $imageName = null;
    if (!empty($_FILES['gig_image']['name'])) {
        $imageName = uploadImage('gig_image', __DIR__ . '/../assets/uploads/gigs');
        if ($imageName === false) $errors[] = "শুধু jpg, jpeg, png, webp, gif ছবি আপলোড করা যাবে";
    }

    // প্যাকেজ ভ্যালিডেশন - কমপক্ষে Basic প্যাকেজ থাকতেই হবে
    $packageTypes = ['basic', 'standard', 'premium'];
    $packagesData = [];
    foreach ($packageTypes as $type) {
        $pTitle = clean($_POST["{$type}_title"] ?? '');
        $pPrice = $_POST["{$type}_price"] ?? '';
        if ($type === 'basic' && ($pTitle === '' || $pPrice === '')) {
            $errors[] = "Basic প্যাকেজের টাইটেল ও মূল্য অবশ্যই দিতে হবে";
        }
        if ($pTitle !== '' && $pPrice !== '') {
            $packagesData[$type] = [
                'title' => $pTitle,
                'price' => (float)$pPrice,
                'desc' => clean($_POST["{$type}_desc"] ?? ''),
                'delivery' => (int)($_POST["{$type}_delivery"] ?? 3),
                'revisions' => clean($_POST["{$type}_revisions"] ?? '1'),
                'features' => clean($_POST["{$type}_features"] ?? ''),
            ];
        }
    }

    if (empty($errors)) {
        $stmt = $conn->prepare("INSERT INTO gigs (user_id, title, description, category, tags, image, status) VALUES (?, ?, ?, ?, ?, ?, 'pending')");
        $stmt->bind_param("isssss", $user['id'], $title, $description, $category, $tags, $imageName);
        $stmt->execute();
        $gigId = $conn->insert_id;

        foreach ($packagesData as $type => $p) {
            $ins = $conn->prepare("INSERT INTO packages (gig_id, type, title, price, description, delivery_days, revisions, features) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $ins->bind_param("issdsiss", $gigId, $type, $p['title'], $p['price'], $p['desc'], $p['delivery'], $p['revisions'], $p['features']);
            $ins->execute();
        }

        flash('success', "গিগ সাবমিট করা হয়েছে! অ্যাডমিন অ্যাপ্রুভ করলেই এটি পাবলিক হবে।");
        redirect('developer/dashboard.php');
    }
}

$pageTitle = "নতুন গিগ যোগ করুন";
require_once __DIR__ . '/../includes/header.php';
?>
<h2>নতুন গিগ তৈরি করুন</h2>

<?php if (!empty($errors)): ?>
    <div class="alert alert-error"><ul><?php foreach ($errors as $e) echo "<li>$e</li>"; ?></ul></div>
<?php endif; ?>

<form method="POST" enctype="multipart/form-data" class="app-form gig-form">
    <?php echo csrfField(); ?>
    <label>গিগ টাইটেল</label>
    <input type="text" name="title" required value="<?php echo htmlspecialchars($_POST['title'] ?? ''); ?>" placeholder="যেমন: আমি আপনার জন্য প্রফেশনাল ওয়েবসাইট বানিয়ে দেব">

    <label>ক্যাটাগরি</label>
    <input type="text" name="category" value="<?php echo htmlspecialchars($_POST['category'] ?? ''); ?>" placeholder="যেমন: Web Development">

    <label>ট্যাগ (কমা দিয়ে আলাদা করুন)</label>
    <input type="text" name="tags" value="<?php echo htmlspecialchars($_POST['tags'] ?? ''); ?>" placeholder="php, website, wordpress">

    <label>ডেসক্রিপশন</label>
    <textarea name="description" rows="5" required><?php echo htmlspecialchars($_POST['description'] ?? ''); ?></textarea>

    <label>গিগের ছবি</label>
    <input type="file" name="gig_image" accept="image/*">

    <hr>
    <h3>প্যাকেজ যোগ করুন</h3>
    <p class="hint">Basic প্যাকেজ বাধ্যতামূলক। Standard ও Premium ঐচ্ছিক — খালি রাখলে সেই প্যাকেজ তৈরি হবে না।</p>

    <?php foreach (['basic' => 'Basic', 'standard' => 'Standard', 'premium' => 'Premium'] as $key => $label): ?>
        <div class="package-form-block">
            <h4><?php echo $label; ?> প্যাকেজ</h4>
            <label>প্যাকেজ টাইটেল</label>
            <input type="text" name="<?php echo $key; ?>_title" placeholder="যেমন: বেসিক ওয়েবসাইট">

            <label>মূল্য ($)</label>
            <input type="number" step="0.01" name="<?php echo $key; ?>_price" placeholder="50">

            <label>বিস্তারিত</label>
            <textarea name="<?php echo $key; ?>_desc" rows="2" placeholder="এই প্যাকেজে কী কী থাকবে তার সংক্ষিপ্ত বিবরণ"></textarea>

            <div class="inline-fields">
                <div>
                    <label>ডেলিভারি সময় (দিন)</label>
                    <input type="number" name="<?php echo $key; ?>_delivery" value="3">
                </div>
                <div>
                    <label>রিভিশন সংখ্যা</label>
                    <input type="text" name="<?php echo $key; ?>_revisions" value="1" placeholder="যেমন: Unlimited">
                </div>
            </div>

            <label>ফিচার লিস্ট (কমা দিয়ে আলাদা করুন)</label>
            <input type="text" name="<?php echo $key; ?>_features" placeholder="রেসপন্সিভ ডিজাইন, ৫টি পেজ, সোর্স কোড">
        </div>
    <?php endforeach; ?>

    <button type="submit" class="btn-primary">গিগ সাবমিট করুন</button>
</form>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
