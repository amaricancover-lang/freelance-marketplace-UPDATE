<?php
require_once __DIR__ . '/../includes/functions.php';
requireRole('developer');
$user = currentUser();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('developer/dashboard.php');
}
verifyCsrf();

$gigId = (int)($_POST['id'] ?? 0);
$stmt = $conn->prepare("DELETE FROM gigs WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $gigId, $user['id']);
$stmt->execute();

flash('success', 'গিগ ডিলিট করা হয়েছে।');
redirect('developer/dashboard.php');
