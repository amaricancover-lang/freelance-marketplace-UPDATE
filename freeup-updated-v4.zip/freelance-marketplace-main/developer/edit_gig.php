<?php
require_once __DIR__ . '/../includes/functions.php';
requireRole('developer');
$user = currentUser();

$gigId = (int)($_GET['id'] ?? 0);
$stmt = $conn->prepare("SELECT * FROM gigs WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $gigId, $user['id']);
$stmt->execute();
$gig = $stmt->get_result()->fetch_assoc();
if (!$gig) { flash('error', 'গিগ পাওয়া যায়নি।'); redirect('developer/dashboard.php'); }

$pstmt = $conn->prepare("SELECT * FROM packages WHERE gig_id = ?");
$pstmt->bind_param("i", $gigId);
$pstmt->execute();
$existingPackages = [];
$res = $pstmt->get_result();
while ($row = $res->fetch_assoc()) $existingPackages[$row['type']] = $row;

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $title = clean($_POST['title'] ?? '');
    $description = clean($_POST['description'] ?? '');
    $category = clean($_POST['category'] ?? '');
    $tags = clean($_POST['tags'] ?? '');

    if ($title === '') $errors[] = "গিগের টাইটেল দিন";
    if ($description === '') $errors[] = "ডেসক্রিপশন দিন";

    $imageName = $gig['image'];
    if (!empty($_FILES['gig_image']['name'])) {
        $newImg = uploadImage('gig_image', __DIR__ . '/../assets/uploads/gigs');
        if ($newImg === false) {
            $errors[] = "শুধু jpg, jpeg, png, webp, gif ছবি আপলোড করা যাবে";
        } elseif ($newImg) {
            $imageName = $newImg;
        }
    }

    if (empty($errors)) {
        // এডিট করলে আবার রিভিউতে যাবে
        $stmt = $conn->prepare("UPDATE gigs SET title=?, description=?, category=?, tags=?, image=?, status='pending' WHERE id=?");
        $stmt->bind_param("sssssi", $title, $description, $category, $tags, $imageName, $gigId);
        $stmt->execute();

        $conn->query("DELETE FROM packages WHERE gig_id = $gigId");
        foreach (['basic', 'standard', 'premium'] as $type) {
            $pTitle = clean($_POST["{$type}_title"] ?? '');
            $pPrice = $_POST["{$type}_price"] ?? '';
            if ($pTitle !== '' && $pPrice !== '') {
                $desc = clean($_POST["{$type}_desc"] ?? '');
                $delivery = (int)($_POST["{$type}_delivery"] ?? 3);
                $revisions = clean($_POST["{$type}_revisions"] ?? '1');
                $features = clean($_POST["{$type}_features"] ?? '');
                $price = (float)$pPrice;
                $ins = $conn->prepare("INSERT INTO packages (gig_id, type, title, price, description, delivery_days, revisions, features) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $ins->bind_param("issdsiss", $gigId, $type, $pTitle, $price, $desc, $delivery, $revisions, $features);
                $ins->execute();
            }
        }

        flash('success', "গিগ আপডেট হয়েছে এবং পুনরায় রিভিউতে পাঠানো হয়েছে।");
        redirect('developer/dashboard.php');
    }
}

$pageTitle = "গিগ এডিট করুন";
require_once __DIR__ . '/../includes/header.php';
?>
<h2>গিগ এডিট করুন</h2>
<?php if (!empty($errors)): ?>
    <div class="alert alert-error"><ul><?php foreach ($errors as $e) echo "<li>$e</li>"; ?></ul></div>
<?php endif; ?>

<form method="POST" enctype="multipart/form-data" class="app-form gig-form">
    <?php echo csrfField(); ?>
    <label>গিগ টাইটেল</label>
    <input type="text" name="title" required value="<?php echo htmlspecialchars($gig['title']); ?>">

    <label>ক্যাটাগরি</label>
    <input type="text" name="category" value="<?php echo htmlspecialchars($gig['category']); ?>">

    <label>ট্যাগ (কমা দিয়ে আলাদা করুন)</label>
    <input type="text" name="tags" value="<?php echo htmlspecialchars($gig['tags']); ?>">

    <label>ডেসক্রিপশন</label>
    <textarea name="description" rows="5" required><?php echo htmlspecialchars($gig['description']); ?></textarea>

    <?php if ($gig['image']): ?>
        <img src="<?php echo BASE_URL; ?>assets/uploads/gigs/<?php echo $gig['image']; ?>" style="max-width:200px;display:block;margin-bottom:10px;">
    <?php endif; ?>
    <label>নতুন ছবি (পরিবর্তন করতে চাইলে)</label>
    <input type="file" name="gig_image" accept="image/*">

    <hr>
    <h3>প্যাকেজ</h3>
    <?php foreach (['basic' => 'Basic', 'standard' => 'Standard', 'premium' => 'Premium'] as $key => $label):
        $p = $existingPackages[$key] ?? null; ?>
        <div class="package-form-block">
            <h4><?php echo $label; ?> প্যাকেজ</h4>
            <label>প্যাকেজ টাইটেল</label>
            <input type="text" name="<?php echo $key; ?>_title" value="<?php echo htmlspecialchars($p['title'] ?? ''); ?>">

            <label>মূল্য ($)</label>
            <input type="number" step="0.01" name="<?php echo $key; ?>_price" value="<?php echo htmlspecialchars($p['price'] ?? ''); ?>">

            <label>বিস্তারিত</label>
            <textarea name="<?php echo $key; ?>_desc" rows="2"><?php echo htmlspecialchars($p['description'] ?? ''); ?></textarea>

            <div class="inline-fields">
                <div>
                    <label>ডেলিভারি সময় (দিন)</label>
                    <input type="number" name="<?php echo $key; ?>_delivery" value="<?php echo htmlspecialchars($p['delivery_days'] ?? 3); ?>">
                </div>
                <div>
                    <label>রিভিশন সংখ্যা</label>
                    <input type="text" name="<?php echo $key; ?>_revisions" value="<?php echo htmlspecialchars($p['revisions'] ?? '1'); ?>">
                </div>
            </div>

            <label>ফিচার লিস্ট (কমা দিয়ে আলাদা করুন)</label>
            <input type="text" name="<?php echo $key; ?>_features" value="<?php echo htmlspecialchars($p['features'] ?? ''); ?>">
        </div>
    <?php endforeach; ?>

    <button type="submit" class="btn-primary">আপডেট করুন</button>
</form>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
