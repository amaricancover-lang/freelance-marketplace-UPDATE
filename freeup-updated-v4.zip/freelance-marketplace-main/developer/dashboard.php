<?php
require_once __DIR__ . '/../includes/functions.php';
requireRole('developer');
$user = currentUser();

if ($user['status'] !== 'approved') {
    flash('error', 'আপনার একাউন্ট এখনো অ্যাপ্রুভড না।');
    redirect('index.php');
}

$stmt = $conn->prepare("SELECT * FROM gigs WHERE user_id = ? ORDER BY created_at DESC");
$stmt->bind_param("i", $user['id']);
$stmt->execute();
$gigs = $stmt->get_result();

$pageTitle = "ডেভলপার ড্যাশবোর্ড";
require_once __DIR__ . '/../includes/header.php';
?>
<div class="dash-header">
    <h2>আমার গিগসমূহ</h2>
    <a href="add_gig.php" class="btn-primary">+ নতুন গিগ যোগ করুন</a>
</div>

<div class="gig-grid">
<?php if ($gigs->num_rows === 0): ?>
    <p>আপনার এখনো কোনো গিগ নেই। "নতুন গিগ যোগ করুন" বাটনে ক্লিক করুন।</p>
<?php endif; ?>
<?php while ($g = $gigs->fetch_assoc()): ?>
    <div class="gig-manage-card">
        <?php if ($g['image']): ?>
            <img src="<?php echo BASE_URL; ?>assets/uploads/gigs/<?php echo $g['image']; ?>" alt="">
        <?php else: ?>
            <div class="no-image">কোনো ছবি নেই</div>
        <?php endif; ?>
        <div class="gig-manage-info">
            <h4><?php echo htmlspecialchars($g['title']); ?></h4>
            <span class="status-badge status-<?php echo $g['status']; ?>">
                <?php
                    $labels = ['pending' => 'রিভিউ চলছে', 'approved' => 'লাইভ', 'rejected' => 'রিজেক্টেড'];
                    echo $labels[$g['status']];
                ?>
            </span>
            <div class="gig-manage-actions">
                <a href="edit_gig.php?id=<?php echo $g['id']; ?>">এডিট</a>
                <form method="POST" action="delete_gig.php" style="display:inline;" class="confirm-delete-form">
                    <?php echo csrfField(); ?>
                    <input type="hidden" name="id" value="<?php echo $g['id']; ?>">
                    <button type="submit" class="link-btn-danger">ডিলিট</button>
                </form>
                <?php if ($g['status'] === 'approved'): ?>
                    <a href="../gigs/gig_detail.php?id=<?php echo $g['id']; ?>">দেখুন</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php endwhile; ?>
</div>


<script nonce="<?php echo cspNonce(); ?>">
document.querySelectorAll('.confirm-delete-form').forEach(function(form) {
    form.addEventListener('submit', function(e) {
        if (!confirm('আপনি কি নিশ্চিত এই গিগটি ডিলিট করতে চান?')) e.preventDefault();
    });
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
