<?php
require_once __DIR__ . '/../includes/functions.php';

$profileId = (int)($_GET['id'] ?? 0);
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $profileId);
$stmt->execute();
$profile = $stmt->get_result()->fetch_assoc();

if (!$profile) { flash('error', 'ইউজার পাওয়া যায়নি।'); redirect('index.php'); }

$isOwner = isLoggedIn() && $_SESSION['user_id'] == $profileId;

// এডিট ফর্ম হ্যান্ডলিং (শুধু নিজের প্রোফাইল)
if ($isOwner && $_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $bio = clean($_POST['bio'] ?? '');
    $skills = clean($_POST['skills'] ?? '');
    $imageName = $profile['profile_image'];
    if (!empty($_FILES['profile_image']['name'])) {
        $newImg = uploadImage('profile_image', __DIR__ . '/../assets/uploads/profiles');
        if ($newImg) $imageName = $newImg;
    }
    $stmt = $conn->prepare("UPDATE users SET bio=?, skills=?, profile_image=? WHERE id=?");
    $stmt->bind_param("sssi", $bio, $skills, $imageName, $profileId);
    $stmt->execute();
    flash('success', 'প্রোফাইল আপডেট হয়েছে।');
    redirect('user/profile.php?id=' . $profileId);
}

// এই ইউজারের পাবলিশড গিগ (যদি ডেভেলপার হয়)
$gigs = null;
if ($profile['role'] === 'developer') {
    $gstmt = $conn->prepare("SELECT * FROM gigs WHERE user_id = ? AND status = 'approved'");
    $gstmt->bind_param("i", $profileId);
    $gstmt->execute();
    $gigs = $gstmt->get_result();
}

$pageTitle = $profile['name'] . " এর প্রোফাইল";
require_once __DIR__ . '/../includes/header.php';
?>
<div class="profile-header">
    <?php if ($profile['profile_image']): ?>
        <img class="profile-avatar-lg" src="<?php echo BASE_URL; ?>assets/uploads/profiles/<?php echo $profile['profile_image']; ?>">
    <?php else: ?>
        <div class="profile-avatar-lg placeholder"><?php echo strtoupper(substr($profile['name'],0,1)); ?></div>
    <?php endif; ?>
    <div>
        <h2><?php echo htmlspecialchars($profile['name']); ?></h2>
        <span class="role-tag"><?php echo ucfirst($profile['role']); ?></span>
        <?php if ($profile['skills']): ?>
            <div class="tag-list">
                <?php foreach (explode(',', $profile['skills']) as $s): ?>
                    <span class="tag-pill"><?php echo htmlspecialchars(trim($s)); ?></span>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    <?php if (!$isOwner && isLoggedIn()): ?>
        <a href="<?php echo BASE_URL; ?>messages/chat.php?to=<?php echo $profile['id']; ?>" class="btn-secondary">মেসেজ পাঠান</a>
    <?php endif; ?>
</div>

<p class="bio-text"><?php echo nl2br(htmlspecialchars($profile['bio'] ?: 'কোনো বায়ো যোগ করা হয়নি।')); ?></p>

<?php if ($isOwner): ?>
    <h3>প্রোফাইল এডিট করুন</h3>
    <form method="POST" enctype="multipart/form-data" class="app-form">
        <?php echo csrfField(); ?>
        <label>প্রোফাইল ছবি</label>
        <input type="file" name="profile_image" accept="image/*">

        <label>বায়ো</label>
        <textarea name="bio" rows="4"><?php echo htmlspecialchars($profile['bio']); ?></textarea>

        <label>স্কিলস (কমা দিয়ে আলাদা করুন)</label>
        <input type="text" name="skills" value="<?php echo htmlspecialchars($profile['skills']); ?>" placeholder="PHP, WordPress, Graphic Design">

        <button type="submit" class="btn-primary">সেভ করুন</button>
    </form>
<?php endif; ?>

<?php if ($gigs && $gigs->num_rows > 0): ?>
    <h3>প্রকাশিত গিগসমূহ</h3>
    <div class="gig-grid">
        <?php while ($g = $gigs->fetch_assoc()): ?>
            <a href="<?php echo BASE_URL; ?>gigs/gig_detail.php?id=<?php echo $g['id']; ?>" class="gig-public-card">
                <?php if ($g['image']): ?>
                    <img src="<?php echo BASE_URL; ?>assets/uploads/gigs/<?php echo $g['image']; ?>">
                <?php else: ?>
                    <div class="no-image">কোনো ছবি নেই</div>
                <?php endif; ?>
                <div class="gig-public-info"><h4><?php echo htmlspecialchars($g['title']); ?></h4></div>
            </a>
        <?php endwhile; ?>
    </div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
