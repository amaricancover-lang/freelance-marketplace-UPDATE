<?php
require_once __DIR__ . '/../includes/functions.php';
if (isLoggedIn()) redirect('index.php');

$error = '';

if (loginIsLocked()) {
    $mins = ceil(loginSecondsRemaining() / 60);
    $error = "অনেকবার ভুল পাসওয়ার্ড দেওয়া হয়েছে। নিরাপত্তার জন্য প্রায় {$mins} মিনিট পর আবার চেষ্টা করুন।";
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $identity = clean($_POST['identity'] ?? ''); // email অথবা mobile
    $password = $_POST['password'] ?? '';

    if (!verifyCaptcha()) {
        registerFailedLogin();
        $error = "ক্যাপচার উত্তর ভুল হয়েছে, আবার চেষ্টা করুন।";
    } else {
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? OR mobile = ? LIMIT 1");
        $stmt->bind_param("ss", $identity, $identity);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();

        if ($user && password_verify($password, $user['password'])) {
            if ($user['is_banned']) {
                logActivity($user['id'], 'blocked_login_attempt', 'ব্যান করা একাউন্ট দিয়ে লগইনের চেষ্টা');
                $error = "আপনার একাউন্টটি সাসপেন্ড করা হয়েছে। বিস্তারিত জানতে সাপোর্টে যোগাযোগ করুন।";
            } elseif ($user['email'] && !$user['email_verified']) {
                resetLoginAttempts();
                redirect('auth/verify_email.php?user_id=' . $user['id']);
            } elseif ($user['role'] === 'developer' && $user['status'] === 'pending') {
                $error = "আপনার ডেভলপার একাউন্ট এখনো অ্যাডমিন অ্যাপ্রুভ করেননি। অনুগ্রহ করে অপেক্ষা করুন।";
            } elseif ($user['status'] === 'rejected') {
                $error = "আপনার একাউন্ট রিজেক্ট করা হয়েছে। বিস্তারিত জানতে সাপোর্টে যোগাযোগ করুন।";
            } elseif ($user['role'] === 'admin') {
                // অ্যাডমিনের জন্য এক্সট্রা 2FA লেয়ার — পাসওয়ার্ড ঠিক হলেও সরাসরি লগইন হবে না
                resetLoginAttempts();
                if (!$user['email']) {
                    $error = "অ্যাডমিন একাউন্টে ইমেইল যোগ করা নেই, 2FA পাঠানো যাচ্ছে না। সাপোর্টে যোগাযোগ করুন।";
                } else {
                    $code = generateOtp($user['id'], '2fa_login');
                    sendOtpEmail($user['email'], $user['name'], $code, '2fa_login');
                    $_SESSION['pending_admin_id'] = $user['id'];
                    redirect('auth/admin_2fa.php');
                }
            } else {
                resetLoginAttempts();
                // সেশন ফিক্সেশন অ্যাটাক ঠেকাতে লগইনের সময় নতুন সেশন আইডি ইস্যু করা হয়
                session_regenerate_id(true);
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['name'] = $user['name'];
                logActivity($user['id'], 'login', 'সফল লগইন');
                redirect('index.php');
            }
        } else {
            registerFailedLogin($identity !== '' ? $identity : null);
            $error = "ইমেইল/মোবাইল অথবা পাসওয়ার্ড সঠিক নয়।";
        }
    }
}

$pageTitle = "লগইন";
require_once __DIR__ . '/../includes/header.php';
?>
<div class="auth-box">
    <h2>লগইন করুন</h2>
    <?php if ($error): ?><div class="alert alert-error"><?php echo $error; ?></div><?php endif; ?>

    <form method="POST" class="app-form">
        <?php echo csrfField(); ?>
        <label>ইমেইল অথবা মোবাইল নাম্বার</label>
        <input type="text" name="identity" required autofocus>

        <label>পাসওয়ার্ড</label>
        <input type="password" name="password" required>

        <?php echo captchaField(); ?>

        <button type="submit" class="btn-primary">লগইন</button>
    </form>
    <p class="auth-switch">একাউন্ট নেই? <a href="register.php">রেজিস্টার করুন</a></p>
    <p class="auth-switch"><a href="forgot_password.php">পাসওয়ার্ড ভুলে গেছেন?</a></p>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
