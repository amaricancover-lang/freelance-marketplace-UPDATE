<?php
require_once __DIR__ . '/../includes/functions.php';
if (isLoggedIn()) redirect('index.php');

$errors = [];
$done = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $email = clean($_POST['email'] ?? '');
    $code = clean($_POST['code'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if (strlen($password) < 8 || !preg_match('/[A-Za-z]/', $password) || !preg_match('/[0-9]/', $password)) {
        $errors[] = "পাসওয়ার্ড কমপক্ষে ৮ ক্যারেক্টার এবং অক্ষর ও সংখ্যা উভয়ই থাকতে হবে";
    }
    if ($password !== $confirm) $errors[] = "পাসওয়ার্ড মিলছে না";

    if (empty($errors)) {
        if (!checkRateLimit('reset_password_attempt', 8, 600)) {
            $errors[] = "অনেকবার চেষ্টা করা হয়েছে। কিছুক্ষণ পর আবার চেষ্টা করুন।";
        } else {
            $stmt = $conn->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $user = $stmt->get_result()->fetch_assoc();

            if ($user && verifyOtp($user['id'], 'password_reset', $code, true)) {
                $hashed = password_hash($password, PASSWORD_BCRYPT);
                $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
                $stmt->bind_param("si", $hashed, $user['id']);
                $stmt->execute();
                // পাসওয়ার্ড রিসেটের পর সব আগের লগইন অ্যাটেম্পট লক ক্লিয়ার করে দেওয়া হচ্ছে
                resetLoginAttempts();
                logActivity($user['id'], 'password_reset', 'পাসওয়ার্ড রিসেট সম্পন্ন হয়েছে');
                $done = true;
            } else {
                $errors[] = "কোড সঠিক নয়, মেয়াদ শেষ হয়ে গেছে, ইমেইলটি ভুল, অথবা কোডটি অন্য নেটওয়ার্ক থেকে ব্যবহারের চেষ্টা হচ্ছে (নিরাপত্তার জন্য একই নেটওয়ার্ক থেকে ব্যবহার করতে হয়)।";
            }
        }
    }
}

$pageTitle = "পাসওয়ার্ড রিসেট";
require_once __DIR__ . '/../includes/header.php';
?>
<div class="auth-box">
    <h2>নতুন পাসওয়ার্ড সেট করুন</h2>

    <?php if ($done): ?>
        <div class="alert alert-success">পাসওয়ার্ড সফলভাবে পরিবর্তন হয়েছে! এখন নতুন পাসওয়ার্ড দিয়ে <a href="login.php">লগইন করুন</a>।</div>
    <?php else: ?>
        <?php if (!empty($errors)): ?>
            <div class="alert alert-error"><ul><?php foreach ($errors as $e) echo "<li>$e</li>"; ?></ul></div>
        <?php endif; ?>
        <form method="POST" class="app-form">
            <?php echo csrfField(); ?>
            <label>ইমেইল</label>
            <input type="email" name="email" required value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">

            <label>ইমেইলে পাঠানো কোড</label>
            <input type="text" name="code" maxlength="6" required>

            <label>নতুন পাসওয়ার্ড</label>
            <input type="password" name="password" required minlength="8">
            <p class="hint">কমপক্ষে ৮ ক্যারেক্টার, অক্ষর ও সংখ্যা মিলিয়ে</p>

            <label>নতুন পাসওয়ার্ড কনফার্ম করুন</label>
            <input type="password" name="confirm_password" required>

            <button type="submit" class="btn-primary">পাসওয়ার্ড পরিবর্তন করুন</button>
        </form>
        <p class="auth-switch"><a href="forgot_password.php">কোড পাননি? আবার পাঠান</a></p>
    <?php endif; ?>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
