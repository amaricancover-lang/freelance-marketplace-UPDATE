<?php
require_once __DIR__ . '/../includes/functions.php';
if (isLoggedIn()) redirect('index.php');

$userId = (int)($_GET['user_id'] ?? $_POST['user_id'] ?? 0);
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if (!$user || $user['email_verified']) {
    redirect('auth/login.php');
}

$error = '';
$resent = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();

    if (isset($_POST['resend'])) {
        $code = generateOtp($userId, 'email_verify');
        sendOtpEmail($user['email'], $user['name'], $code, 'email_verify');
        $resent = true;
    } else {
        $code = clean($_POST['code'] ?? '');
        if (verifyOtp($userId, 'email_verify', $code)) {
            $conn->query("UPDATE users SET email_verified = 1 WHERE id = " . $userId);
            sendWelcomeEmail($user['email'], $user['name']);
            flash('success', "ইমেইল সফলভাবে ভেরিফাই হয়েছে! এখন লগইন করুন।");
            redirect('auth/login.php');
        } else {
            $error = "কোডটি সঠিক নয় অথবা মেয়াদ শেষ হয়ে গেছে। আবার চেষ্টা করুন অথবা নতুন কোড পাঠান।";
        }
    }
}

$pageTitle = "ইমেইল ভেরিফিকেশন";
require_once __DIR__ . '/../includes/header.php';
?>
<div class="auth-box">
    <h2>ইমেইল ভেরিফাই করুন</h2>
    <p class="hint"><?php echo htmlspecialchars($user['email']); ?> ঠিকানায় একটি ৬-সংখ্যার কোড পাঠানো হয়েছে।</p>

    <?php if ($resent): ?><div class="alert alert-success">নতুন কোড পাঠানো হয়েছে।</div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-error"><?php echo $error; ?></div><?php endif; ?>

    <form method="POST" class="app-form">
        <?php echo csrfField(); ?>
        <input type="hidden" name="user_id" value="<?php echo $userId; ?>">
        <label>ভেরিফিকেশন কোড</label>
        <input type="text" name="code" maxlength="6" required autofocus>
        <button type="submit" class="btn-primary">ভেরিফাই করুন</button>
    </form>

    <form method="POST" style="margin-top:10px;">
        <?php echo csrfField(); ?>
        <input type="hidden" name="user_id" value="<?php echo $userId; ?>">
        <button type="submit" name="resend" value="1" class="btn-secondary">নতুন কোড পাঠান</button>
    </form>

    <p class="hint" style="margin-top:14px;">
        লোকাল সার্ভারে (XAMPP) ইমেইল না পেলে — এটি স্বাভাবিক, কারণ লোকাল mail() কনফিগার করা থাকে না।
        লাইভ হোস্টিং সার্ভারে এটি স্বয়ংক্রিয়ভাবে কাজ করবে।
    </p>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
