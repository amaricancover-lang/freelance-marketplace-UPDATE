<?php
require_once __DIR__ . '/../includes/functions.php';
if (isLoggedIn()) redirect('index.php');

$errors = [];

if (!registrationAllowedForIp()) {
    $errors[] = "এই IP ঠিকানা থেকে অনেকবার একাউন্ট তৈরির চেষ্টা হয়েছে। নিরাপত্তার জন্য সাময়িকভাবে বন্ধ রাখা হয়েছে। সমস্যা মনে করলে সাপোর্টে যোগাযোগ করুন।";
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    if (!verifyCaptcha()) {
        $errors[] = "ক্যাপচার উত্তর ভুল হয়েছে, আবার চেষ্টা করুন";
    }
    $name = clean($_POST['name'] ?? '');
    $email = clean($_POST['email'] ?? '');
    $mobile = clean($_POST['mobile'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';
    $role = $_POST['role'] === 'developer' ? 'developer' : 'buyer';

    if ($name === '') $errors[] = "নাম দিন";
    if ($email === '' && $mobile === '') $errors[] = "ইমেইল অথবা মোবাইল নাম্বার দিতে হবে";
    if (strlen($password) < 8 || !preg_match('/[A-Za-z]/', $password) || !preg_match('/[0-9]/', $password)) {
        $errors[] = "পাসওয়ার্ড কমপক্ষে ৮ ক্যারেক্টার এবং অক্ষর ও সংখ্যা উভয়ই থাকতে হবে";
    }
    if ($password !== $confirm) $errors[] = "পাসওয়ার্ড মিলছে না";

    if (empty($errors)) {
        // ইমেইল/মোবাইল আগে থেকে আছে কিনা চেক
        $stmt = $conn->prepare("SELECT id FROM users WHERE (email = ? AND email != '') OR (mobile = ? AND mobile != '')");
        $stmt->bind_param("ss", $email, $mobile);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            $errors[] = "এই ইমেইল অথবা মোবাইল নাম্বার দিয়ে আগেই একাউন্ট আছে";
        }
    }

    if (empty($errors)) {
        $hashed = password_hash($password, PASSWORD_BCRYPT);
        // ডেভেলপার হলে অ্যাডমিন অ্যাপ্রুভাল লাগবে, বায়ার হলে সরাসরি অ্যাপ্রুভড
        $status = ($role === 'developer') ? 'pending' : 'approved';
        // ইমেইল দিলে ভেরিফাই করতে হবে; শুধু মোবাইল দিলে (SMS গেটওয়ে না থাকায়) ভেরিফিকেশন স্কিপ হয়
        $emailVerified = ($email === '') ? 1 : 0;

        $stmt = $conn->prepare("INSERT INTO users (name, email, mobile, password, role, status, email_verified) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $emailVal = $email !== '' ? $email : null;
        $mobileVal = $mobile !== '' ? $mobile : null;
        $stmt->bind_param("ssssssi", $name, $emailVal, $mobileVal, $hashed, $role, $status, $emailVerified);

        if ($stmt->execute()) {
            $newUserId = $conn->insert_id;
            recordRegistrationAttempt();
            logActivity($newUserId, 'register', "নতুন $role একাউন্ট তৈরি হয়েছে");
            if ($email !== '') {
                $code = generateOtp($newUserId, 'email_verify');
                sendOtpEmail($email, $name, $code, 'email_verify');
                flash('success', "রেজিস্ট্রেশন সফল হয়েছে! আপনার ইমেইলে পাঠানো ৬-সংখ্যার কোড দিয়ে ভেরিফাই করুন।");
                redirect('auth/verify_email.php?user_id=' . $newUserId);
            } else {
                if ($role === 'developer') {
                    flash('success', "রেজিস্ট্রেশন সফল হয়েছে! ডেভলপার একাউন্ট অ্যাডমিন অ্যাপ্রুভালের অপেক্ষায় আছে। অ্যাপ্রুভ হলে আপনি লগইন করে গিগ পাবলিশ করতে পারবেন।");
                } else {
                    flash('success', "রেজিস্ট্রেশন সফল হয়েছে! এখন লগইন করুন।");
                }
                redirect('auth/login.php');
            }        } else {
            $errors[] = "কিছু একটা সমস্যা হয়েছে, আবার চেষ্টা করুন।";
        }
    }
}

$pageTitle = "রেজিস্ট্রেশন";
require_once __DIR__ . '/../includes/header.php';
?>
<div class="auth-box">
    <h2>নতুন একাউন্ট তৈরি করুন</h2>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-error">
            <ul><?php foreach ($errors as $e) echo "<li>" . $e . "</li>"; ?></ul>
        </div>
    <?php endif; ?>

    <form method="POST" class="app-form">
        <?php echo csrfField(); ?>
        <label>আপনি কি হিসেবে জয়েন করতে চান?</label>
        <div class="role-choice">
            <label class="role-card">
                <input type="radio" name="role" value="buyer" checked>
                <div><strong>কিনতে এসেছি (Buyer)</strong><p>সার্ভিস খুঁজবো ও অর্ডার করবো</p></div>
            </label>
            <label class="role-card">
                <input type="radio" name="role" value="developer">
                <div><strong>সেল করতে এসেছি (Developer/Seller)</strong><p>গিগ পাবলিশ করবো — অ্যাডমিন অ্যাপ্রুভাল লাগবে</p></div>
            </label>
        </div>

        <label>পূর্ণ নাম</label>
        <input type="text" name="name" required value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>">

        <label>ইমেইল (ঐচ্ছিক যদি মোবাইল দেন)</label>
        <input type="email" name="email" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">

        <label>মোবাইল নাম্বার (ঐচ্ছিক যদি ইমেইল দেন)</label>
        <input type="text" name="mobile" value="<?php echo htmlspecialchars($_POST['mobile'] ?? ''); ?>">

        <label>পাসওয়ার্ড</label>
        <input type="password" name="password" required minlength="8">
        <p class="hint">কমপক্ষে ৮ ক্যারেক্টার, অক্ষর ও সংখ্যা মিলিয়ে</p>

        <label>পাসওয়ার্ড কনফার্ম করুন</label>
        <input type="password" name="confirm_password" required>

        <?php echo captchaField(); ?>

        <button type="submit" class="btn-primary">রেজিস্টার করুন</button>
    </form>
    <p class="auth-switch">আগে থেকে একাউন্ট আছে? <a href="login.php">লগইন করুন</a></p>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
