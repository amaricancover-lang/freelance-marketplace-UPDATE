<?php
require_once __DIR__ . '/../includes/functions.php';

if (isLoggedIn()) redirect('index.php');
if (empty($_SESSION['pending_admin_id'])) redirect('auth/login.php');

$adminId = (int)$_SESSION['pending_admin_id'];
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ? AND role = 'admin'");
$stmt->bind_param("i", $adminId);
$stmt->execute();
$admin = $stmt->get_result()->fetch_assoc();

if (!$admin) { unset($_SESSION['pending_admin_id']); redirect('auth/login.php'); }

$error = '';
$resent = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();

    if (isset($_POST['resend'])) {
        $code = generateOtp($adminId, '2fa_login');
        sendOtpEmail($admin['email'], $admin['name'], $code, '2fa_login');
        $resent = true;
    } else {
        $code = clean($_POST['code'] ?? '');
        if (verifyOtp($adminId, '2fa_login', $code)) {
            unset($_SESSION['pending_admin_id']);
            session_regenerate_id(true);
            $_SESSION['user_id'] = $admin['id'];
            $_SESSION['role'] = $admin['role'];
            $_SESSION['name'] = $admin['name'];
            redirect('admin/dashboard.php');
        } else {
            $error = "কোডটি সঠিক নয় অথবা মেয়াদ শেষ হয়ে গেছে।";
        }
    }
}

$pageTitle = "অ্যাডমিন ভেরিফিকেশন";
require_once __DIR__ . '/../includes/header.php';
?>
<div class="auth-box">
    <h2>অ্যাডমিন 2FA ভেরিফিকেশন</h2>
    <p class="hint"><?php echo htmlspecialchars($admin['email']); ?> ঠিকানায় একটি ৬-সংখ্যার কোড পাঠানো হয়েছে।</p>

    <?php if ($resent): ?><div class="alert alert-success">নতুন কোড পাঠানো হয়েছে।</div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-error"><?php echo $error; ?></div><?php endif; ?>

    <form method="POST" class="app-form">
        <?php echo csrfField(); ?>
        <label>ভেরিফিকেশন কোড</label>
        <input type="text" name="code" maxlength="6" required autofocus>
        <button type="submit" class="btn-primary">ভেরিফাই করুন</button>
    </form>

    <form method="POST" style="margin-top:10px;">
        <?php echo csrfField(); ?>
        <button type="submit" name="resend" value="1" class="btn-secondary">নতুন কোড পাঠান</button>
    </form>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
