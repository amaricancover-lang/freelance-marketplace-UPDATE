<?php
require_once __DIR__ . '/../includes/functions.php';
if (isLoggedIn()) redirect('index.php');

$error = '';
$sent = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    if (!verifyCaptcha()) {
        $error = "ক্যাপচার উত্তর ভুল হয়েছে, আবার চেষ্টা করুন।";
    } elseif (!checkRateLimit('forgot_password', 3, 600)) {
        $error = "অনেকবার রিকোয়েস্ট করা হয়েছে। ১০ মিনিট পর আবার চেষ্টা করুন।";
    } else {
        $email = clean($_POST['email'] ?? '');
        $stmt = $conn->prepare("SELECT id, name, email FROM users WHERE email = ? LIMIT 1");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();

        // নিরাপত্তার জন্য: ইমেইলটি সিস্টেমে আছে কিনা তা প্রকাশ করা হচ্ছে না —
        // যেকোনো ইমেইলের জন্য একই "পাঠানো হয়েছে" বার্তা দেখানো হচ্ছে (user enumeration ঠেকাতে)
        if ($user) {
            $code = generateOtp($user['id'], 'password_reset');
            sendOtpEmail($user['email'], $user['name'], $code, 'password_reset');
        }
        $sent = true;
    }
}

$pageTitle = "পাসওয়ার্ড রিসেট";
require_once __DIR__ . '/../includes/header.php';
?>
<div class="auth-box">
    <h2>পাসওয়ার্ড ভুলে গেছেন?</h2>

    <?php if ($sent): ?>
        <div class="alert alert-success">
            যদি এই ইমেইলে একটি একাউন্ট থাকে, তাহলে একটি রিসেট কোড পাঠানো হয়েছে।
            <a href="reset_password.php">কোড দিয়ে পাসওয়ার্ড রিসেট করুন</a>
        </div>
    <?php else: ?>
        <?php if ($error): ?><div class="alert alert-error"><?php echo $error; ?></div><?php endif; ?>
        <p class="hint">আপনার একাউন্টের সাথে যুক্ত ইমেইল ঠিকানা দিন — একটি রিসেট কোড পাঠানো হবে।</p>
        <form method="POST" class="app-form">
            <?php echo csrfField(); ?>
            <label>ইমেইল</label>
            <input type="email" name="email" required autofocus>

            <?php echo captchaField(); ?>

            <button type="submit" class="btn-primary">রিসেট কোড পাঠান</button>
        </form>
    <?php endif; ?>
    <p class="auth-switch"><a href="login.php">লগইনে ফিরে যান</a></p>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
