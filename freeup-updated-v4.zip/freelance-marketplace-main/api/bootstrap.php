<?php
// Android অ্যাপের REST API — সাধারণ সাহায্যকারী ফাংশন (JSON উত্তর, ইনপুট, টোকেন লগইন)
// এই ফাইল সরাসরি খোলার জন্য নয়; api/index.php এটি ইনক্লুড করে।

// এই কনস্ট্যান্টটি functions.php কে জানায় যে এটি API রিকোয়েস্ট (সেশন/কুকি ছাড়া, JSON উত্তর)
define('API_REQUEST', true);

// XAMPP এ display_errors চালু থাকে; ওয়ার্নিং JSON এর ভেতরে ঢুকে গেলে অ্যাপ ভেঙে যায়, তাই বন্ধ রাখা হলো
ini_set('display_errors', '0');
error_reporting(E_ALL);

header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store');

// ============ JSON উত্তর ============
function apiRespond($data, $status = 200) {
    http_response_code($status);
    echo json_encode(['ok' => true, 'data' => $data],
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE | JSON_PRESERVE_ZERO_FRACTION);
    exit;
}

function apiError($status, $code, $message, $extra = []) {
    http_response_code($status);
    echo json_encode(['ok' => false, 'error' => array_merge(['code' => $code, 'message' => $message], $extra)],
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

// অপ্রত্যাশিত সমস্যা হলে ভেতরের তথ্য অ্যাপে না পাঠিয়ে সার্ভারের error log এ লেখা হয়
set_exception_handler(function ($e) {
    error_log('[API] ' . get_class($e) . ': ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    apiError(500, 'server_error', 'সার্ভারে একটি সমস্যা হয়েছে। কিছুক্ষণ পর আবার চেষ্টা করুন।');
});

require_once __DIR__ . '/../includes/functions.php';

// ============ ইনপুট ============
// JSON বডি (Content-Type: application/json) অথবা সাধারণ ফর্ম/multipart — দুটোই চলে
function apiInput() {
    static $input = null;
    if ($input !== null) return $input;
    $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
    if (stripos($contentType, 'application/json') !== false) {
        $raw = file_get_contents('php://input');
        $decoded = ($raw === '' || $raw === false) ? [] : json_decode($raw, true);
        if (!is_array($decoded)) {
            apiError(400, 'invalid_json', 'পাঠানো JSON ঠিক নেই।');
        }
        $input = $decoded;
    } else {
        $input = $_POST;
    }
    return $input;
}

// ছাঁটা (trim) টেক্সট, সর্বোচ্চ $max অক্ষর
function apiStr($key, $max = 255) {
    $v = apiInput()[$key] ?? '';
    if (!is_scalar($v)) return '';
    return mb_substr(trim((string)$v), 0, $max);
}

// পাসওয়ার্ডের মতো মান — ছাঁটা বা কাটা হয় না
function apiRaw($key) {
    $v = apiInput()[$key] ?? '';
    return is_scalar($v) ? (string)$v : '';
}

function apiInt($key) {
    $v = apiInput()[$key] ?? 0;
    return is_numeric($v) ? (int)$v : 0;
}

// ?page= ও ?per_page= থেকে [পেজ, প্রতি পেজে কতটি, অফসেট]
function apiPaging($defaultPer = 20, $maxPer = 50) {
    $page = max(1, (int)($_GET['page'] ?? 1));
    $per = (int)($_GET['per_page'] ?? $defaultPer);
    if ($per < 1) $per = $defaultPer;
    $per = min($per, $maxPer);
    return [$page, $per, ($page - 1) * $per];
}

// ============ ডাটাবেজ সাহায্যকারী (সবসময় prepared statement) ============
function apiStmt($sql, $types = '', $params = []) {
    global $conn;
    $stmt = $conn->prepare($sql);
    if ($types !== '') {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    return $stmt;
}

function apiRows($stmt) {
    $rows = [];
    $result = $stmt->get_result();
    while ($r = $result->fetch_assoc()) $rows[] = $r;
    return $rows;
}

function apiRow($stmt) {
    $row = $stmt->get_result()->fetch_assoc();
    return $row ?: null;
}

// ============ রেট লিমিট (ইউজার/কী অনুযায়ী) ============
// rate_limits টেবিলের ip_address কলামে এখানে IP এর বদলে 'u123' (ইউজার আইডি) জাতীয় কী রাখা হয়
function apiRateLimit($action, $key, $max, $windowSeconds) {
    $stmt = apiStmt("SELECT COUNT(*) c FROM rate_limits WHERE action = ? AND ip_address = ? AND created_at > (NOW() - INTERVAL ? SECOND)",
        'ssi', [$action, $key, $windowSeconds]);
    $count = (int)apiRow($stmt)['c'];
    if ($count >= $max) return false;
    apiStmt("INSERT INTO rate_limits (action, ip_address) VALUES (?, ?)", 'ss', [$action, $key]);
    return true;
}

// ============ ছোট ফরম্যাট সাহায্যকারী ============
function apiTime($ts) {
    return $ts ? date('c', strtotime($ts)) : null;
}

function splitList($csv) {
    return array_values(array_filter(array_map('trim', explode(',', (string)$csv)), 'strlen'));
}

function siteRootUrl() {
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    return $scheme . '://' . $host . BASE_URL;
}

// $folder = gigs | profiles | chat
function apiImageUrl($folder, $file) {
    return $file ? siteRootUrl() . 'assets/uploads/' . $folder . '/' . rawurlencode($file) : null;
}

function apiUploadDir($folder) {
    $dir = __DIR__ . '/../assets/uploads/' . $folder;
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    return $dir;
}

// ============ টোকেন লগইন ============
// অ্যাপ প্রতিটি রিকোয়েস্টে পাঠায়:  Authorization: Bearer <৬৪ অক্ষরের টোকেন>
function apiBearerToken() {
    $header = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
    if ($header === '' && function_exists('getallheaders')) {
        foreach (getallheaders() as $k => $v) {
            if (strcasecmp($k, 'Authorization') === 0) { $header = $v; break; }
        }
    }
    if (preg_match('/^Bearer\s+([A-Za-z0-9]{64})$/', trim($header), $m)) {
        return $m[1];
    }
    return null;
}

// নতুন টোকেন বানায়। আসল টোকেন শুধু একবার অ্যাপকে দেওয়া হয়; ডাটাবেজে শুধু হ্যাশ থাকে
function apiIssueToken($userId, $device) {
    $token = bin2hex(random_bytes(32));
    $hash = hash('sha256', $token);
    $ip = clientIp();
    apiStmt("INSERT INTO api_tokens (user_id, token_hash, device_name, ip_address, expires_at) VALUES (?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL 90 DAY))",
        'isss', [$userId, $hash, $device, $ip]);

    // একজন ইউজারের সর্বোচ্চ ১০টি সক্রিয় টোকেন; পুরনোগুলো বাতিল হয়ে যায়
    apiStmt("UPDATE api_tokens SET revoked = 1 WHERE user_id = ? AND revoked = 0
             AND id NOT IN (SELECT id FROM (SELECT id FROM api_tokens WHERE user_id = ? AND revoked = 0 ORDER BY id DESC LIMIT 10) keep)",
        'ii', [$userId, $userId]);
    // অনেক আগে মেয়াদ শেষ হওয়া টোকেন মুছে ফেলা
    apiStmt("DELETE FROM api_tokens WHERE expires_at < (NOW() - INTERVAL 30 DAY)");

    return [$token, date('c', strtotime('+90 days'))];
}

// লগইন করা ইউজার (অ্যারে) ফেরত দেয়।
// $required = true হলে লগইন না থাকলে সরাসরি 401/403 JSON দিয়ে থেমে যায়; false হলে শুধু null দেয়
function apiAuth($required = true) {
    static $done = false, $user = null, $failure = null;

    if (!$done) {
        $done = true;
        $token = apiBearerToken();
        if ($token === null) {
            $failure = [401, 'unauthenticated', 'লগইন করা নেই। আগে লগইন করুন।'];
        } else {
            $row = apiRow(apiStmt(
                "SELECT t.id AS token_id, u.* FROM api_tokens t JOIN users u ON u.id = t.user_id
                 WHERE t.token_hash = ? AND t.revoked = 0 AND t.expires_at > NOW() LIMIT 1",
                's', [hash('sha256', $token)]));
            if (!$row) {
                $failure = [401, 'invalid_token', 'লগইনের মেয়াদ শেষ অথবা টোকেন সঠিক নয়। আবার লগইন করুন।'];
            } elseif ($row['is_banned']) {
                $failure = [403, 'account_banned', 'আপনার একাউন্টটি সাসপেন্ড করা হয়েছে।'];
            } elseif ($row['status'] !== 'approved' || $row['role'] === 'admin') {
                $failure = [403, 'account_not_allowed', 'এই একাউন্ট দিয়ে অ্যাপ ব্যবহার করা যাবে না।'];
            } else {
                $user = $row;
                apiStmt("UPDATE api_tokens SET last_used_at = NOW() WHERE id = ? AND (last_used_at IS NULL OR last_used_at < (NOW() - INTERVAL 60 SECOND))",
                    'i', [$row['token_id']]);
            }
        }
    }

    if ($user === null && $required) {
        apiError($failure[0], $failure[1], $failure[2]);
    }
    return $user;
}

// ============ JSON আকার (অ্যাপকে যা পাঠানো হয়) ============
function apiUser($u) {
    return [
        'id' => (int)$u['id'],
        'name' => $u['name'],
        'email' => $u['email'],
        'mobile' => $u['mobile'],
        'role' => $u['role'],
        'status' => $u['status'],
        'bio' => $u['bio'] ?? '',
        'skills' => splitList($u['skills'] ?? ''),
        'profile_image_url' => apiImageUrl('profiles', $u['profile_image'] ?? null),
        'created_at' => apiTime($u['created_at']),
    ];
}

function apiGigBrief($g) {
    $desc = (string)($g['description'] ?? '');
    return [
        'id' => (int)$g['id'],
        'title' => $g['title'],
        'category' => $g['category'],
        'tags' => splitList($g['tags']),
        'image_url' => apiImageUrl('gigs', $g['image']),
        'seller' => ['id' => (int)$g['seller_id'], 'name' => $g['seller_name']],
        'starting_price' => $g['starting_price'] !== null ? (float)$g['starting_price'] : null,
        'excerpt' => mb_strlen($desc) > 140 ? mb_substr($desc, 0, 140) . '…' : $desc,
        'status' => $g['status'],
        'created_at' => apiTime($g['created_at']),
    ];
}

function apiPackage($p) {
    return [
        'id' => (int)$p['id'],
        'type' => $p['type'],
        'title' => $p['title'],
        'price' => (float)$p['price'],
        'description' => $p['description'],
        'delivery_days' => (int)$p['delivery_days'],
        'revisions' => $p['revisions'],
        'features' => splitList($p['features']),
    ];
}

function apiMessage($m, $myId) {
    $file = $m['file_path'];
    $ext = $file ? strtolower(pathinfo($file, PATHINFO_EXTENSION)) : '';
    return [
        'id' => (int)$m['id'],
        'sender_id' => (int)$m['sender_id'],
        'mine' => (int)$m['sender_id'] === (int)$myId,
        'message' => $m['message'],
        'file_url' => apiImageUrl('chat', $file),
        'file_type' => $file ? (in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'gif'], true) ? 'image' : 'file') : null,
        'is_read' => (bool)$m['is_read'],
        'created_at' => apiTime($m['created_at']),
    ];
}
