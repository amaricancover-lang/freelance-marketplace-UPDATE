<?php
// API এন্ডপয়েন্টের তালিকা — একটি জায়গায় রাখা, যাতে রাউটার (api/index.php) ও
// অ্যাডমিন পেজ (admin/api.php) দুটোই একই তালিকা ব্যবহার করে এবং কখনো মিসম্যাচ না হয়।
//
// প্রতিটি লাইন: [মেথড, পাথ, হ্যান্ডলার ফাংশন (handlers.php তে), লগইন লাগবে কিনা, বর্ণনা]
// লগইন: 'none' = লাগবে না, 'token' = লাগবে, 'optional' = দিলে বাড়তি তথ্য পাওয়া যায়
// পাথের {id} মানে একটি সংখ্যা

return [
    ['POST', 'auth/register',     'handleRegister',      'none',     'নতুন একাউন্ট খোলা (name, email অথবা mobile, password, role = buyer|developer)'],
    ['POST', 'auth/verify-email', 'handleVerifyEmail',   'none',     'ইমেইলে আসা ৬-সংখ্যার কোড যাচাই (user_id, code)'],
    ['POST', 'auth/resend-code',  'handleResendCode',    'none',     'ইমেইল ভেরিফিকেশনের নতুন কোড পাঠানো (user_id)'],
    ['POST', 'auth/login',        'handleLogin',         'none',     'লগইন করে টোকেন পাওয়া (identity, password, device_name)'],
    ['POST', 'auth/logout',       'handleLogout',        'token',    'এই ডিভাইসের টোকেন বাতিল করা'],
    ['GET',  'me',                'handleMe',            'token',    'নিজের প্রোফাইল ও না-পড়া মেসেজের সংখ্যা'],
    ['PUT',  'me',                'handleUpdateMe',      'token',    'প্রোফাইল বদলানো (JSON: name, bio, skills)'],
    ['POST', 'me/photo',          'handleMyPhoto',       'token',    'প্রোফাইল ছবি আপলোড (multipart ফিল্ড: profile_image)'],
    ['GET',  'categories',        'handleCategories',    'none',     'ক্যাটাগরির তালিকা'],
    ['GET',  'gigs',              'handleGigs',          'none',     'গিগ তালিকা ও সার্চ (?q= &category= &page= &per_page=)'],
    ['GET',  'gigs/{id}',         'handleGigDetail',     'optional', 'একটি গিগের বিস্তারিত ও তিনটি প্যাকেজ'],
    ['GET',  'users/{id}',        'handleUserProfile',   'none',     'কারো পাবলিক প্রোফাইল ও তার গিগ'],
    ['GET',  'my/gigs',           'handleMyGigs',        'token',    'আমার গিগ (শুধু ডেভলপার)'],
    ['POST', 'orders',            'handleCreateOrder',   'token',    'অর্ডার দেওয়া (gig_id, package_id)'],
    ['GET',  'orders',            'handleOrders',        'token',    'আমার অর্ডার (?as=buying অথবা ?as=selling)'],
    ['GET',  'messages',          'handleConversations', 'token',    'কথোপকথনের তালিকা (না-পড়া সংখ্যা সহ)'],
    ['GET',  'messages/{id}',     'handleThread',        'token',    'একজনের সাথে চ্যাট (?after_id= দিলে শুধু নতুন মেসেজ)'],
    ['POST', 'messages/{id}',     'handleSendMessage',   'token',    'মেসেজ বা ফাইল পাঠানো (message, attachment)'],
];
