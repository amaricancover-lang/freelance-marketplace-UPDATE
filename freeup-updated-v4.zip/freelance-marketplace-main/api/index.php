<?php
// Android অ্যাপের REST API — একটি প্রবেশদ্বার (front controller)।
// URL:  http://localhost/<ফোল্ডার>/api/<পাথ>     যেমন  .../api/gigs   অথবা   .../api/auth/login
// (.htaccess কাজ না করলে এভাবেও চলে: .../api/index.php/gigs)
// সব উত্তর JSON:  সফল → {"ok":true,"data":{...}}   ব্যর্থ → {"ok":false,"error":{"code":"...","message":"..."}}

require_once __DIR__ . '/bootstrap.php';
require_once __DIR__ . '/handlers.php';
$routes = require __DIR__ . '/routes.php';

// ============ রিকোয়েস্টের পাথ বের করা ============
$requestPath = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$scriptDir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/');
$route = (strpos($requestPath, $scriptDir) === 0) ? substr($requestPath, strlen($scriptDir)) : '';
$route = trim($route, '/');
$route = preg_replace('#^index\.php(/|$)#', '', $route);
$route = trim(rawurldecode($route), '/');

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if ($method === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// ============ API চালু আছে কিনা (অ্যাডমিন > Android API পেজ থেকে বদলানো যায়) ============
$state = apiState();

// শুধু /api/ — অ্যাপ বা ব্রাউজার দিয়ে API ঠিকঠাক চলছে কিনা দেখার জন্য
if ($route === '') {
    apiRespond([
        'service' => 'FreeUp API',
        'version' => 1,
        'status' => $state === 'on' ? 'running' : ($state === 'off' ? 'disabled' : 'not_installed'),
        'base_url' => siteRootUrl() . 'api/',
    ]);
}

if ($state === 'missing') {
    apiError(503, 'api_not_installed', 'ডাটাবেজে API এর টেবিল নেই। phpMyAdmin এ update_api.sql ইমপোর্ট করুন।');
}
if ($state === 'off') {
    apiError(503, 'api_disabled', 'অ্যাপের API এখন অ্যাডমিন বন্ধ রেখেছেন। পরে আবার চেষ্টা করুন।');
}

// ============ এন্ডপয়েন্ট খুঁজে চালানো ============
$allowedMethods = [];
foreach ($routes as $r) {
    [$routeMethod, $routePath, $handler] = $r;
    $pattern = '#^' . str_replace('{id}', '([0-9]{1,10})', $routePath) . '$#';
    if (!preg_match($pattern, $route, $matches)) continue;

    $allowedMethods[] = $routeMethod;
    if ($routeMethod === $method) {
        array_shift($matches);
        call_user_func_array($handler, array_map('intval', $matches));
        exit;
    }
}

if ($allowedMethods) {
    header('Allow: ' . implode(', ', array_unique($allowedMethods)));
    apiError(405, 'method_not_allowed', 'এই পাথে ' . $method . ' মেথড চলবে না। চলবে: ' . implode(', ', array_unique($allowedMethods)));
}
apiError(404, 'not_found', 'এই API পাথটি পাওয়া যায়নি।');
