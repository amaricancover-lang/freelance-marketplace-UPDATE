<?php
// Android অ্যাপের REST API — প্রতিটি এন্ডপয়েন্টের কাজ। রাউটিং আছে api/index.php তে।
// প্রতিটি ফাংশন শেষে apiRespond() বা apiError() দিয়ে থেমে যায়।

// ====================================================================
//  অ্যাকাউন্ট: রেজিস্ট্রেশন, ইমেইল ভেরিফিকেশন, লগইন, লগআউট
// ====================================================================

function handleRegister() {
    global $conn;
    if (!registrationAllowedForIp()) {
        apiError(429, 'registration_limited', 'এই IP ঠিকানা থেকে অনেকবার একাউন্ট তৈরির চেষ্টা হয়েছে। পরে আবার চেষ্টা করুন।');
    }
    if (!checkRateLimit('api_register', 10, 3600)) {
        apiError(429, 'rate_limited', 'অনেকবার চেষ্টা করা হয়েছে। কিছুক্ষণ পর আবার চেষ্টা করুন।');
    }

    $name = apiStr('name', 100);
    $email = apiStr('email', 150);
    $mobile = apiStr('mobile', 20);
    $password = apiRaw('password');
    $role = apiStr('role', 20) === 'developer' ? 'developer' : 'buyer';

    $errors = [];
    if ($name === '') $errors[] = 'নাম দিন';
    if ($email === '' && $mobile === '') $errors[] = 'ইমেইল অথবা মোবাইল নাম্বার দিতে হবে';
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'ইমেইল ঠিকানাটি সঠিক নয়';
    if ($mobile !== '' && !preg_match('/^\+?[0-9][0-9 \-]{5,18}$/', $mobile)) $errors[] = 'মোবাইল নাম্বার সঠিক নয়';
    if (strlen($password) < 8 || !preg_match('/[A-Za-z]/', $password) || !preg_match('/[0-9]/', $password)) {
        $errors[] = 'পাসওয়ার্ড কমপক্ষে ৮ ক্যারেক্টার এবং অক্ষর ও সংখ্যা উভয়ই থাকতে হবে';
    }
    if (strlen($password) > 72) $errors[] = 'পাসওয়ার্ড সর্বোচ্চ ৭২ ক্যারেক্টারের হতে পারবে';
    if ($errors) {
        apiError(422, 'validation_failed', $errors[0], ['errors' => $errors]);
    }

    $exists = apiStmt("SELECT id FROM users WHERE (email = ? AND email != '') OR (mobile = ? AND mobile != '')", 'ss', [$email, $mobile]);
    if ($exists->get_result()->num_rows > 0) {
        apiError(409, 'already_exists', 'এই ইমেইল অথবা মোবাইল নাম্বার দিয়ে আগেই একাউন্ট আছে।');
    }

    $hashed = password_hash($password, PASSWORD_BCRYPT);
    // ডেভেলপার হলে অ্যাডমিন অ্যাপ্রুভাল লাগবে, বায়ার হলে সরাসরি অ্যাপ্রুভড (ওয়েবসাইটের নিয়মই)
    $status = ($role === 'developer') ? 'pending' : 'approved';
    // ইমেইল দিলে ভেরিফাই করতে হবে; শুধু মোবাইল দিলে ভেরিফিকেশন স্কিপ হয় (ওয়েবসাইটের নিয়মই)
    $emailVerified = ($email === '') ? 1 : 0;
    $emailVal = $email !== '' ? $email : null;
    $mobileVal = $mobile !== '' ? $mobile : null;

    apiStmt("INSERT INTO users (name, email, mobile, password, role, status, email_verified) VALUES (?, ?, ?, ?, ?, ?, ?)",
        'ssssssi', [$name, $emailVal, $mobileVal, $hashed, $role, $status, $emailVerified]);
    $newUserId = $conn->insert_id;
    recordRegistrationAttempt();
    logActivity($newUserId, 'register', "নতুন $role একাউন্ট তৈরি হয়েছে (অ্যাপ)");

    $needsVerification = ($email !== '');
    if ($needsVerification) {
        $code = generateOtp($newUserId, 'email_verify');
        sendOtpEmail($email, $name, $code, 'email_verify');
    }

    apiRespond([
        'user_id' => (int)$newUserId,
        'needs_email_verification' => $needsVerification,
        'awaiting_admin_approval' => ($role === 'developer'),
    ], 201);
}

function handleVerifyEmail() {
    $userId = apiInt('user_id');
    $code = apiStr('code', 10);
    if ($userId <= 0 || !preg_match('/^[0-9]{6}$/', $code)) {
        apiError(422, 'validation_failed', '৬-সংখ্যার কোডটি দিন।');
    }
    // ৬ সংখ্যার কোড অনুমান করে মেলানো ঠেকাতে: প্রতি ইউজারে ১৫ মিনিটে ১০ বার, প্রতি IP তে ৩০ বার
    if (!apiRateLimit('api_verify', 'u' . $userId, 10, 900) || !checkRateLimit('api_verify_ip', 30, 900)) {
        apiError(429, 'rate_limited', 'অনেকবার চেষ্টা করা হয়েছে। কিছুক্ষণ পর আবার চেষ্টা করুন।');
    }

    $user = apiRow(apiStmt("SELECT * FROM users WHERE id = ?", 'i', [$userId]));
    $invalid = function () {
        apiError(400, 'invalid_code', 'কোডটি সঠিক নয় অথবা মেয়াদ শেষ হয়ে গেছে। নতুন কোড পাঠান।');
    };
    if (!$user || $user['email_verified']) $invalid();
    if (!verifyOtp($userId, 'email_verify', $code)) $invalid();

    apiStmt("UPDATE users SET email_verified = 1 WHERE id = ?", 'i', [$userId]);
    sendWelcomeEmail($user['email'], $user['name']);
    logActivity($userId, 'email_verified', 'ইমেইল ভেরিফাই হয়েছে (অ্যাপ)');

    apiRespond([
        'verified' => true,
        'awaiting_admin_approval' => ($user['role'] === 'developer' && $user['status'] === 'pending'),
    ]);
}

function handleResendCode() {
    $userId = apiInt('user_id');
    if ($userId <= 0) apiError(422, 'validation_failed', 'user_id দিন।');
    if (!apiRateLimit('api_resend', 'u' . $userId, 3, 900) || !checkRateLimit('api_resend_ip', 10, 3600)) {
        apiError(429, 'rate_limited', 'অনেকবার কোড চাওয়া হয়েছে। কিছুক্ষণ পর আবার চেষ্টা করুন।');
    }
    $user = apiRow(apiStmt("SELECT * FROM users WHERE id = ?", 'i', [$userId]));
    if ($user && $user['email'] && !$user['email_verified']) {
        $code = generateOtp($userId, 'email_verify');
        sendOtpEmail($user['email'], $user['name'], $code, 'email_verify');
    }
    // একাউন্ট আছে কিনা বোঝা না যায়, তাই সবসময় একই উত্তর
    apiRespond(['sent' => true]);
}

function handleLogin() {
    if (loginIsLocked()) {
        $secs = loginSecondsRemaining();
        apiError(429, 'login_locked', 'অনেকবার ভুল পাসওয়ার্ড দেওয়া হয়েছে। প্রায় ' . ceil($secs / 60) . ' মিনিট পর আবার চেষ্টা করুন।', ['retry_after_seconds' => $secs]);
    }

    $identity = apiStr('identity', 150);   // ইমেইল অথবা মোবাইল
    $password = apiRaw('password');
    $device = apiStr('device_name', 100) ?: 'Android';
    if ($identity === '' || $password === '') {
        apiError(422, 'validation_failed', 'ইমেইল/মোবাইল ও পাসওয়ার্ড দিন।');
    }

    $user = apiRow(apiStmt("SELECT * FROM users WHERE email = ? OR mobile = ? LIMIT 1", 'ss', [$identity, $identity]));
    if (!$user || !password_verify($password, $user['password'])) {
        registerFailedLogin($identity);
        apiError(401, 'invalid_credentials', 'ইমেইল/মোবাইল অথবা পাসওয়ার্ড সঠিক নয়।');
    }

    if ($user['is_banned']) {
        logActivity($user['id'], 'blocked_login_attempt', 'ব্যান করা একাউন্ট দিয়ে লগইনের চেষ্টা (অ্যাপ)');
        apiError(403, 'account_banned', 'আপনার একাউন্টটি সাসপেন্ড করা হয়েছে। বিস্তারিত জানতে সাপোর্টে যোগাযোগ করুন।');
    }
    if ($user['email'] && !$user['email_verified']) {
        resetLoginAttempts();
        apiError(403, 'email_not_verified', 'আগে ইমেইল ভেরিফাই করুন।', ['user_id' => (int)$user['id']]);
    }
    if ($user['role'] === 'developer' && $user['status'] === 'pending') {
        apiError(403, 'account_pending', 'আপনার ডেভলপার একাউন্ট এখনো অ্যাডমিন অ্যাপ্রুভ করেননি। অনুগ্রহ করে অপেক্ষা করুন।');
    }
    if ($user['status'] === 'rejected') {
        apiError(403, 'account_rejected', 'আপনার একাউন্ট রিজেক্ট করা হয়েছে। বিস্তারিত জানতে সাপোর্টে যোগাযোগ করুন।');
    }
    if ($user['role'] === 'admin') {
        // অ্যাডমিনের জন্য ইমেইল 2FA ওয়েবসাইটেই থাকে; অ্যাপ দিয়ে অ্যাডমিন লগইন বন্ধ রাখা হয়েছে
        apiError(403, 'admin_not_allowed', 'অ্যাডমিন একাউন্ট দিয়ে অ্যাপে লগইন করা যায় না। ওয়েবসাইট ব্যবহার করুন।');
    }

    resetLoginAttempts();
    [$token, $expiresAt] = apiIssueToken((int)$user['id'], $device);
    logActivity($user['id'], 'login', 'সফল লগইন (অ্যাপ: ' . $device . ')');

    apiRespond([
        'token' => $token,
        'token_type' => 'Bearer',
        'expires_at' => $expiresAt,
        'user' => apiUser($user),
    ]);
}

function handleLogout() {
    $me = apiAuth();
    apiStmt("UPDATE api_tokens SET revoked = 1 WHERE id = ?", 'i', [$me['token_id']]);
    apiRespond(['logged_out' => true]);
}

// ====================================================================
//  নিজের প্রোফাইল
// ====================================================================

function handleMe() {
    $me = apiAuth();
    $unread = (int)apiRow(apiStmt("SELECT COUNT(*) c FROM messages WHERE receiver_id = ? AND is_read = 0", 'i', [$me['id']]))['c'];
    apiRespond(['user' => apiUser($me), 'unread_messages' => $unread]);
}

function handleUpdateMe() {
    $me = apiAuth();
    $in = apiInput();
    $sets = [];
    $types = '';
    $params = [];

    if (array_key_exists('name', $in)) {
        $name = apiStr('name', 100);
        if ($name === '') apiError(422, 'validation_failed', 'নাম খালি রাখা যাবে না।');
        $sets[] = 'name = ?'; $types .= 's'; $params[] = $name;
    }
    if (array_key_exists('bio', $in)) {
        $sets[] = 'bio = ?'; $types .= 's'; $params[] = apiStr('bio', 2000);
    }
    if (array_key_exists('skills', $in)) {
        $skills = $in['skills'];
        if (is_array($skills)) {
            $skills = implode(', ', array_map('strval', array_filter($skills, 'is_scalar')));
        }
        $sets[] = 'skills = ?'; $types .= 's'; $params[] = mb_substr(trim((string)$skills), 0, 255);
    }
    if (!$sets) apiError(422, 'validation_failed', 'বদলানোর মতো কোনো তথ্য পাঠানো হয়নি (name, bio, skills)।');

    $types .= 'i'; $params[] = $me['id'];
    apiStmt("UPDATE users SET " . implode(', ', $sets) . " WHERE id = ?", $types, $params);

    $fresh = apiRow(apiStmt("SELECT * FROM users WHERE id = ?", 'i', [$me['id']]));
    apiRespond(['user' => apiUser($fresh)]);
}

function handleMyPhoto() {
    $me = apiAuth();
    $name = uploadImage('profile_image', apiUploadDir('profiles'));
    if ($name === null) apiError(422, 'validation_failed', 'ছবি পাঠানো হয়নি (ফর্ম ফিল্ডের নাম: profile_image)।');
    if ($name === false) apiError(422, 'invalid_file', 'ছবিটি সঠিক নয় অথবা ৫ এমবির বেশি বড়। jpg, png, webp বা gif দিন।');
    apiStmt("UPDATE users SET profile_image = ? WHERE id = ?", 'si', [$name, $me['id']]);
    apiRespond(['profile_image_url' => apiImageUrl('profiles', $name)]);
}

// ====================================================================
//  ক্যাটাগরি, গিগ, প্রোফাইল (পাবলিক)
// ====================================================================

function handleCategories() {
    apiRespond(['items' => siteCategories()]);
}

function handleGigs() {
    [$page, $per, $offset] = apiPaging();
    $q = is_string($_GET['q'] ?? null) ? trim($_GET['q']) : '';
    $category = is_string($_GET['category'] ?? null) ? trim($_GET['category']) : '';

    $where = "g.status = 'approved'";
    $types = '';
    $params = [];
    if ($q !== '') {
        $where .= " AND (g.title LIKE ? OR g.tags LIKE ? OR g.category LIKE ?)";
        $like = '%' . $q . '%';
        $types .= 'sss';
        array_push($params, $like, $like, $like);
    }
    if ($category !== '') {
        $where .= " AND g.category = ?";
        $types .= 's';
        $params[] = $category;
    }

    $total = (int)apiRow(apiStmt("SELECT COUNT(*) c FROM gigs g WHERE $where", $types, $params))['c'];
    $rows = apiRows(apiStmt(
        "SELECT g.*, u.name AS seller_name, u.id AS seller_id,
                (SELECT MIN(price) FROM packages WHERE gig_id = g.id) AS starting_price
         FROM gigs g JOIN users u ON g.user_id = u.id
         WHERE $where ORDER BY g.created_at DESC, g.id DESC LIMIT ? OFFSET ?",
        $types . 'ii', array_merge($params, [$per, $offset])));

    apiRespond([
        'items' => array_map('apiGigBrief', $rows),
        'page' => $page,
        'per_page' => $per,
        'total' => $total,
        'has_more' => ($offset + count($rows)) < $total,
    ]);
}

function handleGigDetail($id) {
    $gig = apiRow(apiStmt(
        "SELECT g.*, u.name AS seller_name, u.id AS seller_id, u.profile_image AS seller_image, u.bio AS seller_bio
         FROM gigs g JOIN users u ON g.user_id = u.id WHERE g.id = ?", 'i', [$id]));
    $me = apiAuth(false);

    // অ্যাপ্রুভড না হলে শুধু গিগের মালিক নিজে দেখতে পারবে (ওয়েবসাইটের নিয়মই)
    if (!$gig || ($gig['status'] !== 'approved' && (!$me || (int)$me['id'] !== (int)$gig['seller_id']))) {
        apiError(404, 'gig_not_found', 'গিগটি পাওয়া যায়নি বা এখনো পাবলিশ হয়নি।');
    }

    $packages = array_map('apiPackage', apiRows(apiStmt(
        "SELECT * FROM packages WHERE gig_id = ? ORDER BY FIELD(type,'basic','standard','premium')", 'i', [$id])));
    $prices = array_column($packages, 'price');
    $gig['starting_price'] = $prices ? min($prices) : null;

    $out = apiGigBrief($gig);
    $out['description'] = (string)$gig['description'];
    $out['packages'] = $packages;
    $out['seller']['bio'] = (string)$gig['seller_bio'];
    $out['seller']['profile_image_url'] = apiImageUrl('profiles', $gig['seller_image']);
    $out['can_order'] = $me !== null
        && $gig['status'] === 'approved'
        && (int)$me['id'] !== (int)$gig['seller_id']
        && count($packages) > 0;

    apiRespond($out);
}

function handleUserProfile($id) {
    $u = apiRow(apiStmt(
        "SELECT * FROM users WHERE id = ? AND is_banned = 0 AND status = 'approved' AND role != 'admin'", 'i', [$id]));
    if (!$u) apiError(404, 'user_not_found', 'ইউজার পাওয়া যায়নি।');

    $gigs = apiRows(apiStmt(
        "SELECT g.*, u.name AS seller_name, u.id AS seller_id,
                (SELECT MIN(price) FROM packages WHERE gig_id = g.id) AS starting_price
         FROM gigs g JOIN users u ON g.user_id = u.id
         WHERE g.user_id = ? AND g.status = 'approved' ORDER BY g.created_at DESC LIMIT 50", 'i', [$id]));

    // অন্যের প্রোফাইলে ইমেইল/মোবাইল দেখানো হয় না
    $pub = apiUser($u);
    unset($pub['email'], $pub['mobile'], $pub['status']);
    $pub['gigs'] = array_map('apiGigBrief', $gigs);
    apiRespond($pub);
}

function handleMyGigs() {
    $me = apiAuth();
    if ($me['role'] !== 'developer') {
        apiError(403, 'not_a_seller', 'এটি শুধু ডেভলপার/সেলার একাউন্টের জন্য।');
    }
    $rows = apiRows(apiStmt(
        "SELECT g.*, u.name AS seller_name, u.id AS seller_id,
                (SELECT MIN(price) FROM packages WHERE gig_id = g.id) AS starting_price
         FROM gigs g JOIN users u ON g.user_id = u.id
         WHERE g.user_id = ? ORDER BY g.created_at DESC", 'i', [$me['id']]));
    apiRespond(['items' => array_map('apiGigBrief', $rows)]);
}

// ====================================================================
//  অর্ডার
// ====================================================================

function handleCreateOrder() {
    global $conn;
    $me = apiAuth();
    $gigId = apiInt('gig_id');
    $packageId = apiInt('package_id');
    if ($gigId <= 0 || $packageId <= 0) {
        apiError(422, 'validation_failed', 'gig_id ও package_id দিন।');
    }
    if (!apiRateLimit('api_order', 'u' . $me['id'], 15, 3600)) {
        apiError(429, 'rate_limited', 'অনেকগুলো অর্ডার দ্রুত দেওয়া হয়েছে। কিছুক্ষণ পর আবার চেষ্টা করুন।');
    }

    // প্যাকেজটি সত্যিই এই গিগের এবং গিগটি পাবলিশড কিনা যাচাই
    $row = apiRow(apiStmt(
        "SELECT p.id AS package_id, p.title AS package_title, p.price,
                g.id AS gig_id, g.title AS gig_title, g.user_id AS seller_id, g.status
         FROM packages p JOIN gigs g ON g.id = p.gig_id
         WHERE p.id = ? AND g.id = ?", 'ii', [$packageId, $gigId]));
    if (!$row || $row['status'] !== 'approved') {
        apiError(404, 'gig_not_found', 'গিগ বা প্যাকেজটি পাওয়া যায়নি।');
    }
    if ((int)$row['seller_id'] === (int)$me['id']) {
        apiError(422, 'own_gig', 'নিজের গিগে অর্ডার করা যায় না।');
    }

    apiStmt("INSERT INTO orders (buyer_id, gig_id, package_id, status) VALUES (?, ?, ?, 'pending')",
        'iii', [$me['id'], $gigId, $packageId]);
    $orderId = $conn->insert_id;
    logActivity($me['id'], 'place_order', "গিগ #$gigId, প্যাকেজ #$packageId এর জন্য অর্ডার দেওয়া হয়েছে (অ্যাপ)");

    // সেলারকে ইমেইলে জানানো
    $seller = apiRow(apiStmt("SELECT name, email FROM users WHERE id = ?", 'i', [$row['seller_id']]));
    if ($seller && $seller['email']) {
        sendNewOrderEmail($seller['email'], $seller['name'], $row['gig_title'], $row['price']);
    }

    apiRespond([
        'order_id' => (int)$orderId,
        'status' => 'pending',
        'gig_id' => (int)$row['gig_id'],
        'gig_title' => $row['gig_title'],
        'package_title' => $row['package_title'],
        'price' => (float)$row['price'],
    ], 201);
}

function handleOrders() {
    $me = apiAuth();
    $as = (($_GET['as'] ?? 'buying') === 'selling') ? 'selling' : 'buying';
    if ($as === 'selling' && $me['role'] !== 'developer') {
        apiError(403, 'not_a_seller', 'বিক্রির অর্ডার শুধু ডেভলপার/সেলার একাউন্ট দেখতে পারে।');
    }
    [$page, $per, $offset] = apiPaging(20, 50);

    // buying = আমি যা কিনেছি (অপর পক্ষ = সেলার); selling = আমার গিগে আসা অর্ডার (অপর পক্ষ = বায়ার)
    if ($as === 'buying') {
        $join = "JOIN users u ON u.id = g.user_id";
        $where = "o.buyer_id = ?";
    } else {
        $join = "JOIN users u ON u.id = o.buyer_id";
        $where = "g.user_id = ?";
    }
    $rows = apiRows(apiStmt(
        "SELECT o.id, o.status, o.created_at, g.id AS gig_id, g.title AS gig_title, g.image,
                p.type AS package_type, p.title AS package_title, p.price, p.delivery_days,
                u.id AS other_id, u.name AS other_name
         FROM orders o JOIN gigs g ON g.id = o.gig_id JOIN packages p ON p.id = o.package_id $join
         WHERE $where ORDER BY o.id DESC LIMIT ? OFFSET ?",
        'iii', [$me['id'], $per + 1, $offset]));

    $hasMore = count($rows) > $per;
    $rows = array_slice($rows, 0, $per);
    $items = array_map(function ($r) {
        return [
            'id' => (int)$r['id'],
            'status' => $r['status'],
            'created_at' => apiTime($r['created_at']),
            'gig' => ['id' => (int)$r['gig_id'], 'title' => $r['gig_title'], 'image_url' => apiImageUrl('gigs', $r['image'])],
            'package' => [
                'type' => $r['package_type'],
                'title' => $r['package_title'],
                'price' => (float)$r['price'],
                'delivery_days' => (int)$r['delivery_days'],
            ],
            'other_user' => ['id' => (int)$r['other_id'], 'name' => $r['other_name']],
        ];
    }, $rows);

    apiRespond(['as' => $as, 'items' => $items, 'page' => $page, 'per_page' => $per, 'has_more' => $hasMore]);
}

// ====================================================================
//  মেসেজ
// ====================================================================

function apiFindChatUser($otherId, $me) {
    if ($otherId === (int)$me['id']) {
        apiError(422, 'validation_failed', 'নিজেকে মেসেজ পাঠানো যায় না।');
    }
    $other = apiRow(apiStmt("SELECT id, name, role, profile_image FROM users WHERE id = ? AND is_banned = 0", 'i', [$otherId]));
    if (!$other) apiError(404, 'user_not_found', 'ইউজার পাওয়া যায়নি।');
    return $other;
}

function apiChatUser($u) {
    return [
        'id' => (int)$u['id'],
        'name' => $u['name'],
        'role' => $u['role'],
        'profile_image_url' => apiImageUrl('profiles', $u['profile_image']),
    ];
}

function handleConversations() {
    $me = apiAuth();
    $id = (int)$me['id'];
    $rows = apiRows(apiStmt(
        "SELECT u.id, u.name, u.role, u.profile_image,
            (SELECT message FROM messages m2 WHERE (m2.sender_id = u.id AND m2.receiver_id = ?) OR (m2.sender_id = ? AND m2.receiver_id = u.id) ORDER BY m2.id DESC LIMIT 1) AS last_message,
            (SELECT created_at FROM messages m3 WHERE (m3.sender_id = u.id AND m3.receiver_id = ?) OR (m3.sender_id = ? AND m3.receiver_id = u.id) ORDER BY m3.id DESC LIMIT 1) AS last_time,
            (SELECT COUNT(*) FROM messages m4 WHERE m4.sender_id = u.id AND m4.receiver_id = ? AND m4.is_read = 0) AS unread
         FROM users u
         WHERE u.id IN (
             SELECT sender_id FROM messages WHERE receiver_id = ?
             UNION
             SELECT receiver_id FROM messages WHERE sender_id = ?
         )
         ORDER BY last_time DESC",
        'iiiiiii', [$id, $id, $id, $id, $id, $id, $id]));

    $items = array_map(function ($r) {
        $item = apiChatUser($r);
        $item['last_message'] = ($r['last_message'] !== null && $r['last_message'] !== '') ? $r['last_message'] : null;
        $item['last_time'] = apiTime($r['last_time']);
        $item['unread'] = (int)$r['unread'];
        return $item;
    }, $rows);
    apiRespond(['items' => $items]);
}

// ?after_id=N দিলে শুধু নতুন মেসেজ আসে (অ্যাপ কিছুক্ষণ পর পর এটি চালিয়ে নতুন মেসেজ দেখাতে পারে)
function handleThread($otherId) {
    $me = apiAuth();
    $other = apiFindChatUser($otherId, $me);
    $myId = (int)$me['id'];
    $after = max(0, (int)($_GET['after_id'] ?? 0));

    $pair = "((sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?))";
    if ($after > 0) {
        $rows = apiRows(apiStmt("SELECT * FROM messages WHERE $pair AND id > ? ORDER BY id ASC LIMIT 200",
            'iiiii', [$myId, $otherId, $otherId, $myId, $after]));
    } else {
        $rows = apiRows(apiStmt("SELECT * FROM (SELECT * FROM messages WHERE $pair ORDER BY id DESC LIMIT 100) recent ORDER BY id ASC",
            'iiii', [$myId, $otherId, $otherId, $myId]));
    }

    apiStmt("UPDATE messages SET is_read = 1 WHERE sender_id = ? AND receiver_id = ? AND is_read = 0", 'ii', [$otherId, $myId]);

    apiRespond([
        'user' => apiChatUser($other),
        'messages' => array_map(function ($m) use ($myId) { return apiMessage($m, $myId); }, $rows),
    ]);
}

// টেক্সট পাঠাতে JSON {"message":"..."}; ফাইল/ছবি পাঠাতে multipart ফর্মে "attachment" ফিল্ড (সাথে চাইলে "message")
function handleSendMessage($otherId) {
    global $conn;
    $me = apiAuth();
    $other = apiFindChatUser($otherId, $me);
    if (!apiRateLimit('api_message', 'u' . $me['id'], 30, 300)) {
        apiError(429, 'rate_limited', 'অনেকগুলো মেসেজ দ্রুত পাঠানো হয়েছে। কিছুক্ষণ অপেক্ষা করুন।');
    }

    $text = apiStr('message', 5000);
    $filePath = null;
    if (!empty($_FILES['attachment']['name'])) {
        $uploaded = uploadChatFile('attachment', apiUploadDir('chat'));
        if ($uploaded === false) {
            apiError(422, 'invalid_file', 'ফাইলটি পাঠানো যায়নি। সর্বোচ্চ ১০ এমবি; jpg, png, webp, gif, pdf, doc, docx, zip, rar, txt চলবে।');
        }
        $filePath = $uploaded;
    }
    if ($text === '' && !$filePath) {
        apiError(422, 'validation_failed', 'মেসেজ লিখুন অথবা ফাইল দিন।');
    }

    apiStmt("INSERT INTO messages (sender_id, receiver_id, message, file_path) VALUES (?, ?, ?, ?)",
        'iiss', [$me['id'], $otherId, $text, $filePath]);
    $messageId = $conn->insert_id;

    $receiver = apiRow(apiStmt("SELECT name, email FROM users WHERE id = ?", 'i', [$otherId]));
    if ($receiver && $receiver['email']) {
        $preview = $text !== '' ? $text : '📎 একটি ফাইল পাঠানো হয়েছে';
        sendNewMessageEmail($receiver['email'], $receiver['name'], $me['name'], $preview);
    }

    $row = apiRow(apiStmt("SELECT * FROM messages WHERE id = ?", 'i', [$messageId]));
    apiRespond(['message' => apiMessage($row, (int)$me['id'])], 201);
}
