<?php
require_once __DIR__ . '/../includes/functions.php';

$search = clean($_GET['q'] ?? '');
$category = clean($_GET['category'] ?? '');

$sql = "SELECT g.*, u.name AS seller_name, u.id AS seller_id,
        (SELECT MIN(price) FROM packages WHERE gig_id = g.id) AS starting_price
        FROM gigs g JOIN users u ON g.user_id = u.id
        WHERE g.status = 'approved'";
$params = [];
$types = "";

if ($search !== '') {
    $sql .= " AND (g.title LIKE ? OR g.tags LIKE ? OR g.category LIKE ?)";
    $like = "%$search%";
    $params[] = &$like; $params[] = &$like; $params[] = &$like;
    $types .= "sss";
}
if ($category !== '') {
    $sql .= " AND g.category = ?";
    $params[] = &$category;
    $types .= "s";
}
$sql .= " ORDER BY g.created_at DESC";

$stmt = $conn->prepare($sql);
if ($types !== "") {
    array_unshift($params, $types);
    call_user_func_array([$stmt, 'bind_param'], $params);
}
$stmt->execute();
$gigs = $stmt->get_result();

$pageTitle = "গিগ ব্রাউজ করুন";
require_once __DIR__ . '/../includes/header.php';
?>
<h2 class="page-heading"><?php echo $category !== '' ? htmlspecialchars($category) : 'সকল সার্ভিস'; ?></h2>
<p class="hint"><?php echo $gigs->num_rows; ?>টি সার্ভিস পাওয়া গেছে</p>

<form method="GET" class="search-bar">
    <?php if ($category !== ''): ?><input type="hidden" name="category" value="<?php echo htmlspecialchars($category); ?>"><?php endif; ?>
    <input type="text" name="q" placeholder="সার্ভিস খুঁজুন..." value="<?php echo htmlspecialchars($search); ?>">
    <button type="submit" class="btn-primary">খুঁজুন</button>
</form>

<div class="gig-grid">
<?php if ($gigs->num_rows === 0): ?>
    <p>কোনো গিগ পাওয়া যায়নি।</p>
<?php endif; ?>
<?php while ($g = $gigs->fetch_assoc()): ?>
    <a href="gig_detail.php?id=<?php echo $g['id']; ?>" class="gig-public-card">
        <?php if ($g['image']): ?>
            <img src="<?php echo BASE_URL; ?>assets/uploads/gigs/<?php echo $g['image']; ?>" alt="">
        <?php else: ?>
            <div class="no-image">কোনো ছবি নেই</div>
        <?php endif; ?>
        <div class="gig-public-info">
            <p class="seller-name-small"><?php echo htmlspecialchars($g['seller_name']); ?></p>
            <h4><?php echo htmlspecialchars($g['title']); ?></h4>
            <div class="price-from">শুরু <?php echo $g['starting_price'] ? '$' . number_format($g['starting_price'], 2) : 'N/A'; ?></div>
        </div>
    </a>
<?php endwhile; ?>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
