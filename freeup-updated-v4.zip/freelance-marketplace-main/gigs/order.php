<?php
require_once __DIR__ . '/../includes/functions.php';
requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('gigs/browse.php');
verifyCsrf();

if (!checkRateLimit('place_order', 15, 3600)) {
    flash('error', 'অনেকগুলো অর্ডার দ্রুত দেওয়া হয়েছে। কিছুক্ষণ পর আবার চেষ্টা করুন।');
    redirect('gigs/browse.php');
}

$gigId = (int)($_POST['gig_id'] ?? 0);
$packageId = (int)($_POST['package_id'] ?? 0);
$buyerId = $_SESSION['user_id'];

$stmt = $conn->prepare("INSERT INTO orders (buyer_id, gig_id, package_id, status) VALUES (?, ?, ?, 'pending')");
$stmt->bind_param("iii", $buyerId, $gigId, $packageId);
$stmt->execute();
logActivity($buyerId, 'place_order', "গিগ #$gigId, প্যাকেজ #$packageId এর জন্য অর্ডার দেওয়া হয়েছে");

// গিগের মালিক (সেলার) কে ইমেইলে জানানো হচ্ছে
$nstmt = $conn->prepare("SELECT g.title, u.name AS seller_name, u.email AS seller_email, p.price
                          FROM gigs g JOIN users u ON g.user_id = u.id
                          JOIN packages p ON p.id = ?
                          WHERE g.id = ?");
$nstmt->bind_param("ii", $packageId, $gigId);
$nstmt->execute();
$info = $nstmt->get_result()->fetch_assoc();
if ($info && $info['seller_email']) {
    sendNewOrderEmail($info['seller_email'], $info['seller_name'], $info['title'], $info['price']);
}

flash('success', "অর্ডার সফলভাবে প্লেস করা হয়েছে! সেলার শীঘ্রই যোগাযোগ করবেন।");
redirect('gigs/gig_detail.php?id=' . $gigId);
