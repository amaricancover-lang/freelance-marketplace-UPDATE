<?php
require_once __DIR__ . '/../includes/functions.php';

$gigId = (int)($_GET['id'] ?? 0);
$stmt = $conn->prepare("SELECT g.*, u.name AS seller_name, u.id AS seller_id, u.profile_image, u.bio
                         FROM gigs g JOIN users u ON g.user_id = u.id WHERE g.id = ?");
$stmt->bind_param("i", $gigId);
$stmt->execute();
$gig = $stmt->get_result()->fetch_assoc();

if (!$gig || ($gig['status'] !== 'approved' && (!isLoggedIn() || $_SESSION['user_id'] != $gig['seller_id']))) {
    flash('error', 'গিগটি পাওয়া যায়নি বা এখনো পাবলিশ হয়নি।');
    redirect('gigs/browse.php');
}

$pstmt = $conn->prepare("SELECT * FROM packages WHERE gig_id = ? ORDER BY FIELD(type,'basic','standard','premium')");
$pstmt->bind_param("i", $gigId);
$pstmt->execute();
$packages = [];
$res = $pstmt->get_result();
while ($row = $res->fetch_assoc()) $packages[$row['type']] = $row;

$pageTitle = $gig['title'];
require_once __DIR__ . '/../includes/header.php';
?>
<div class="breadcrumbs">🏠 / <?php echo htmlspecialchars($gig['category'] ?: 'সাধারণ'); ?></div>

<h1 class="gig-page-title"><?php echo htmlspecialchars($gig['title']); ?></h1>

<div class="seller-profile-row">
    <div class="seller-avatar-md"><?php echo strtoupper(substr($gig['seller_name'],0,1)); ?></div>
    <div>
        <a href="<?php echo BASE_URL; ?>user/profile.php?id=<?php echo $gig['seller_id']; ?>"><strong><?php echo htmlspecialchars($gig['seller_name']); ?></strong></a>
    </div>
</div>

<div class="gig-layout-grid">
    <div>
        <?php if ($gig['image']): ?>
            <img class="gig-main-banner" src="<?php echo BASE_URL; ?>assets/uploads/gigs/<?php echo $gig['image']; ?>" alt="">
        <?php endif; ?>
        <h3>বিস্তারিত বর্ণনা</h3>
        <p class="gig-full-desc"><?php echo nl2br(htmlspecialchars($gig['description'])); ?></p>
        <?php if ($gig['tags']): ?>
            <div class="tag-list">
                <?php foreach (explode(',', $gig['tags']) as $tag): ?>
                    <span class="tag-pill"><?php echo htmlspecialchars(trim($tag)); ?></span>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <?php if (isLoggedIn() && $_SESSION['user_id'] != $gig['seller_id']): ?>
            <a href="<?php echo BASE_URL; ?>messages/chat.php?to=<?php echo $gig['seller_id']; ?>" class="btn-secondary">সেলারকে মেসেজ করুন</a>
        <?php endif; ?>
    </div>

    <div>
        <div class="package-card">
            <?php if (count($packages) > 1): ?>
            <div class="package-tabs">
                <?php foreach ($packages as $type => $p): ?>
                    <button type="button" class="tab-btn <?php echo $type==='basic'?'active':''; ?>" data-type="<?php echo $type; ?>"><?php echo ucfirst($type); ?></button>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <div class="package-body">
                <?php foreach ($packages as $type => $p): ?>
                    <div class="pkg-panel" id="pkg-<?php echo $type; ?>" style="<?php echo $type==='basic' ? '' : 'display:none;'; ?>">
                        <div class="package-title-row">
                            <span class="pkg-title"><?php echo htmlspecialchars($p['title']); ?></span>
                            <span class="pkg-price">$<?php echo number_format($p['price'], 2); ?></span>
                        </div>
                        <p class="pkg-desc"><?php echo htmlspecialchars($p['description']); ?></p>
                        <div class="pkg-meta">
                            <span>🕒 <?php echo $p['delivery_days']; ?>-দিন ডেলিভারি</span>
                            <span>🔄 <?php echo htmlspecialchars($p['revisions']); ?> রিভিশন</span>
                        </div>
                        <?php if ($p['features']): ?>
                        <ul class="includes-list">
                            <?php foreach (explode(',', $p['features']) as $f): if (trim($f) === '') continue; ?>
                                <li class="checked"><?php echo htmlspecialchars(trim($f)); ?></li>
                            <?php endforeach; ?>
                        </ul>
                        <?php endif; ?>

                        <?php if (isLoggedIn() && $_SESSION['user_id'] != $gig['seller_id'] && $_SESSION['role'] !== 'admin'): ?>
                            <form method="POST" action="<?php echo BASE_URL; ?>gigs/order.php">
                                <?php echo csrfField(); ?>
                                <input type="hidden" name="gig_id" value="<?php echo $gig['id']; ?>">
                                <input type="hidden" name="package_id" value="<?php echo $p['id']; ?>">
                                <button type="submit" class="continue-btn">Continue ($<?php echo number_format($p['price'],2); ?>)</button>
                            </form>
                        <?php elseif (!isLoggedIn()): ?>
                            <a href="<?php echo BASE_URL; ?>auth/login.php" class="continue-btn" style="display:block;text-align:center;text-decoration:none;">অর্ডার করতে লগইন করুন</a>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
                <?php if (empty($packages)): ?>
                    <p>এই গিগে এখনো কোনো প্যাকেজ যোগ করা হয়নি।</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script nonce="<?php echo cspNonce(); ?>">
function showPkg(type) {
    document.querySelectorAll('.pkg-panel').forEach(el => el.style.display = 'none');
    document.querySelectorAll('.tab-btn').forEach(el => el.classList.remove('active'));
    document.getElementById('pkg-' + type).style.display = 'block';
    document.querySelector('.tab-btn[data-type="' + type + '"]').classList.add('active');
}
document.querySelectorAll('.tab-btn').forEach(function(btn) {
    btn.addEventListener('click', function() { showPkg(btn.dataset.type); });
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
