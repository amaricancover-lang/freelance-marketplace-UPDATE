<?php
require_once __DIR__ . '/../includes/functions.php';
requireRole('admin');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'], $_POST['id'])) {
    verifyCsrf();
    $id = (int)$_POST['id'];
    $newStatus = $_POST['action'] === 'approve' ? 'approved' : 'rejected';
    $stmt = $conn->prepare("UPDATE users SET status = ? WHERE id = ? AND role = 'developer'");
    $stmt->bind_param("si", $newStatus, $id);
    $stmt->execute();

    // ডেভলপারকে ইমেইলে জানানো হচ্ছে
    $dstmt = $conn->prepare("SELECT name, email FROM users WHERE id = ?");
    $dstmt->bind_param("i", $id);
    $dstmt->execute();
    $devRow = $dstmt->get_result()->fetch_assoc();
    if ($devRow && $devRow['email']) {
        sendDeveloperStatusEmail($devRow['email'], $devRow['name'], $newStatus === 'approved');
    }
    logActivity($_SESSION['user_id'], 'developer_' . $newStatus, "ডেভলপার #$id");

    flash('success', 'স্ট্যাটাস আপডেট হয়েছে।');
    redirect('admin/approve_developers.php');
}

$devs = $conn->query("SELECT * FROM users WHERE role='developer' ORDER BY status='pending' DESC, created_at DESC");

$pageTitle = "ডেভলপার অ্যাপ্রুভাল";
require_once __DIR__ . '/../includes/header.php';
?>
<h2>ডেভলপার ম্যানেজমেন্ট</h2>

<table class="admin-table">
    <tr><th>নাম</th><th>ইমেইল/মোবাইল</th><th>স্ট্যাটাস</th><th>একশন</th></tr>
    <?php while ($d = $devs->fetch_assoc()): ?>
    <tr>
        <td><a href="<?php echo BASE_URL; ?>user/profile.php?id=<?php echo $d['id']; ?>"><?php echo htmlspecialchars($d['name']); ?></a></td>
        <td><?php echo htmlspecialchars($d['email'] ?: $d['mobile']); ?></td>
        <td><span class="status-badge status-<?php echo $d['status']; ?>"><?php echo $d['status']; ?></span></td>
        <td>
            <?php if ($d['status'] !== 'approved'): ?>
                <form method="POST" style="display:inline;">
                    <?php echo csrfField(); ?>
                    <input type="hidden" name="id" value="<?php echo $d['id']; ?>">
                    <input type="hidden" name="action" value="approve">
                    <button type="submit" class="link-btn-approve">অ্যাপ্রুভ</button>
                </form>
            <?php endif; ?>
            <?php if ($d['status'] !== 'rejected'): ?>
                <form method="POST" style="display:inline;" class="confirm-action-form">
                    <?php echo csrfField(); ?>
                    <input type="hidden" name="id" value="<?php echo $d['id']; ?>">
                    <input type="hidden" name="action" value="reject">
                    <button type="submit" class="link-btn-reject">রিজেক্ট</button>
                </form>
            <?php endif; ?>
        </td>
    </tr>
    <?php endwhile; ?>
</table>


<script nonce="<?php echo cspNonce(); ?>">
document.querySelectorAll('.confirm-action-form').forEach(function(form) {
    form.addEventListener('submit', function(e) {
        if (!confirm('আপনি কি নিশ্চিত?')) e.preventDefault();
    });
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
