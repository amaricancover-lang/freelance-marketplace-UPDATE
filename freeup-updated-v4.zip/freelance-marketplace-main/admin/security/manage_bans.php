<?php
require_once __DIR__ . '/../../includes/functions.php';
requireRole('admin');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $id = (int)($_POST['id'] ?? 0);

    if (isset($_POST['ban'])) {
        $reason = clean($_POST['reason'] ?? 'সন্দেহজনক/ফেক একাউন্ট');
        $stmt = $conn->prepare("UPDATE users SET is_banned = 1, ban_reason = ? WHERE id = ? AND role != 'admin'");
        $stmt->bind_param("si", $reason, $id);
        $stmt->execute();
        logActivity($_SESSION['user_id'], 'user_banned', "ইউজার #$id ব্যান করা হয়েছে: $reason");
        flash('success', 'ইউজার ব্যান করা হয়েছে।');
    } elseif (isset($_POST['unban'])) {
        $stmt = $conn->prepare("UPDATE users SET is_banned = 0, ban_reason = NULL WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        logActivity($_SESSION['user_id'], 'user_unbanned', "ইউজার #$id আনব্যান করা হয়েছে");
        flash('success', 'ইউজার আনব্যান করা হয়েছে।');
    }
    redirect('admin/security/manage_bans.php');
}

$search = clean($_GET['q'] ?? '');
if ($search !== '') {
    $like = "%$search%";
    $stmt = $conn->prepare("SELECT * FROM users WHERE role != 'admin' AND (name LIKE ? OR email LIKE ? OR mobile LIKE ?) ORDER BY is_banned DESC, created_at DESC LIMIT 100");
    $stmt->bind_param("sss", $like, $like, $like);
    $stmt->execute();
    $users = $stmt->get_result();
} else {
    $users = $conn->query("SELECT * FROM users WHERE role != 'admin' ORDER BY is_banned DESC, created_at DESC LIMIT 100");
}

$pageTitle = "ইউজার ব্যান ম্যানেজমেন্ট";
require_once __DIR__ . '/../../includes/header.php';
?>
<h2>ইউজার ব্যান ম্যানেজমেন্ট</h2>
<p class="hint">ফেক বা অ্যাবিউজিভ একাউন্ট এখান থেকে সাসপেন্ড করুন — ব্যান করা ইউজার তৎক্ষণাৎ লগ-আউট হয়ে যাবে এবং আর লগইন করতে পারবে না।</p>

<form method="GET" class="search-bar" style="max-width:400px;">
    <input type="text" name="q" placeholder="নাম/ইমেইল/মোবাইল দিয়ে খুঁজুন" value="<?php echo htmlspecialchars($search); ?>">
    <button type="submit" class="btn-primary">খুঁজুন</button>
</form>

<table class="admin-table">
    <tr><th>নাম</th><th>ইমেইল/মোবাইল</th><th>রোল</th><th>স্ট্যাটাস</th><th>একশন</th></tr>
    <?php while ($u = $users->fetch_assoc()): ?>
    <tr>
        <td><a href="<?php echo BASE_URL; ?>user/profile.php?id=<?php echo $u['id']; ?>"><?php echo htmlspecialchars($u['name']); ?></a></td>
        <td><?php echo htmlspecialchars($u['email'] ?: $u['mobile']); ?></td>
        <td><?php echo ucfirst($u['role']); ?></td>
        <td>
            <?php if ($u['is_banned']): ?>
                <span class="status-badge status-rejected">ব্যানড</span>
                <?php if ($u['ban_reason']): ?><div class="hint" style="margin:2px 0 0;"><?php echo htmlspecialchars($u['ban_reason']); ?></div><?php endif; ?>
            <?php else: ?>
                <span class="status-badge status-approved">স্বাভাবিক</span>
            <?php endif; ?>
        </td>
        <td>
            <?php if ($u['is_banned']): ?>
                <form method="POST" style="display:inline;">
                    <?php echo csrfField(); ?>
                    <input type="hidden" name="id" value="<?php echo $u['id']; ?>">
                    <button type="submit" name="unban" value="1" class="link-btn-approve">আনব্যান</button>
                </form>
            <?php else: ?>
                <form method="POST" style="display:inline;" class="ban-form">
                    <?php echo csrfField(); ?>
                    <input type="hidden" name="id" value="<?php echo $u['id']; ?>">
                    <input type="hidden" name="reason" class="ban-reason-input" value="">
                    <button type="submit" name="ban" value="1" class="link-btn-reject">ব্যান</button>
                </form>
            <?php endif; ?>
        </td>
    </tr>
    <?php endwhile; ?>
</table>

<script nonce="<?php echo cspNonce(); ?>">
document.querySelectorAll('.ban-form').forEach(function(form) {
    form.addEventListener('submit', function(e) {
        const reason = prompt('ব্যান করার কারণ লিখুন:', 'সন্দেহজনক/ফেক একাউন্ট');
        if (reason === null) { e.preventDefault(); return; }
        form.querySelector('.ban-reason-input').value = reason;
    });
});
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
