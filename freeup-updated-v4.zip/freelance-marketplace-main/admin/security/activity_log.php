<?php
require_once __DIR__ . '/../../includes/functions.php';
requireRole('admin');

$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 50;
$offset = ($page - 1) * $perPage;

$total = $conn->query("SELECT COUNT(*) c FROM activity_log")->fetch_assoc()['c'];
$totalPages = max(1, ceil($total / $perPage));

$stmt = $conn->prepare("SELECT a.*, u.name AS user_name FROM activity_log a LEFT JOIN users u ON a.user_id = u.id ORDER BY a.created_at DESC LIMIT ? OFFSET ?");
$stmt->bind_param("ii", $perPage, $offset);
$stmt->execute();
$logs = $stmt->get_result();

$pageTitle = "অ্যাক্টিভিটি লগ";
require_once __DIR__ . '/../../includes/header.php';
?>
<h2>পূর্ণ অ্যাক্টিভিটি লগ</h2>
<p class="hint">মোট <?php echo $total; ?> টি এন্ট্রি — পেজ <?php echo $page; ?> / <?php echo $totalPages; ?></p>

<table class="admin-table">
    <tr><th>সময়</th><th>ইউজার</th><th>অ্যাকশন</th><th>বিস্তারিত</th><th>IP</th></tr>
    <?php if ($logs->num_rows === 0): ?>
        <tr><td colspan="5">কোনো লগ পাওয়া যায়নি।</td></tr>
    <?php endif; ?>
    <?php while ($row = $logs->fetch_assoc()): ?>
        <tr>
            <td><?php echo timeAgo($row['created_at']); ?></td>
            <td><?php echo $row['user_name'] ? htmlspecialchars($row['user_name']) : '—'; ?></td>
            <td><?php echo htmlspecialchars($row['action']); ?></td>
            <td><?php echo htmlspecialchars($row['details']); ?></td>
            <td><?php echo htmlspecialchars($row['ip_address']); ?></td>
        </tr>
    <?php endwhile; ?>
</table>

<div style="display:flex;gap:10px;margin-top:16px;">
    <?php if ($page > 1): ?><a href="?page=<?php echo $page-1; ?>" class="btn-secondary">← আগের পেজ</a><?php endif; ?>
    <?php if ($page < $totalPages): ?><a href="?page=<?php echo $page+1; ?>" class="btn-secondary">পরের পেজ →</a><?php endif; ?>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
