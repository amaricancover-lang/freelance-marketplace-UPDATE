<?php
require_once __DIR__ . '/../../includes/functions.php';
requireRole('admin');

$blockedCount = $conn->query("SELECT COUNT(*) c FROM blocked_ips")->fetch_assoc()['c'];
$bannedCount = $conn->query("SELECT COUNT(*) c FROM users WHERE is_banned = 1")->fetch_assoc()['c'];
$last24hFailedLogins = $conn->query("SELECT COUNT(*) c FROM login_attempts WHERE attempted_at > (NOW() - INTERVAL 24 HOUR)")->fetch_assoc()['c'];
$last24hActivity = $conn->query("SELECT COUNT(*) c FROM activity_log WHERE created_at > (NOW() - INTERVAL 24 HOUR)")->fetch_assoc()['c'];

// সাম্প্রতিক সন্দেহজনক ঘটনা (IP ব্লক, ব্যান, OTP মিসম্যাচ, ব্যান করা একাউন্টে লগইন চেষ্টা)
$suspicious = $conn->query("SELECT a.*, u.name AS user_name FROM activity_log a LEFT JOIN users u ON a.user_id = u.id
    WHERE a.action IN ('ip_blocked','blocked_login_attempt','otp_ip_mismatch') ORDER BY a.created_at DESC LIMIT 10");

$pageTitle = "সিকিউরিটি ড্যাশবোর্ড";
require_once __DIR__ . '/../../includes/header.php';
?>
<h2>🛡️ সিকিউরিটি অ্যাডমিন প্যানেল</h2>
<p class="hint">সাইটের সিকিউরিটি সংক্রান্ত সবকিছু এখান থেকে নিয়ন্ত্রণ করুন — IP ব্লক, ইউজার ব্যান, অ্যাক্টিভিটি লগ।</p>

<div class="admin-stats">
    <div class="stat-box highlight"><h3><?php echo $blockedCount; ?></h3><p>ব্লক করা IP</p></div>
    <div class="stat-box highlight"><h3><?php echo $bannedCount; ?></h3><p>ব্যান করা ইউজার</p></div>
    <div class="stat-box"><h3><?php echo $last24hFailedLogins; ?></h3><p>গত ২৪ ঘণ্টায় ব্যর্থ লগইন</p></div>
    <div class="stat-box"><h3><?php echo $last24hActivity; ?></h3><p>গত ২৪ ঘণ্টায় মোট অ্যাক্টিভিটি</p></div>
</div>

<div class="admin-links">
    <a href="blocked_ips.php" class="btn-primary">IP ব্লক ম্যানেজমেন্ট</a>
    <a href="manage_bans.php" class="btn-primary">ইউজার ব্যান ম্যানেজমেন্ট</a>
    <a href="activity_log.php" class="btn-secondary">পূর্ণ অ্যাক্টিভিটি লগ দেখুন</a>
</div>

<h3 style="margin-top:28px;">সাম্প্রতিক সন্দেহজনক কার্যকলাপ</h3>
<table class="admin-table">
    <tr><th>সময়</th><th>ঘটনা</th><th>ইউজার</th><th>IP</th><th>বিস্তারিত</th></tr>
    <?php if ($suspicious->num_rows === 0): ?>
        <tr><td colspan="5">কোনো সন্দেহজনক কার্যকলাপ পাওয়া যায়নি।</td></tr>
    <?php endif; ?>
    <?php while ($row = $suspicious->fetch_assoc()): ?>
        <tr>
            <td><?php echo timeAgo($row['created_at']); ?></td>
            <td><span class="status-badge status-rejected"><?php echo htmlspecialchars($row['action']); ?></span></td>
            <td><?php echo $row['user_name'] ? htmlspecialchars($row['user_name']) : '—'; ?></td>
            <td><?php echo htmlspecialchars($row['ip_address']); ?></td>
            <td><?php echo htmlspecialchars($row['details']); ?></td>
        </tr>
    <?php endwhile; ?>
</table>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
