<?php
require_once __DIR__ . '/../../includes/functions.php';
requireRole('admin');

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();

    if (isset($_POST['block_ip'])) {
        $ip = trim($_POST['ip_address'] ?? '');
        $reason = clean($_POST['reason'] ?? 'অ্যাডমিন কর্তৃক ম্যানুয়াল ব্লক');
        // সহজ IPv4/IPv6 ফরম্যাট ভ্যালিডেশন
        if (filter_var($ip, FILTER_VALIDATE_IP)) {
            blockIp($ip, $reason, 'admin');
            flash('success', "$ip ব্লক করা হয়েছে।");
        } else {
            $error = "সঠিক IP ঠিকানা দিন।";
        }
    } elseif (isset($_POST['unblock_ip'])) {
        $ip = trim($_POST['ip_address'] ?? '');
        unblockIp($ip);
        flash('success', "$ip আনব্লক করা হয়েছে।");
    }

    if (!$error) redirect('admin/security/blocked_ips.php');
}

$blocked = $conn->query("SELECT * FROM blocked_ips ORDER BY blocked_at DESC");
$myIp = clientIp();

$pageTitle = "IP ব্লক ম্যানেজমেন্ট";
require_once __DIR__ . '/../../includes/header.php';
?>
<h2>IP ব্লক ম্যানেজমেন্ট</h2>
<p class="hint">আপনার বর্তমান IP: <strong><?php echo htmlspecialchars($myIp); ?></strong> (নিজের IP ব্লক করলে নিজেই লক আউট হয়ে যাবেন — সাবধান)</p>

<?php if ($error): ?><div class="alert alert-error"><?php echo $error; ?></div><?php endif; ?>

<h3>নতুন IP ম্যানুয়ালি ব্লক করুন</h3>
<form method="POST" class="app-form" style="max-width:400px;">
    <?php echo csrfField(); ?>
    <label>IP ঠিকানা</label>
    <input type="text" name="ip_address" placeholder="192.168.1.1" required>
    <label>কারণ</label>
    <input type="text" name="reason" placeholder="যেমন: ফেক একাউন্ট / স্প্যাম / অ্যাবিউজ">
    <button type="submit" name="block_ip" value="1" class="btn-primary">ব্লক করুন</button>
</form>

<h3 style="margin-top:28px;">বর্তমানে ব্লক করা IP সমূহ</h3>
<table class="admin-table">
    <tr><th>IP</th><th>কারণ</th><th>যেভাবে ব্লক হয়েছে</th><th>সময়</th><th>একশন</th></tr>
    <?php if ($blocked->num_rows === 0): ?>
        <tr><td colspan="5">কোনো IP ব্লক করা নেই।</td></tr>
    <?php endif; ?>
    <?php while ($b = $blocked->fetch_assoc()): ?>
        <tr>
            <td><?php echo htmlspecialchars($b['ip_address']); ?></td>
            <td><?php echo htmlspecialchars($b['reason']); ?></td>
            <td><span class="status-badge <?php echo $b['blocked_by']==='auto' ? 'status-pending' : 'status-rejected'; ?>"><?php echo $b['blocked_by'] === 'auto' ? 'অটো-ব্লক' : 'অ্যাডমিন'; ?></span></td>
            <td><?php echo timeAgo($b['blocked_at']); ?></td>
            <td>
                <form method="POST" class="confirm-action-form" style="display:inline;">
                    <?php echo csrfField(); ?>
                    <input type="hidden" name="ip_address" value="<?php echo htmlspecialchars($b['ip_address']); ?>">
                    <button type="submit" name="unblock_ip" value="1" class="link-btn-approve">আনব্লক</button>
                </form>
            </td>
        </tr>
    <?php endwhile; ?>
</table>

<script nonce="<?php echo cspNonce(); ?>">
document.querySelectorAll('.confirm-action-form').forEach(function(form) {
    form.addEventListener('submit', function(e) {
        if (!confirm('আপনি কি নিশ্চিত?')) e.preventDefault();
    });
});
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
