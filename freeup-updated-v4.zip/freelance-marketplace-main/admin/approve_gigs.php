<?php
require_once __DIR__ . '/../includes/functions.php';
requireRole('admin');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'], $_POST['id'])) {
    verifyCsrf();
    $id = (int)$_POST['id'];
    $newStatus = $_POST['action'] === 'approve' ? 'approved' : 'rejected';
    $stmt = $conn->prepare("UPDATE gigs SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $newStatus, $id);
    $stmt->execute();

    // গিগের মালিককে ইমেইলে জানানো হচ্ছে
    $gstmt = $conn->prepare("SELECT g.title, u.name, u.email FROM gigs g JOIN users u ON g.user_id = u.id WHERE g.id = ?");
    $gstmt->bind_param("i", $id);
    $gstmt->execute();
    $gigRow = $gstmt->get_result()->fetch_assoc();
    if ($gigRow && $gigRow['email']) {
        sendGigStatusEmail($gigRow['email'], $gigRow['name'], $gigRow['title'], $newStatus === 'approved');
    }
    logActivity($_SESSION['user_id'], 'gig_' . $newStatus, "গিগ #$id");

    flash('success', 'গিগের স্ট্যাটাস আপডেট হয়েছে।');
    redirect('admin/approve_gigs.php');
}

$gigs = $conn->query("SELECT g.*, u.name AS seller_name FROM gigs g JOIN users u ON g.user_id = u.id ORDER BY g.status='pending' DESC, g.created_at DESC");

$pageTitle = "গিগ অ্যাপ্রুভাল";
require_once __DIR__ . '/../includes/header.php';
?>
<h2>গিগ ম্যানেজমেন্ট</h2>

<table class="admin-table">
    <tr><th>গিগ</th><th>সেলার</th><th>স্ট্যাটাস</th><th>একশন</th></tr>
    <?php while ($g = $gigs->fetch_assoc()): ?>
    <tr>
        <td><a href="<?php echo BASE_URL; ?>gigs/gig_detail.php?id=<?php echo $g['id']; ?>"><?php echo htmlspecialchars($g['title']); ?></a></td>
        <td><?php echo htmlspecialchars($g['seller_name']); ?></td>
        <td><span class="status-badge status-<?php echo $g['status']; ?>"><?php echo $g['status']; ?></span></td>
        <td>
            <?php if ($g['status'] !== 'approved'): ?>
                <form method="POST" style="display:inline;">
                    <?php echo csrfField(); ?>
                    <input type="hidden" name="id" value="<?php echo $g['id']; ?>">
                    <input type="hidden" name="action" value="approve">
                    <button type="submit" class="link-btn-approve">অ্যাপ্রুভ</button>
                </form>
            <?php endif; ?>
            <?php if ($g['status'] !== 'rejected'): ?>
                <form method="POST" style="display:inline;" class="confirm-action-form">
                    <?php echo csrfField(); ?>
                    <input type="hidden" name="id" value="<?php echo $g['id']; ?>">
                    <input type="hidden" name="action" value="reject">
                    <button type="submit" class="link-btn-reject">রিজেক্ট</button>
                </form>
            <?php endif; ?>
        </td>
    </tr>
    <?php endwhile; ?>
</table>


<script nonce="<?php echo cspNonce(); ?>">
document.querySelectorAll('.confirm-action-form').forEach(function(form) {
    form.addEventListener('submit', function(e) {
        if (!confirm('আপনি কি নিশ্চিত?')) e.preventDefault();
    });
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
