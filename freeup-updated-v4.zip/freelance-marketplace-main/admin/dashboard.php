<?php
require_once __DIR__ . '/../includes/functions.php';
requireRole('admin');

$pendingDevs = $conn->query("SELECT COUNT(*) c FROM users WHERE role='developer' AND status='pending'")->fetch_assoc()['c'];
$pendingGigs = $conn->query("SELECT COUNT(*) c FROM gigs WHERE status='pending'")->fetch_assoc()['c'];
$totalUsers = $conn->query("SELECT COUNT(*) c FROM users")->fetch_assoc()['c'];
$totalGigs = $conn->query("SELECT COUNT(*) c FROM gigs WHERE status='approved'")->fetch_assoc()['c'];

$pageTitle = "অ্যাডমিন ড্যাশবোর্ড";
require_once __DIR__ . '/../includes/header.php';
?>
<h2>অ্যাডমিন ড্যাশবোর্ড</h2>

<div class="admin-stats">
    <div class="stat-box"><h3><?php echo $totalUsers; ?></h3><p>মোট ইউজার</p></div>
    <div class="stat-box"><h3><?php echo $totalGigs; ?></h3><p>লাইভ গিগ</p></div>
    <div class="stat-box highlight"><h3><?php echo $pendingDevs; ?></h3><p>অপেক্ষমান ডেভলপার</p></div>
    <div class="stat-box highlight"><h3><?php echo $pendingGigs; ?></h3><p>অপেক্ষমান গিগ</p></div>
</div>

<div class="admin-links">
    <a href="approve_developers.php" class="btn-primary">ডেভলপার অ্যাপ্রুভাল ম্যানেজ করুন</a>
    <a href="approve_gigs.php" class="btn-primary">গিগ অ্যাপ্রুভাল ম্যানেজ করুন</a>
    <a href="manage_users.php" class="btn-secondary">সকল ইউজার দেখুন</a>
    <a href="security/dashboard.php" class="btn-secondary">🛡️ সিকিউরিটি প্যানেল</a>
    <a href="api.php" class="btn-secondary">📱 Android API</a>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
