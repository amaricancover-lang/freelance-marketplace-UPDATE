<?php
require_once __DIR__ . '/../includes/functions.php';
requireRole('admin');

$users = $conn->query("SELECT * FROM users ORDER BY created_at DESC");

$pageTitle = "সকল ইউজার";
require_once __DIR__ . '/../includes/header.php';
?>
<h2>সকল ইউজার</h2>
<table class="admin-table">
    <tr><th>নাম</th><th>ইমেইল/মোবাইল</th><th>রোল</th><th>স্ট্যাটাস</th></tr>
    <?php while ($u = $users->fetch_assoc()): ?>
    <tr>
        <td><a href="<?php echo BASE_URL; ?>user/profile.php?id=<?php echo $u['id']; ?>"><?php echo htmlspecialchars($u['name']); ?></a></td>
        <td><?php echo htmlspecialchars($u['email'] ?: $u['mobile']); ?></td>
        <td><?php echo ucfirst($u['role']); ?></td>
        <td><span class="status-badge status-<?php echo $u['status']; ?>"><?php echo $u['status']; ?></span></td>
    </tr>
    <?php endwhile; ?>
</table>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
