<?php
require_once __DIR__ . '/../includes/functions.php';
requireRole('admin');

$state = apiState(); // on | off | missing
$error = '';

// ============ অ্যাকশন (সব POST + CSRF সুরক্ষিত) ============
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $action = $_POST['action'] ?? '';

    if ($state === 'missing') {
        $error = "ডাটাবেজে API এর টেবিল নেই। আগে phpMyAdmin এ <b>update_api.sql</b> ইমপোর্ট করুন।";
    } elseif ($action === 'toggle') {
        $new = ($state === 'on') ? '0' : '1';
        setSiteSetting('api_enabled', $new);
        logActivity($_SESSION['user_id'], 'api_toggle', $new === '1' ? 'অ্যাপ API চালু করা হয়েছে' : 'অ্যাপ API বন্ধ করা হয়েছে');
        flash('success', $new === '1' ? 'অ্যাপের API চালু করা হয়েছে।' : 'অ্যাপের API বন্ধ করা হয়েছে। অ্যাপ আর কাজ করবে না।');
        redirect('admin/api.php');
    } elseif ($action === 'revoke') {
        $tokenId = (int)($_POST['token_id'] ?? 0);
        $stmt = $conn->prepare("UPDATE api_tokens SET revoked = 1 WHERE id = ?");
        $stmt->bind_param("i", $tokenId);
        $stmt->execute();
        logActivity($_SESSION['user_id'], 'api_token_revoked', "টোকেন #$tokenId বাতিল করা হয়েছে");
        flash('success', 'টোকেনটি বাতিল করা হয়েছে। ওই ডিভাইসকে আবার লগইন করতে হবে।');
        redirect('admin/api.php');
    } elseif ($action === 'revoke_all') {
        $conn->query("UPDATE api_tokens SET revoked = 1 WHERE revoked = 0");
        logActivity($_SESSION['user_id'], 'api_token_revoked', 'সব অ্যাপ টোকেন বাতিল করা হয়েছে');
        flash('success', 'সব ডিভাইসের টোকেন বাতিল করা হয়েছে।');
        redirect('admin/api.php');
    }
}

// ============ দেখানোর তথ্য ============
$routes = require __DIR__ . '/../api/routes.php';

$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$baseUrl = $scheme . '://' . $host . BASE_URL . 'api/';
// Android Emulator এর ভেতর থেকে কম্পিউটারের localhost এর ঠিকানা হলো 10.0.2.2
$emuHost = '10.0.2.2' . (preg_match('/:(\d+)$/', $host, $pm) ? ':' . $pm[1] : '');
$emulatorUrl = $scheme . '://' . $emuHost . BASE_URL . 'api/';

$tokens = [];
$activeCount = 0;
if ($state !== 'missing') {
    $res = $conn->query("SELECT t.id, t.device_name, t.ip_address, t.created_at, t.last_used_at, t.expires_at, t.revoked,
                                (t.expires_at <= NOW()) AS expired, u.id AS user_id, u.name, u.email, u.mobile
                         FROM api_tokens t JOIN users u ON u.id = t.user_id
                         ORDER BY t.id DESC LIMIT 50");
    while ($row = $res->fetch_assoc()) $tokens[] = $row;
    $activeCount = (int)$conn->query("SELECT COUNT(*) c FROM api_tokens WHERE revoked = 0 AND expires_at > NOW()")->fetch_assoc()['c'];
}

$pageTitle = "Android API";
require_once __DIR__ . '/../includes/header.php';
?>
<h2>📱 Android অ্যাপের জন্য REST API</h2>
<p class="hint" style="margin-bottom:16px;">এই API দিয়ে আপনার Android অ্যাপ এই সাইটের সাথে কথা বলে — গিগ দেখা, অর্ডার, মেসেজ সবই। অ্যাপ বানানোর ধাপগুলো PDF গাইডে আছে।</p>

<?php if ($error): ?><div class="alert alert-error"><?php echo $error; ?></div><?php endif; ?>

<?php if ($state === 'missing'): ?>
    <div class="alert alert-error">
        <b>এখনো সেটআপ হয়নি।</b> phpMyAdmin খুলুন → <code>freelance_marketplace</code> ডাটাবেজ সিলেক্ট করুন → Import ট্যাবে প্রজেক্ট ফোল্ডারের <b>update_api.sql</b> ফাইলটি দিন।
        তারপর এই পেজ রিলোড করুন।
    </div>
<?php endif; ?>

<div class="api-card">
    <div class="api-status-row">
        <div>
            <h3>API এর অবস্থা</h3>
            <?php if ($state === 'on'): ?>
                <span class="status-badge status-approved">চালু আছে</span>
                <span class="hint">সক্রিয় লগইন: <?php echo $activeCount; ?>টি ডিভাইস</span>
            <?php elseif ($state === 'off'): ?>
                <span class="status-badge status-rejected">বন্ধ আছে</span>
                <span class="hint">অ্যাপ এখন কাজ করবে না</span>
            <?php else: ?>
                <span class="status-badge status-pending">সেটআপ বাকি</span>
            <?php endif; ?>
        </div>
        <?php if ($state !== 'missing'): ?>
        <form method="POST">
            <?php echo csrfField(); ?>
            <input type="hidden" name="action" value="toggle">
            <button type="submit" class="<?php echo $state === 'on' ? 'btn-secondary' : 'btn-primary'; ?>" style="margin-top:0;">
                <?php echo $state === 'on' ? 'API বন্ধ করুন' : 'API চালু করুন'; ?>
            </button>
        </form>
        <?php endif; ?>
    </div>
</div>

<div class="api-card">
    <h3>API ঠিকানা (Base URL)</h3>
    <p class="hint">অ্যাপের কোডে এই ঠিকানা বসাতে হবে। শেষের <code>/</code> থাকা জরুরি।</p>
    <div class="api-url">
        <strong>কম্পিউটার/ব্রাউজার:</strong> <code id="url-main"><?php echo htmlspecialchars($baseUrl); ?></code>
        <button type="button" class="btn-secondary copy-btn" data-target="url-main" style="margin-top:0;">কপি</button>
    </div>
    <div class="api-url">
        <strong>Android Emulator:</strong> <code id="url-emu"><?php echo htmlspecialchars($emulatorUrl); ?></code>
        <button type="button" class="btn-secondary copy-btn" data-target="url-emu" style="margin-top:0;">কপি</button>
    </div>
    <p class="hint">আসল ফোনে টেস্ট করতে: ফোন ও কম্পিউটার একই Wi-Fi এ রাখুন, তারপর <code>localhost</code> এর জায়গায় কম্পিউটারের IP (যেমন <code>192.168.0.105</code>) বসান।
        কম্পিউটারের IP পেতে Command Prompt এ <code>ipconfig</code> চালান।</p>
    <p class="hint">ঠিকঠাক চলছে কিনা দেখতে ব্রাউজারে ঠিকানাটি খুলুন — <code>"status":"running"</code> দেখালে ঠিক আছে।</p>
</div>

<div class="api-card">
    <h3>এন্ডপয়েন্ট তালিকা</h3>
    <p class="hint">সব উত্তর JSON। সফল: <code>{"ok":true,"data":{...}}</code>, ব্যর্থ: <code>{"ok":false,"error":{"code":"...","message":"..."}}</code>।
        "টোকেন" লেখা এন্ডপয়েন্টে প্রতিটি রিকোয়েস্টে <code>Authorization: Bearer &lt;টোকেন&gt;</code> হেডার পাঠাতে হয়।</p>
    <div class="admin-table-wrap">
    <table class="admin-table">
        <tr><th>মেথড</th><th>পাথ</th><th>লগইন</th><th>কাজ</th></tr>
        <?php
        $authLabels = ['none' => 'লাগবে না', 'token' => 'টোকেন লাগবে', 'optional' => 'ঐচ্ছিক'];
        foreach ($routes as $r): ?>
        <tr>
            <td><span class="method method-<?php echo $r[0]; ?>"><?php echo $r[0]; ?></span></td>
            <td><code>/api/<?php echo htmlspecialchars($r[1]); ?></code></td>
            <td><?php echo $authLabels[$r[3]]; ?></td>
            <td><?php echo htmlspecialchars($r[4]); ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    </div>
    <p class="hint">নোট: নিরাপত্তার জন্য অ্যাডমিন একাউন্ট অ্যাপ দিয়ে লগইন করতে পারে না (অ্যাডমিন 2FA শুধু ওয়েবসাইটে)। রেজিস্ট্রেশন, লগইন ও অর্ডারে ওয়েবসাইটের মতোই রেট-লিমিট ও IP ব্লক কাজ করে।</p>
</div>

<div class="api-card">
    <h3>দ্রুত টেস্ট (লগইন)</h3>
    <p class="hint">Command Prompt বা Terminal এ চালিয়ে দেখুন (আগে ওয়েবসাইটে একটি Buyer একাউন্ট খুলে নিন):</p>
    <div class="code-block">curl -X POST <?php echo htmlspecialchars($baseUrl); ?>auth/login ^
  -H "Content-Type: application/json" ^
  -d "{\"identity\":\"you@example.com\",\"password\":\"YourPass123\"}"</div>
    <p class="hint">সফল হলে উত্তরে <code>token</code> আসবে। (Linux/Mac এ লাইন শেষের <code>^</code> এর জায়গায় <code>\</code> দিন।)</p>
</div>

<div class="api-card">
    <h3>অ্যাপ বানানোর গাইড</h3>
    <p class="hint">Android Studio দিয়ে ধাপে ধাপে অ্যাপ বানানোর সম্পূর্ণ PDF গাইড (Kotlin + Retrofit, কোডসহ)।</p>
    <a href="<?php echo BASE_URL; ?>docs/android-app-guide.pdf" class="btn-primary" target="_blank" style="margin-top:6px;">📄 PDF গাইড খুলুন</a>
</div>

<?php if ($state !== 'missing'): ?>
<div class="api-card">
    <div class="api-status-row">
        <h3>লগইন করা ডিভাইস (সর্বশেষ ৫০টি)</h3>
        <?php if ($activeCount > 0): ?>
        <form method="POST" class="confirm-form" data-msg="সব ডিভাইসের লগইন বাতিল করতে চান? সবাইকে অ্যাপে আবার লগইন করতে হবে।">
            <?php echo csrfField(); ?>
            <input type="hidden" name="action" value="revoke_all">
            <button type="submit" class="btn-secondary" style="margin-top:0;">সবগুলো বাতিল করুন</button>
        </form>
        <?php endif; ?>
    </div>
    <?php if (!$tokens): ?>
        <p class="hint">এখনো কেউ অ্যাপ দিয়ে লগইন করেনি।</p>
    <?php else: ?>
    <div class="admin-table-wrap">
    <table class="admin-table">
        <tr><th>ইউজার</th><th>ডিভাইস</th><th>IP</th><th>লগইন</th><th>শেষ ব্যবহার</th><th>অবস্থা</th><th></th></tr>
        <?php foreach ($tokens as $t):
            if ($t['revoked']) { $label = 'বাতিল'; $cls = 'rejected'; }
            elseif ($t['expired']) { $label = 'মেয়াদ শেষ'; $cls = 'pending'; }
            else { $label = 'সক্রিয়'; $cls = 'approved'; }
        ?>
        <tr>
            <td><a href="<?php echo BASE_URL; ?>user/profile.php?id=<?php echo $t['user_id']; ?>"><?php echo htmlspecialchars($t['name']); ?></a><br>
                <span class="hint"><?php echo htmlspecialchars($t['email'] ?: $t['mobile']); ?></span></td>
            <td><?php echo htmlspecialchars($t['device_name'] ?? ''); ?></td>
            <td><?php echo htmlspecialchars($t['ip_address'] ?? ''); ?></td>
            <td><?php echo timeAgo($t['created_at']); ?></td>
            <td><?php echo $t['last_used_at'] ? timeAgo($t['last_used_at']) : '—'; ?></td>
            <td><span class="status-badge status-<?php echo $cls; ?>"><?php echo $label; ?></span></td>
            <td>
                <?php if (!$t['revoked'] && !$t['expired']): ?>
                <form method="POST" class="confirm-form" data-msg="এই ডিভাইসের লগইন বাতিল করবেন?">
                    <?php echo csrfField(); ?>
                    <input type="hidden" name="action" value="revoke">
                    <input type="hidden" name="token_id" value="<?php echo (int)$t['id']; ?>">
                    <button type="submit" class="link-btn-danger">বাতিল</button>
                </form>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
    </div>
    <?php endif; ?>
</div>
<?php endif; ?>

<script nonce="<?php echo cspNonce(); ?>">
document.querySelectorAll('.copy-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
        var text = document.getElementById(btn.dataset.target).textContent;
        var done = function() { btn.textContent = 'কপি হয়েছে'; setTimeout(function() { btn.textContent = 'কপি'; }, 1500); };
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(done, function() {});
        }
    });
});
document.querySelectorAll('.confirm-form').forEach(function(form) {
    form.addEventListener('submit', function(e) {
        if (!confirm(form.dataset.msg)) e.preventDefault();
    });
});
</script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
